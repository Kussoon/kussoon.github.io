import copy, json, pathlib, sys, tempfile, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'adapter'))
from convert import convert, read, write, search
class ConversionTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.entities=read(ROOT/'output/kobe-entities.json')['entities'];cls.cross=read(ROOT/'output/kobe-crosswalk.json');cls.by={e['sourceId']:e for e in cls.entities if 'sourceId' in e}
 def test_01_higashinada_basic(self):
  with tempfile.TemporaryDirectory() as d:
   e=convert(ROOT/'source',d,wards=['28101']);self.assertEqual(sum(x['kind']=='town' for x in e),49);self.assertEqual(sum(x['kind']=='chome' for x in e),196)
   self.assertTrue(search(e,'うおざききたまち'));self.assertTrue(search(e,'魚崎北町一丁目'))
 def test_02_suma_kita_exceptions(self):
  with tempfile.TemporaryDirectory() as d:
   e=convert(ROOT/'source',d,wards=['28107','28109']);g=read(pathlib.Path(d)/'kobe-geometry-index.json')['entries']
   self.assertEqual(sum(p['sourceAuditInvalid'] for x in g for p in x['parts']),3)
   self.assertEqual(sum(x.get('post2020',False) for x in e),1)
   self.assertTrue(any(len(x['parts'])>1 for x in g));self.assertTrue(any(x['name']=='妙法寺' for x in e))
 def test_03_official_rows_and_unique_groups(self):
  self.assertEqual(len(self.cross['officialRows']),831);self.assertEqual(len(self.cross['townNameGroups']),826)
  self.assertEqual(sum(len(x['entityIds']) for x in self.cross['townNameGroups']),831)
 def test_04_expansion_and_no_chome(self):
  ex=self.cross['expandedEntries'];self.assertEqual(len(ex),2854);self.assertEqual(sum(x['isChome'] for x in ex),2538)
  self.assertEqual(sum(not x['isChome'] for x in ex),316)
  byid={e['id']:e for e in self.entities}
  for x in ex:self.assertEqual(byid[x['entityId']]['kind'],'chome' if x['isChome'] else 'town')
 def test_05_chome_no_inherited_geometry_or_fabricated_reading(self):
  for e in self.entities:
   if e['kind']=='chome':self.assertEqual(e['geometryRefs'],[]);self.assertIsNone(e['reading']);self.assertTrue(e['parentReading']);self.assertIsNone(e['geometryRef'])
 def test_06_source_rows_exact(self):
  source=read(ROOT/'source/city/kobe-town-index.json')['records']
  self.assertEqual({t['town_id'] for t in source},set(x['sourceId'] for x in self.cross['officialRows']))
  for t in source:self.assertEqual(self.by[t['town_id']]['sourceRecord'],t)
 def test_07_readings_and_aliases_search(self):
  for e in self.entities:
   if e['kind']=='town':
    self.assertIn(e,search(self.entities,e['reading'],ward=e['wardCode']))
    for a in e['aliases']:self.assertIn(e,search(self.entities,a,ward=e['wardCode']))
  self.assertTrue(search(self.entities,'鴨子ケ原一丁目',ward='28101'));self.assertTrue(search(self.entities,'鴨子ケ原',ward='28101'));self.assertTrue(search(self.entities,'上祇園町',ward='28105'));self.assertTrue(search(self.entities,'鴬町',ward='28106'))
 def test_08_city_and_ward_search(self):
  allhits=search(self.entities,'町'); parts=[e for code in ['28101','28102','28105','28106','28107','28108','28109','28110','28111'] for e in search(self.entities,'町',ward=code)]
  self.assertEqual({e['id'] for e in allhits},{e['id'] for e in parts});self.assertTrue(search(self.entities,'神戸市東灘区魚崎北町'))
 def test_09_registry_reordering_and_renumbering(self):
  with tempfile.TemporaryDirectory() as d:
   out=pathlib.Path(d)/'out'; a=convert(ROOT/'source',out,registry=ROOT/'output/id-registry.json',wards=['28101']);r=read(out/'id-registry.json');
   # Renumbering affects only provenance: signature registry preserves identity.
   import convert as module
   real=module.read
   def changed(p):
    data=real(p)
    if str(p).endswith('town-index.json'):
     data=copy.deepcopy(data); data['records'].reverse()
     for row in data['records']: row['town_id']='renumbered:'+row['town_id']
    if str(p).endswith(('chome-index.json','statistical-areas-index.json','crosswalk.json')):
     data=copy.deepcopy(data)
     for row in data['records']:
      if 'town_id' in row:row['town_id']='renumbered:'+row['town_id']
      if 'town_ids' in row:row['town_ids']=['renumbered:'+x for x in row['town_ids']]
    return data
   module.read=changed
   try:b=convert(ROOT/'source',out,registry=ROOT/'output/id-registry.json',wards=['28101'])
   finally:module.read=real
   self.assertEqual({e['name']:e['id'] for e in a if e['kind']=='town'},{e['name']:e['id'] for e in b if e['kind']=='town'})
 def test_10_rename_requires_review_and_supports_migration(self):
  import convert as module
  real=module.read; oldid=self.by['28101:T0001']['id']
  def renamed(p):
   d=real(p)
   if str(p).endswith('town-index.json'):d=copy.deepcopy(d);d['records'][0]['official_town_name']='改称検証用'
   return d
  with tempfile.TemporaryDirectory() as d:
   module.read=renamed
   try:
    with self.assertRaisesRegex(ValueError,'Unreviewed'):convert(ROOT/'source',d,registry=ROOT/'output/id-registry.json',wards=['28101'])
    e=convert(ROOT/'source',d,registry=ROOT/'output/id-registry.json',migrations={'28101:T0001':oldid},wards=['28101']);self.assertEqual(next(x['id'] for x in e if x['name']=='改称検証用'),oldid)
   finally:module.read=real
if __name__=='__main__':unittest.main()
