"""Run required pilot stages, then regenerate full-city output."""
import pathlib,sys,tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'adapter'))
from convert import convert,read
with tempfile.TemporaryDirectory() as d:
 for codes,expected in [(['28101'],(49,209,210)),(['28107','28109'],(199,631,658))]:
  convert(ROOT/'source',d,wards=codes);s=read(pathlib.Path(d)/'summary.json')['totals']
  assert (s['officialRows'],s['expandedEntries'],s['geometryFeatures'])==expected
  if len(codes)==2:
   g=read(pathlib.Path(d)/'kobe-geometry-index.json')['entries'];assert sum(p['sourceAuditInvalid'] for x in g for p in x['parts'])==3
  print('PASS',','.join(codes),s)
convert(ROOT/'source',ROOT/'output')
print('PASS full city',read(ROOT/'output/summary.json')['totals'])
