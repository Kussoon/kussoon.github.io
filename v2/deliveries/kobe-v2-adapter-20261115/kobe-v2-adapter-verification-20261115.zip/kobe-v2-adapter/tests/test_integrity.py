import collections, hashlib, json, pathlib, sys, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'adapter'))
from convert import read
class IntegrityTests(unittest.TestCase):
 @classmethod
 def setUpClass(c):
  c.e=read(ROOT/'output/kobe-entities.json')['entities'];c.g=read(ROOT/'output/kobe-geometry-index.json')['entries'];c.x=read(ROOT/'output/kobe-crosswalk.json');c.s=read(ROOT/'output/summary.json')
 def test_ids_unique(self):self.assertEqual(len(self.e),len({e['id'] for e in self.e}))
 def test_parent_existence_and_acyclic(self):
  by={e['id']:e for e in self.e}
  for e in self.e:
   seen=set();node=e
   while node['parentId'] is not None:
    self.assertNotIn(node['id'],seen);seen.add(node['id']);node=by[node['parentId']]
 def test_parent_kinds(self):
  by={e['id']:e for e in self.e};pairs={'country':'world','prefecture':'country','municipality':'prefecture','ward':'municipality','town':'ward','chome':'town'}
  for e in self.e:
   if e['kind']!='world':self.assertEqual(by[e['parentId']]['kind'],pairs[e['kind']])
 def test_geometry_references(self):
  ids={g['id'] for g in self.g};self.assertEqual(len(ids),2839)
  for e in self.e:
   for ref in e.get('geometryRefs',[]):self.assertIn(ref,ids)
   if e['geometryRef']:self.assertIn(e['geometryRef'],e['geometryRefs'])
 def test_all_raw_geometry_parts_exact(self):
  total=0
  for code in self.s['processingOrder']:
   top=read(ROOT/'source/wards'/code/'boundary_2020.topojson');raw=top['objects']['town']['geometries'];loc=[]
   for g in self.g:
    if g['wardCode']!=code:continue
    for p in g['parts']:
     loc.append(p['geometry_index']);self.assertEqual(str(raw[p['geometry_index']]['properties']['KEY_CODE']),g['statisticalAreaId']);self.assertEqual(raw[p['geometry_index']]['type'],p['geometry_type'])
   self.assertEqual(sorted(loc),list(range(len(raw))));total+=len(loc)
  self.assertEqual(total,2887)
 def test_32_decisions_exact(self):
  self.assertEqual(self.x['unresolvedDecisions'],read(ROOT/'source/audit/remaining-32-final-decisions.json'))
  self.assertEqual(collections.Counter(r['decision'] for r in self.x['unresolvedDecisions']),{'部分対応':12,'名称・階層のみ確認':18,'時点差による未対応':2})
 def test_unresolved_official_restrictions(self):
  by={e.get('sourceId'):e for e in self.e if e['kind']=='town'}
  for r in self.x['unresolvedDecisions']:
   if r['side']=='official_town':self.assertTrue(by[r['source_id']]['nameSearchEligible']);self.assertFalse(by[r['source_id']]['boundaryQuizEligible'])
 def test_non_town_six_excluded(self):self.assertEqual(sum(not g['learningSearchEligible'] for g in self.g),6)
 def test_three_invalid_features_preserved(self):
  bad=[p for g in self.g for p in g['parts'] if p['sourceAuditInvalid']];self.assertEqual(len(bad),3)
 def test_all_wards_sum(self):
  self.assertEqual(len(self.s['wards']),9)
  for k,v in self.s['totals'].items():self.assertEqual(sum(w[k] for w in self.s['wards']),v)
  for w in self.s['wards']:
   local=read(ROOT/'output/wards'/f"{w['wardCode']}.json")['entities'];self.assertEqual(local,[e for e in self.e if e.get('wardCode')==w['wardCode']])
 def test_hyogo49_bridge(self):
  top=read(ROOT/'evidence/github/main/v2/data/hyogo/hyogo-city.topojson'); gs=top['objects']['city']['geometries'];codes=[str(g['properties']['N03_007']) for g in gs]
  self.assertEqual(len(codes),49);self.assertEqual(len(set(codes)),49);by={e['id']:e for e in self.e}
  for code in self.s['processingOrder']:self.assertIn(code,codes);self.assertEqual(by[code]['kind'],'ward');self.assertEqual(by[code]['parentId'],'28100')
  self.assertNotIn('28100',codes)
  self.assertEqual(set(codes)&set(by),set(self.s['processingOrder']))
 def test_existing_hierarchy_shared_roots(self):
  existing=read(ROOT/'evidence/github/main/v2/geography/data/hierarchy.json')['nodes'];by={e['id']:e for e in self.e}
  self.assertEqual(set(by)&{e['id'] for e in existing},{'world','jp','jp-hyogo'})
  for e in existing:
   if e['id'] in by:
    for k in ['name','kind','parentId']:self.assertEqual(e[k],by[e['id']][k])
 def test_multilateral_relations_exact(self):
  expected=[]
  for code in self.s['processingOrder']:expected.extend(read(ROOT/'source/wards'/code/'crosswalk.json')['records'])
  self.assertEqual(expected,self.x['statisticalRelations'])
  by={e.get('sourceId'):e for e in self.e if e['kind']=='town'}
  for g in self.g:
   self.assertEqual(g['townEntityIds'],[by[x]['id'] for x in g['sourceRecord']['town_ids']])
 def test_schema(self):
  import jsonschema
  jsonschema.Draft202012Validator(read(ROOT/'adapter/schema.json')).validate(read(ROOT/'output/kobe-entities.json'))
 def test_source_manifest(self):
  m=read(ROOT/'source/manifest.json')
  for f in m['files']:
   p=ROOT/'source'/f['path'];self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),f['sha256'],f['path']);self.assertEqual(p.stat().st_size,f['size_bytes'])
if __name__=='__main__':unittest.main()
