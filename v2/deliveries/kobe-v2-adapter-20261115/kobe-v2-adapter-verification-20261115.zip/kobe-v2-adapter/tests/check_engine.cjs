// Execute frozen upstream pure decoders only. No DOM, map page or rendering.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert/strict');
const root=path.resolve(__dirname,'..'),read=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8'));
const engine=fs.readFileSync(path.join(root,'evidence/github/main/v2/common/js/town-map-engine.js'),'utf8');
const ctx={window:{}};vm.runInNewContext(engine,ctx);
const rows=[];
for(const code of read('output/summary.json').processingOrder){
 const topo=read('source/wards/'+code+'/boundary_2020.topojson');let common;
 try {const d=ctx.window.KussoonV2TownMap.decode(topo);assert.equal(d.features.length,topo.objects.town.geometries.length);assert(d.features.every(f=>f.rings.flat().every(p=>p.every(Number.isFinite))));common={status:'pass',features:d.features.length,uniqueRuntimeIds:new Set(d.features.map(f=>f.id)).size};}
 catch(e){common={status:'fail',error:e.message};}
 rows.push({wardCode:code,commonDecoder:common});
}
const pilot=fs.readFileSync(path.join(root,'evidence/github/pr450/v2/kawanishi-town-pilot/index.html'),'utf8');
const begin=pilot.indexOf('function decode(top){'),end=pilot.indexOf('\nfunction setup(',begin);assert(begin>=0&&end>begin);
const mainPilot=fs.readFileSync(path.join(root,'evidence/github/main/v2/kawanishi-town-pilot/index.html'),'utf8');
assert.equal(pilot.slice(begin,end),mainPilot.slice(mainPilot.indexOf('function decode(top){'),mainPilot.indexOf('\nfunction setup(',mainPilot.indexOf('function decode(top){'))));
const decode=vm.runInNewContext('('+pilot.slice(begin,end)+')');
const kaw=decode(read('evidence/github/pr450/v2/data/towns/kawanishi-2020.topojson'));
assert.equal(kaw.length,182);assert.equal(kaw.reduce((n,a)=>n+a.ids.length,0),191);
for(const row of rows){try{const r=decode(read('source/wards/'+row.wardCode+'/boundary_2020.topojson'));row.pr450PilotDecoder={status:'pass',features:r.reduce((n,a)=>n+a.ids.length,0)};}catch(e){row.pr450PilotDecoder={status:'fail',error:e.message};}}
// Importer deliberately supports only three municipalities; verify rejection.
const importer=require(path.join(root,'evidence/github/pr450/scripts/build-town-candidates.cjs'));
assert.throws(()=>importer.fromRaw('28101',read('source/wards/28101/boundary_2020.topojson')),/対象外/);
const k=importer.fromRaw('28217',read('evidence/github/pr450/v2/data/towns/kawanishi-2020.topojson'));assert.equal(k.errors.length,0);assert.equal(k.entries.length,191);
const out={method:'Node VM pure decoder; no browser/rendering',kawanishi:{distinctNames:kaw.length,features:191,importerEntries:k.entries.length,errors:k.errors.length},kobeImporter:'rejected-unsupported-code-as-expected',wards:rows};
fs.writeFileSync(path.join(root,'reports/engine-decode-results.json'),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out,null,2));
