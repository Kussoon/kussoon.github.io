"""Validate all packaged file sizes and SHA-256 digests, including raw sources."""
import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parents[1]
m=json.loads((root/'manifest.json').read_text())
for row in m['files']:
 p=root/row['path'];assert p.stat().st_size==row['sizeBytes'],row['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
print('PASS',len(m['files']),'file digests')
