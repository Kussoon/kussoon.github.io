#!/usr/bin/env python3
"""Independent, lossless Kobe preparation adapter. No network, no UI writes."""
import argparse, collections, hashlib, json, pathlib, re, uuid
NS = uuid.UUID('e73bd80a-5690-48e3-87ea-16dced3c82e9')
ORDER = ['28101','28107','28109','28102','28105','28106','28108','28110','28111']
def read(p): return json.loads(pathlib.Path(p).read_text(encoding='utf-8'))
def write(p,d):
 p=pathlib.Path(p); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def digest(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def signature(t): return json.dumps([t[k] for k in ['ward_code','official_town_name','town_reading','chome_min','chome_max']],ensure_ascii=False,separators=(',',':'))
def ident(seed): return 'kobe-v2:'+str(uuid.uuid5(NS,seed))
def norm(s): return re.sub(r'[\U000e0100-\U000e01ef\ufe00-\ufe0f\s]','',s)
def entity(id,parent,kind,name,reading=None,**extra):
 return dict(id=id,parentId=parent,kind=kind,name=name,reading=reading,aliases=[],geometryRef=None,groups=[],**extra)
def convert(source,dest,registry=None,migrations=None,allow_new=False,wards=None):
 source=pathlib.Path(source); dest=pathlib.Path(dest); selected=wards or ORDER
 old=read(registry) if registry else {'version':1,'records':[]}
 history=old['records']+old.get('retired',[])
 bysig={r['signature']:r for r in history}; priorids={r['entityId'] for r in history}; migrations=migrations or {}
 if len(bysig)!=len(history): raise ValueError('Ambiguous previous identity signatures')
 decisions=read(source/'audit/remaining-32-final-decisions.json'); official_dec={r['source_id']:r for r in decisions if r['side']=='official_town'}
 aliases={r['official_town_id']:r for r in read(source/'audit/orthographic-aliases.json')}
 invalid=read(source/'audit/gis/feature-validity.json'); bad={(r['ward_code'],r['geometry_index']) for r in invalid if not r['valid']}
 entities=[entity('world',None,'world','世界'),entity('jp','world','country','日本'),entity('jp-hyogo','jp','prefecture','兵庫県'),entity('28100','jp-hyogo','municipality','神戸市',municipalityCode='28100')]
 geometries=[]; rows=[]; expansions=[]; stats_cross=[]; summaries=[]; newreg=[]; town_groups=collections.defaultdict(list)
 for code in selected:
  base=source/'wards'/code; townfile=read(base/'town-index.json'); towns=townfile['records']; chomes=read(base/'chome-index.json')['records']; stats=read(base/'statistical-areas-index.json')['records']; top=read(base/'boundary_2020.topojson')
  entities.append(entity(code,'28100','ward',townfile['ward_name'],townfile['ward_reading'],municipalityCode=code))
  lookup={}; towns_by_source={t['town_id']:t for t in towns}; start=len(entities)
  for t in towns:
   sig=signature(t); prev=bysig.get(sig); explicit=migrations.get(t['town_id'])
   if explicit and explicit not in priorids: raise ValueError('Migration target absent from previous registry: '+explicit)
   if prev: eid=prev['entityId']
   elif explicit: eid=explicit
   elif registry and not allow_new: raise ValueError('Unreviewed new/renamed/restructured row: '+t['town_id'])
   else: eid=ident('initial-20261115:'+t['town_id']) if not registry else ident('new:'+sig)
   lookup[t['town_id']]=eid; newreg.append(dict(entityId=eid,signature=sig,sourceId=t['town_id']))
   refs=['codh2020:'+x for x in t['statistical_area_ids']]; decision=official_dec.get(t['town_id']); names=[]
   for a in aliases.get(t['town_id'],{}).get('statistical_names',[]): names.append(re.sub(r'[一二三四五六七八九十百〇零]+丁目$','',a['codh_name']))
   names=sorted(set(names)-{t['official_town_name']})
   e=entity(eid,code,'town',t['official_town_name'],t['town_reading'],sourceId=t['town_id'],wardCode=code,cityCode='28100',geometryRefs=refs,boundaryStatus=decision['decision'] if decision else t['boundary_match_status'],nameSearchEligible=True,positionDisplay='restricted-statistical' if refs else 'unavailable',boundaryQuizEligible=False,post2020=t['boundary_match_status']=='post_2020_no_boundary',sourceRecord=t)
   e['aliases']=names; e['geometryRef']=refs[0] if len(refs)==1 else None; entities.append(e);town_groups[(code,t['official_town_name'])].append(eid)
   rows.append(dict(sourceId=t['town_id'],entityId=eid,statisticalAreaIds=t['statistical_area_ids']))
  for c in chomes:
   parent=lookup[c['town_id']]; eid=parent
   if c['chome_number'] is not None:
    eid=ident(parent+':chome:'+str(c['chome_number']))
    entities.append(entity(eid,parent,'chome',c['display_name'],None,sourceId=c['chome_id'],wardCode=code,cityCode='28100',chomeNumber=c['chome_number'],parentReading=c['town_reading'],readingStatus='full-chome-reading-not-provided',geometryRefs=[],boundaryStatus='unconfirmed-chome',nameSearchEligible=True,positionDisplay='unavailable',boundaryQuizEligible=False))
    suffix=c['display_name'][len(towns_by_source[c['town_id']]['official_town_name']):]
    entities[-1]['aliases']=sorted({a['codh_name'] for a in aliases.get(c['town_id'],{}).get('statistical_names',[]) if a['codh_name'].endswith(suffix) and a['codh_name']!=c['display_name']})
   expansions.append(dict(sourceRecord=c,entityId=eid,parentEntityId=parent,isChome=c['chome_number'] is not None))
  for s in stats:
   parts=[]
   for part in s['geometry_parts']:
    g=top['objects'][part['object_name']]['geometries'][part['geometry_index']]
    if str(g['properties']['KEY_CODE'])!=s['stat_area_id']: raise ValueError('Incorrect raw geometry locator')
    parts.append(dict(part,sourceAuditInvalid=(code,part['geometry_index']) in bad))
   geometries.append(dict(id='codh2020:'+s['stat_area_id'],statisticalAreaId=s['stat_area_id'],wardCode=code,topojsonFile='source/'+s['topojson_file'],parts=parts,sourceYear=2020,sourceUrl=s['source_url'],sourceMetadata=top.get('metadata'),sourceRecord=s,learningSearchEligible=s['learning_search_eligible'],townEntityIds=[lookup[x] for x in s['town_ids']],boundaryQuizEligible=False))
  stats_cross.extend(read(base/'crosswalk.json')['records'])
  wc=[e for e in entities[start:] if e.get('wardCode')==code]
  summary=dict(wardCode=code,officialRows=len(towns),uniqueTownNames=len({t['official_town_name'] for t in towns}),expandedEntries=len(chomes),actualChomes=sum(c['chome_number'] is not None for c in chomes),noChomeEntries=sum(c['chome_number'] is None for c in chomes),statisticalIds=len(stats),geometryFeatures=sum(len(s['geometry_parts']) for s in stats))
  summaries.append(summary); write(dest/'wards'/f'{code}.json',dict(summary=summary,entities=wc))
 # Verify identity uniqueness before writing output; never silently coalesce updates.
 ids=[e['id'] for e in entities]
 if len(ids)!=len(set(ids)): raise ValueError('Duplicate entity ID; review migration/registry')
 active={r['entityId'] for r in newreg}; retired=[r for r in history if r['entityId'] not in active]
 for e in entities:
  if e['kind'] in ('town','chome'):
   ward=next(x['name'] for x in entities if x['id']==e['wardCode'])
   terms=[e['name'],e.get('reading') or '',*e['aliases']]
   if e['kind']=='chome': terms += [e['parentReading'],e['parentReading']+str(e['chomeNumber'])+'丁目']
   e['searchTerms']=sorted({norm(x) for x in terms if x}); e['qualifiedName']='神戸市'+ward+e['name']
 # Refresh ward files after search fields are populated.
 for s in summaries: write(dest/'wards'/f"{s['wardCode']}.json",dict(summary=s,entities=[e for e in entities if e.get('wardCode')==s['wardCode']]))
 write(dest/'kobe-entities.json',dict(schemaVersion='kobe-adapter-1',status='preconnection-not-engine-contract',entities=entities))
 write(dest/'kobe-geometry-index.json',dict(basis='CODH 2020 statistical boundaries; not current legal boundaries',entries=geometries))
 write(dest/'kobe-crosswalk.json',dict(officialRows=rows,expandedEntries=expansions,statisticalRelations=stats_cross,townNameGroups=[dict(wardCode=k[0],name=k[1],entityIds=v) for k,v in sorted(town_groups.items())],unresolvedDecisions=decisions))
 write(dest/'id-registry.json',dict(version=1,records=newreg,retired=retired))
 write(dest/'summary.json',dict(processingOrder=selected,wards=summaries,totals={k:sum(s[k] for s in summaries) for k in summaries[0] if k!='wardCode'},unresolvedDecisions=dict(collections.Counter(r['decision'] for r in decisions)),unresolvedSides=dict(collections.Counter(r['side'] for r in decisions))))
 return entities

def search(entities,query,ward=None,city='28100'):
 q=norm(query)
 return [e for e in entities if e.get('nameSearchEligible') and (not ward or e.get('wardCode')==ward) and e.get('cityCode')==city and (q in norm(e['qualifiedName']) or any(q in term for term in e['searchTerms']))]
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',default='source');p.add_argument('--output',default='output');p.add_argument('--registry');p.add_argument('--migrations',help='JSON: new source town_id -> reviewed old entityId');p.add_argument('--allow-new',action='store_true');p.add_argument('--wards',nargs='+',choices=ORDER)
 a=p.parse_args();convert(a.source,a.output,a.registry,read(a.migrations) if a.migrations else None,a.allow_new,a.wards)
