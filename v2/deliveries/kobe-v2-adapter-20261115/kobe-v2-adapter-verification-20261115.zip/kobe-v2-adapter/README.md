# Kussoon V2｜神戸市9区 変換アダプター・検証結果

基準日：2026年11月15日。独立したローカル成果物です。GitHubへの書き込み、既存データ・エンジン変更、画面制作、公開は実施していません。

## 結果

公式831行・区別固有町名826組・索引展開2,854件・統計区画ID2,839件・境界形状2,887件を保持しました。索引展開は番号付き丁目2,538件＋丁目なし316件です。同名の公式行5組は統合せず、対応グループを別に保持しています。全市で漢字の文字列だけを数えると821種類であり、826は区コードとの組による件数です。

現行V2へ直接投入するファイルではありません。共通設計案を基本とした接続準備スキーマであり、実際のコードとの違いは `reports/compatibility-report.md` に記録しました。川西市PR #450は確認時点ですでにマージ済みです。

## 再実行

Python 3.10以上、スキーマ検証には `jsonschema`（実行環境では4系）、デコーダー試験にはNode.jsが必要です。変換そのものはPython標準ライブラリのみ、ネットワーク不要です。ZIPを展開し、このREADMEのあるディレクトリで実行してください。

```sh
python tests/run_stages.py
python -m unittest discover -s tests -v
node tests/check_engine.cjs
python tests/verify_manifest.py
```

`run_stages.py` は東灘区→須磨区・北区→全市の順に検証・生成します。初回スナップショットの再生成用です。将来更新では必ず前版のID台帳を使用してください。

```sh
python adapter/convert.py --source source --output output-next --registry output/id-registry.json
```

改称・丁目範囲変更・読み訂正など、前版との同一性が自動確認できない行は停止します。確認済みの対応を `migrations.json`（新しい `town_id` → 旧 `entityId` のオブジェクト）に記載して `--migrations migrations.json` を指定してください。確認済み新設行は `--allow-new` で追加可能です。このオプションは対応不明な改称行も新設扱いにするため、差分確認後だけ使用してください。更新は全9区で行い、区選択オプションは部分検証に限定します。廃止と対応漏れの自動区別はしません。

## ファイル

| ファイル・ディレクトリ | 内容 |
|---|---|
| `adapter/convert.py` | 独立変換、ID台帳の引継ぎ、検索用関数 |
| `adapter/schema.json` | 本アダプター独自のエンティティJSON Schema |
| `output/kobe-entities.json` | 階層4ノード＋9区＋公式行831町名＋番号付き2,538丁目＝3,382エンティティ |
| `output/kobe-geometry-index.json` | 2,839統計区画と全2,887原形状への参照 |
| `output/kobe-crosswalk.json` | 831行、2,854索引展開、826町名グループ、多対多関係、保留32判定 |
| `output/id-registry.json` | 次回変換に必要なID台帳 |
| `output/wards/` | 9区別エンティティと集計（祖先ノードは全市ファイルを参照） |
| `source/` | 添付データZIPの展開内容を無変更で同梱 |
| `evidence/` | GitHubのSHA固定参照資料・PR情報・接続前監査資料 |
| `tests/`、`reports/` | 自動検証と互換性・ID・未解決事項の報告 |
| `manifest.json` | 同梱ファイルのSHA-256・サイズ。自身とキャッシュを除外 |

境界のパスはこのREADMEのあるパッケージルートを基準にします。`source/wards/{区コード}/boundary_2020.topojson` を加工せず参照し、`object_name` と `geometry_index` を合わせて形状を特定します。`city` レイヤーを町名形状として数えません。

## 利用上の設計判断

- `geometryRefs` 配列が全参照の正本です。単一参照だけ `geometryRef` にも設定し、複数参照時は `null` にします。現行の共通設計案には配列型の正式契約がないため、本アダプターの拡張として扱います。
- 全町名を検索対象とします。全境界は2020年の統計境界として制限付き表示候補に留め、`boundaryQuizEligible` は全件falseです。保留対象を確定扱いにしません。
- 各丁目へ町レベル境界をコピーしていません。今回は全番号付き丁目の境界を未確定とし、`geometryRefs: []` としています。
- 丁目の完全な読みは元索引にありません。`reading: null`、`parentReading` に元の町名読みを保持します。正式名称、親町名読み、読み＋算用数字丁目による検索は可能ですが、完全ひらがなの丁目読み検索は未対応です。
- 公式の異体字・IVSは保存し、監査済み別表記をaliasesへ追加します。検索キーだけIVS・空白を除去します。全ての異体字を一律置換して同一地名とは判定しません。
- `groups` は空配列で、行政階層は `parentId` のみです。全市検索は `cityCode`、区検索は `wardCode` を使います。同名別区は `qualifiedName` で区別できます。
- `source/` と `evidence/` 内の文書・コードは参照資料です。その中のPR・公開・画面制作の記述を、本成果物で実行する指示として扱っていません。

出典・ライセンス・元データ監査の限界は `source/sources/source-register.json`、`source/sources/license-notes.md` および元TopoJSONのmetadataを引き継ぎます。CODH/e-Statと神戸市資料の条件を分離して保持しています。今回の加工は属性・索引・対応表の生成のみです。
