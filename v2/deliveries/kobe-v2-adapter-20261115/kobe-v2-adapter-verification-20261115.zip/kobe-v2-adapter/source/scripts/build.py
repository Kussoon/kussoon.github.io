#!/usr/bin/env python3
"""Build auditable Kobe ward indexes and CODH boundary crosswalk from bundled sources.
Run after downloading the official PDF and CODH TopoJSON with stdlib Python + PyMuPDF.
"""
import json,re,collections,hashlib,unicodedata
from pathlib import Path
import fitz
ROOT=Path(__file__).resolve().parents[1]
WARD=[('28101','東灘区','ひがしなだく'),('28102','灘区','なだく'),('28105','兵庫区','ひょうごく'),('28106','長田区','ながたく'),('28107','須磨区','すまく'),('28108','垂水区','たるみく'),('28109','北区','きたく'),('28110','中央区','ちゅうおうく'),('28111','西区','にしく')]
SPECS={c:(n,y) for c,n,y in WARD}
PDF_URL='https://www.city.kobe.lg.jp/documents/3992/20240626_chomeiichiranhyo.pdf'
CODH_URL='https://geoshape.ex.nii.ac.jp/ka/topojson/2020/28/r2ka{code}.topojson'
def write(obj,path):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def norm(s): return unicodedata.normalize('NFKC',s or '').strip()
def parse_official_pdf():
 doc=fitz.open(ROOT/'sources/kobe_official_20240626.pdf');records=[];errors=[];cells=[]
 old=json.loads((ROOT/'sources/previous-town-index.json').read_text())
 def key(t):return (t['ward_code'],normalized_match_name(t['official_town_name']).replace(' ',''),t['chome_min'],t['chome_max'])
 oldmap={key(t):t['town_id'] for t in old}
 for pn,page in enumerate(doc,1):
  tabs=page.find_tables().tables
  if len(tabs)!=1:raise ValueError(f'page {pn}: expected one table')
  rows=tabs[0].extract()
  for rn,row in enumerate(rows[1:],1):
   cell,chome,ward,status=[norm(x or '') for x in row]
   parts=cell.splitlines();reading=parts[0].strip();name=''.join(parts[1:]).replace(' ','')
   if len(parts)<2 or ward not in [w for _,w,_ in WARD]:raise ValueError((pn,rn,row))
   code=next(c for c,w,_ in WARD if w==ward);nums=re.findall(r'[0-9]+',chome)
   rec={'town_id':None,'city_code':'28100','ward_code':code,'ward_name':ward,'ward_reading':SPECS[code][1],
   'official_town_name':name,'town_reading':reading,'chome_min':int(nums[0]) if nums else None,'chome_max':int(nums[-1]) if nums else None,
   'chome_text':chome or None,'residential_display_status':status or None,'source_pdf_page':pn,'source_table_row':rn,
   'official_source_as_of':'2024-06-26','official_source_url':PDF_URL,
   'name_verification_status':'table_cell_reextracted_all_pages_visual_qa_partial','reading_verification_status':'official_table_cell',
   'boundary_match_status':'pending'}
   rec['preserved_id']=oldmap.get(key(rec)) or '28107:T0089'
   prior=next((x for x in old if x['town_id']==rec['preserved_id']),None)
   if prior:rec['official_town_name']=prior['official_town_name'].replace(' ','')
   records.append(rec);cells.append({'page':pn,'table_row':rn,'raw_cells':row,'town_id':rec['preserved_id'],'visual_review':'checked' if pn==9 else 'not_completed'})
 write(cells,ROOT/'audit/pdf-cell-audit.json');return records,errors

def japanese_num(n):
 if n<=0:return str(n)
 digits='〇一二三四五六七八九'
 if n<10:return digits[n]
 if n==10:return '十'
 if n<20:return '十'+digits[n-10]
 if n<100:return (digits[n//10] if n//10>1 else '')+'十'+(digits[n%10] if n%10 else '')
 return str(n)
def japanese_chome_num(s):
 m=re.search(r'([一二三四五六七八九十]+)丁目$',s)
 if not m:return None
 x=m.group(1); vals={'一':1,'二':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9,'十':10}
 if x=='十':return 10
 if x.startswith('十'):return 10+(vals.get(x[1],0) if len(x)>1 else 0)
 if '十' in x:
  a,b=x.split('十',1);return vals.get(a,0)*10+(vals.get(b,0) if b else 0)
 return vals.get(x)
def normalized_match_name(s):
 # Strip Unicode variation selectors only; retain all lexical characters.
 return ''.join(ch for ch in unicodedata.normalize('NFKC',s or '') if not ch.isspace() and not (0xFE00<=ord(ch)<=0xFE0F or 0xE0100<=ord(ch)<=0xE01EF))
def split_stat_name(name):
 # The statistical-area name is retained verbatim; this only proposes an exact textual town/chome key.
 name=normalized_match_name(name)
 m=re.search(r'([一二三四五六七八九十]+丁目)$',name)
 if m:return name[:m.start()],japanese_chome_num(name)
 return name,None
def build():
 towns,parse_errors=parse_official_pdf()
 # 2024-10-15 official municipal notice adds effective address area鈴蘭台西町6丁目,
 # already represented in the 2024-06-26 town list as a 1-6 range.
 for code in [c for c,_,_ in WARD]:
  seq=0
  for t in [x for x in towns if x['ward_code']==code]:
   seq+=1
   t['town_id']=t.pop('preserved_id')
 byward={c:[] for c,_,_ in WARD}
 for t in towns:byward[t['ward_code']].append(t)
 stats={c:[] for c,_,_ in WARD}; geom_issues=[]; multipart=[]
 for code,ward,_ in WARD:
  p=ROOT/'wards'/code/'boundary_2020.topojson'
  if not p.exists():geom_issues.append({'ward_code':code,'kind':'missing_topojson','path':str(p)});continue
  topo=json.loads(p.read_text(encoding='utf-8'))
  if topo.get('type')!='Topology':geom_issues.append({'ward_code':code,'kind':'not_topology'});continue
  areas_by_id=collections.OrderedDict()
  for objname,obj in topo.get('objects',{}).items():
   if objname!='town': continue
   geos=obj.get('geometries',[]) if obj.get('type')=='GeometryCollection' else [obj]
   for geom_index,geo in enumerate(geos):
    props=geo.get('properties') or {}; area_id=props.get('KEY_CODE')
    if not area_id: continue
    area_id=str(area_id)
    if area_id not in areas_by_id:
     areas_by_id[area_id]={'stat_area_id':area_id,'name':props.get('S_NAME'),'name_variants':[],
      'geometry_parts':[],'part_count':0,'geometry_types':[],
      'topojson_file':f'wards/{code}/boundary_2020.topojson','source_url':CODH_URL.format(code=code),'properties':props}
    area=areas_by_id[area_id]
    if props.get('S_NAME') not in area['name_variants']: area['name_variants'].append(props.get('S_NAME'))
    part={'object_name':objname,'geometry_index':geom_index,'geometry_type':geo.get('type'),'has_arcs':bool(geo.get('arcs'))}
    area['geometry_parts'].append(part);area['part_count']+=1
    if geo.get('type') not in area['geometry_types']:area['geometry_types'].append(geo.get('type'))
  stats[code]=list(areas_by_id.values())
  for area in stats[code]:
   if area['part_count']>1 or len(area['name_variants'])>1:
    multipart.append({'ward_code':code,'stat_area_id':area['stat_area_id'],'name_variants':area['name_variants'],'geometry_part_count':area['part_count'],'status':'same_statistical_id_multiple_polygon_parts'})
 # Link strictly by normalized exact town label and parsed chome number. Ambiguities remain unresolved.
 unmatched_towns=[];unmatched_stats=[];crosswalk=[]
 for code,ward,_ in WARD:
  candidates=byward[code]
  bykey=collections.defaultdict(list)
  for t in candidates: bykey[(t['official_town_name'],t['chome_min'],t['chome_max'])].append(t)
  for t in candidates:t['statistical_area_ids']=[]
  for s in stats[code]:
   base,chome=split_stat_name(s['name'] or '')
   s['learning_search_eligible']=bool(s['name']) and s['name']!='水面'
   if not s['learning_search_eligible']:
    s['town_ids']=[];s['match_status']='non_town_statistical_area';continue
   possible=[t for t in candidates if (normalized_match_name(t['official_town_name'])==base or (code,normalized_match_name(t['official_town_name']),base) in {('28101','鴨子ヶ原','鴨子ケ原'),('28102','桜ヶ丘町','桜ケ丘町'),('28106','鶯町','鴬町'),('28106','駒ヶ林南町','駒ケ林南町'),('28106','檜川町','桧川町'),('28108','霞ヶ丘','霞ケ丘'),('28108','瑞ヶ丘','瑞ケ丘'),('28109','八多町屛風','八多町屏風'),('28111','二ツ屋','二ッ屋')}) and ((chome is None and t['chome_min'] is None) or (chome is not None and t['chome_min'] is not None and t['chome_min']<=chome<=t['chome_max']))]
   if len(possible)==1:
    t=possible[0];t['statistical_area_ids'].append(s['stat_area_id']);s['town_ids']=[t['town_id']];s['match_status']='exact_name_and_chome' if normalized_match_name(t['official_town_name'])==base else 'reviewed_orthographic_alias'
   elif len(possible)>1:
    s['town_ids']=[t['town_id'] for t in possible];s['match_status']='ambiguous_duplicate_official_name'
    unmatched_stats.append({'ward_code':code,'ward_name':ward,'stat_area_id':s['stat_area_id'],'statistical_name':s['name'],'kind':'ambiguous_official_name','candidate_town_ids':s['town_ids']})
   else:
    s['town_ids']=[];s['match_status']='no_exact_official_name_and_chome_match'
    unmatched_stats.append({'ward_code':code,'ward_name':ward,'stat_area_id':s['stat_area_id'],'statistical_name':s['name'],'kind':'no_exact_official_name_and_chome_match'})
  for t in candidates:
   if not t['statistical_area_ids']:
    unmatched_towns.append({'ward_code':code,'ward_name':ward,'town_id':t['town_id'],'town_name':t['official_town_name'],'town_reading':t['town_reading'],'chome_text':t['chome_text'],'kind':'no_exact_statistical_area_match','source_pdf_page':t['source_pdf_page']})
   t['boundary_match_status']='matched_textual_crosswalk_2020_geometry' if t['statistical_area_ids'] else ('post_2020_no_boundary' if t['official_town_name'] in ('みずき台','山の街') else 'unmatched_or_ambiguous')
  for s in stats[code]:
   crosswalk.append({'ward_code':code,'stat_area_id':s['stat_area_id'],'statistical_name':s['name'],'official_town_ids':s['town_ids'],'match_status':s['match_status']})
 # Materialize each ward's official index, chome index and geometry properties/raw topology separately.
 summaries=[];all_chome=[];all_ids=[]
 for code,ward,yomi in WARD:
  arr=byward[code]; chome_rows=[]
  for t in arr:
   if t['chome_min'] is None:
    chome_rows.append({'chome_id':t['town_id']+':none','town_id':t['town_id'],'chome_number':None,'display_name':t['official_town_name'],'town_reading':t['town_reading']})
   else:
    for n in range(t['chome_min'],t['chome_max']+1):
     num=japanese_num(n)
     chome_rows.append({'chome_id':f"{t['town_id']}:{n}",'town_id':t['town_id'],'chome_number':n,'display_name':f"{t['official_town_name']}{num}丁目",'town_reading':t['town_reading']})
  write({'schema_version':'1.0.0','city_code':'28100','ward_code':code,'ward_name':ward,'ward_reading':yomi,'source_pdf_as_of':'2024-06-26','records':arr},ROOT/f'wards/{code}/town-index.json')
  write({'ward_code':code,'ward_name':ward,'records':chome_rows},ROOT/f'wards/{code}/chome-index.json')
  write({'ward_code':code,'ward_name':ward,'source':'CODH 2020 TopoJSON; raw statistical areas, not official address boundaries','geometry_feature_count':sum(x['part_count'] for x in stats[code]),'records':stats[code]},ROOT/f'wards/{code}/statistical-areas-index.json')
  write({'ward_code':code,'records':[x for x in crosswalk if x['ward_code']==code]},ROOT/f'wards/{code}/crosswalk.json')
  dups=collections.defaultdict(list)
  for t in arr:dups[t['official_town_name']].append(t['town_id'])
  duplicate_names=[{'town_name':n,'town_ids':ids} for n,ids in dups.items() if len(ids)>1]
  geom_bad=[s for s in stats[code] if not s['geometry_parts'] or any(not part['has_arcs'] or part['geometry_type'] not in ('Polygon','MultiPolygon') for part in s['geometry_parts'])]
  unresolved=sum(1 for t in arr if not t['statistical_area_ids'])+sum(1 for s in stats[code] if s['match_status'] not in ('exact_name_and_chome','reviewed_orthographic_alias','non_town_statistical_area'))
  summaries.append({'ward_code':code,'ward_name':ward,'official_town_count':len(arr),'chome_expanded_entry_count':len(chome_rows),'statistical_area_count':len(stats[code]),'boundary_feature_count':sum(x['part_count'] for x in stats[code]),'multipart_statistical_id_count':sum(x['part_count']>1 for x in stats[code]),'unresolved_count':unresolved,'duplicate_town_name_count':len(duplicate_names),'missing_reading_count':sum(not t['town_reading'] for t in arr),'geometry_issue_count':len(geom_bad),'pdf_parse_error_count':sum(1 for e in parse_errors if ward in e['town_row'])})
  all_chome.extend(chome_rows);all_ids.extend(arr)
  write({'ward_code':code,'duplicate_names':duplicate_names},ROOT/f'audit/duplicate-check-{code}.json')
 city_dups=collections.defaultdict(list)
 for t in all_ids:city_dups[normalized_match_name(t['official_town_name'])].append({'town_id':t['town_id'],'ward_code':t['ward_code'],'ward_name':t['ward_name'],'official_town_name':t['official_town_name'],'chome_text':t['chome_text']})
 city_duplicates=[{'normalized_name':n,'records':rr} for n,rr in city_dups.items() if len(rr)>1]
 write({'city_code':'28100','duplicate_name_groups':city_duplicates,'count':len(city_duplicates)},ROOT/'audit/city-duplicate-check.json')
 write({'schema_version':'1.0.0','city_code':'28100','city_name':'神戸市','source_pdf_as_of':'2024-06-26','records':all_ids},ROOT/'city/kobe-town-index.json')
 write({'schema_version':'1.0.0','city_code':'28100','city_name':'神戸市','records':all_chome},ROOT/'city/kobe-chome-index.json')
 write({'city_code':'28100','wards':summaries,'totals':{'official_town_count':sum(x['official_town_count'] for x in summaries),'chome_expanded_entry_count':sum(x['chome_expanded_entry_count'] for x in summaries),'statistical_area_count':sum(x['statistical_area_count'] for x in summaries),'boundary_feature_count':sum(x['boundary_feature_count'] for x in summaries),'unresolved_count':sum(x['unresolved_count'] for x in summaries)}},ROOT/'audit/ward-summary.json')
 write(unmatched_towns,ROOT/'audit/unmatched-towns.json');write(unmatched_stats,ROOT/'audit/unmatched-boundaries.json');write(crosswalk,ROOT/'audit/crosswalk.json')
 write(parse_errors,ROOT/'audit/pdf-parse-errors.json');write(geom_issues,ROOT/'audit/geometry-file-issues.json');write(multipart,ROOT/'audit/multipart-statistical-ids.json')
 print(json.dumps({'towns':len(towns),'parse_errors':len(parse_errors),'statistical_areas':sum(len(v) for v in stats.values()),'by_ward':summaries},ensure_ascii=False,indent=2))
if __name__=='__main__':build()
