#!/usr/bin/env python3
"""Apply recorded 2026-11-15 visual-review decisions to the reviewed PDF hash only.
Run AFTER build.py and historical finalize_revision.py, GIS audit, before refresh_manifest.py.
"""
import json,hashlib,csv,collections,unicodedata,re
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def load(p):return json.loads((R/p).read_text())
def save(p,x):(R/p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKC',s or '') if not c.isspace() and not (0xE0100<=ord(c)<=0xE01EF))
ledger=load('sources/pdf-visual-review-ledger.json')
assert hashlib.sha256((R/'sources/kobe_official_20240626.pdf').read_bytes()).hexdigest()==ledger['pdf_sha256'],'Unreviewed PDF version'
T=load('city/kobe-town-index.json');td={x['town_id']:x for x in T['records']};cells=load('audit/pdf-cell-audit.json');diff=[]
for row in cells:
 t=td[row['town_id']];raw=row['raw_cells'];s=raw[0].splitlines();nums=re.findall(r'\d+',unicodedata.normalize('NFKC',raw[1] or ''))
 checks={'town_name':norm(''.join(s[1:]))==norm(t['official_town_name']),'reading':norm(s[0])==norm(t['town_reading']),'ward':norm(raw[2])==norm(t['ward_name']),'chome':(int(nums[0]) if nums else None)==t['chome_min'] and (int(nums[-1]) if nums else None)==t['chome_max'],'residential_status':norm(raw[3])==norm(t['residential_display_status'])}
 if not all(checks.values()):diff.append({'town_id':t['town_id'],'checks':checks})
 row.update({'visual_review':'completed_AI_visual','reading_match':checks['reading'],'chome_match':checks['chome'],'name_match':checks['town_name'],'ward_match':checks['ward'],'residential_status_match':checks['residential_status'],'corrections':[],'unverified_fields':[]})
 t['name_verification_status']='official_pdf_image_row_review_completed';t['reading_verification_status']='official_pdf_image_row_review_completed';t['pdf_visual_review_page']=t['source_pdf_page']
assert not diff,diff
save('audit/pdf-cell-audit.json',cells);save('city/kobe-town-index.json',T)
for code in ['28101','28102','28105','28106','28107','28108','28109','28110','28111']:
 p=f'wards/{code}/town-index.json';w=load(p);w['records']=[td[t['town_id']] for t in w['records']];save(p,w)
summary=load('audit/ward-summary.json');gis=load('audit/gis/summary.json');invalid=[x for x in load('audit/gis/feature-validity.json') if not x['valid']]
for w in summary['wards']:
 w['gis_invalid_geometry_count']=sum(x['ward_code']==w['ward_code'] for x in invalid)
 w['pdf_visual_review_completed_rows']=w['official_town_count']
summary['totals']['gis_invalid_geometry_count']=len(invalid);save('audit/ward-summary.json',summary)
cases=load('audit/gis/remaining-32-decisions.json')
for x in cases:
 if x['name']=='山の街':x['notice_evidence']={'url':'https://www.city.kobe.lg.jp/documents/6662/koho3865.pdf','local_file':'sources/yamanomachi-notice.pdf','pages':'PDF2,4,6,7,8 (公報20,22,24,25,26頁)','map_review':'PDF8画像確認。町界・16街区を確認。座標付与なしの図面のため未ジオリファレンス。'}
 if x['name']=='みずき台':x['notice_evidence']={'url':'https://www.city.kobe.lg.jp/documents/6662/r50228koho3798kokuji677678679.pdf','local_file':'sources/mizukidai-notice.pdf','pages':'PDF2,4,6,7,8 (公報3124,3126,3128,3129,3130頁)','map_review':'PDF8画像確認。町界の外周確認。座標付与なしの図面のため未ジオリファレンス。'}
 save('audit/gis/remaining-32-decisions.json',cases)
save('audit/remaining-32-final-decisions.json',cases)
with (R/'audit/remaining-32-final-decisions.csv').open('w',encoding='utf-8-sig',newline='') as f:
 fields=['source_id','side','ward_code','name','decision','decision_reason','official_gis_labels','spatial_metrics','source_urls'];wr=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');wr.writeheader();wr.writerows(cases)
for code in [w['ward_code'] for w in summary['wards']]:
 save(f'wards/{code}/partial-boundary-relations.json',{'note':'監査用の部分関係。主クロスウォークに境界を新規割当したものではない。','records':[x for x in cases if x['ward_code']==code]})
save('audit/pdf-reproofreading-summary.json',{'reviewed_pages':20,'reviewed_rows':831,'method':'AIによるPDFレンダリング画像の全行確認 + 原票セルと索引の項目比較','reading_corrections':0,'chome_corrections':0,'status_corrections':0,'new_missing_towns':0,'unreviewed_rows':0,'source_pdf_sha256':ledger['pdf_sha256'],'cell_mismatches':diff,'pages':ledger['pages']})
# Keep historical stage script in history, latest apply script deliberately supersedes its documentation.
save('audit/final-revision-history.json',{'data_value_changes_since_revised':[],'audit_updates':['20ページ831行の目視校正状態を更新','神戸市公式GIS2875featureを追加取得し照合','32件の最終判定/部分関係を記録','CODH位相検査で3自己交差を記録'],'source_geometry_changes':0})
header='''# 神戸市9区 最終監査報告（2026-11-15）

## PDF校正：合格
全20ページ・831町名行をPDFレンダリング画像で行順に確認。読み・町名・区・丁目・複合注記を照合し、新規欠落0、読み修正0、丁目修正0、注記修正0。原票セルとの全項目比較も不一致0。AIによる目視校正であり、人による独立した二重校正は未実施。白川台を含め現行831行を維持。

## GIS対応：部分確認／確定保留
32件：確定0、部分対応12、名称・階層のみ確認18、時点差2、未確認0。これは根拠区分であり、完全な境界割当が終わった件数ではありません。32件とも現行町域との完全対応は保留し、主クロスウォークの境界割当は増やしていません。

神戸市の「市区・町丁目・大字境界」shapeを追加取得（2875feature）。同じリンクコード・似た頂点を持つためCODHと共通の統計由来が示唆され、独立した法定町界の確定根拠とはみなしません。カタログ更新日は2022-10-28ですが配布ZIP内日時は2026-11-14。データ内容の基準日は不明です。PRJが付属しないため、経緯度であることは座標範囲から判断できても測地系は未確認。JGD2000を仮置きした空間比較の数値を確定測量値としません。

池田谷町・道正台・高塚台は、同名区画同士のほぼ同位置を確認しても丁目別の一致は未確定。妙法寺・多井畑の字区画等は親町の一部としての部分関係を保持。玉津町二ツ屋の形状を玉津町丸塚へ流用していません。山田町下谷上字中一里山の2IDは公式GIS側に対応IDがなく名称/階層確認にとどめます。灘区6町等の公式GISに対象町名がないものは類似町名の形状へ接続せず、町名を保持。

みずき台・山の街の告示と町界図を取得・画像確認しました。図は座標付きGISではないため、本工程ではジオリファレンス・座標化していません。2020年形状へ新設町名を割当していません。

## GIS形状品質：要確認3件
CODH全2887featureをShapelyで位相検査。自己交差3件：須磨区白川281070260、北区君影町一丁目28109030001、北区しあわせの村281090791。いずれも元TopoJSONの座標に存在する問題で、原データを変更していません。演算を可能にするためinvalid形状だけメモリ内でmake_validを使用し、その結果は本番形状として保存していません。検査GeoJSONも元座標を保持（旧GeoJSON形式でEPSG:4612を明記）。

重複形状0組、1㎡超の同一区内・区をまたぐ重なり候補0組。同じCODHの区集約cityを対象域として、町区画unionとの差（隙間/区外）は全9区0㎡。これは同一資料内の被覆整合性であり、独立した現行行政界での隙間ゼロを証明しません。独立町界との測地系を確定した精密重ね合わせは残課題です。

## 最終集計
'''
lines=['|区名|公式行|固有町名|丁目展開|区画ID|形状feature|未解決|','|---|---:|---:|---:|---:|---:|---:|']
for w in summary['wards']:lines.append('|'+w['ward_name']+'|'+'|'.join(str(w[k]) for k in ['official_town_count','unique_town_name_count','chome_expanded_entry_count','statistical_area_count','boundary_feature_count','unresolved_count'])+'|')
w=summary['totals'];lines.append('|全市|'+'|'.join(str(w[k]) for k in ['official_town_count','unique_town_name_count','chome_expanded_entry_count','statistical_area_count','boundary_feature_count','unresolved_count'])+'|')
report=header+'\n'.join(lines)+'''

件数は前回修正版から変更なし。区を区別した固有町名数826、区を無視した表記文字列の固有数821。読み欠損0、町名ID重複0、参照不整合0。JSON/TopoJSON構文・弧参照/輪の閉鎖は合格（validation-results.json参照）。名称なし3区画の警告は保持。GIS自己交差3件はこれと別の品質問題です。

## 接続制約と追加資料
最新町名は2024-06-26資料、統計形状は2020-10-01。未対応32件を現在の町域境界として強制接続しないこと。必要な追加資料は、座標系が明記された町字界GIS、未実施地区の町字界図、告示図を正確に座標化する基準点・参照地図です。自己交差3件の扱いも接続前に決定が必要です。学習検索から除外する水面/名称なし6区画も形状は保持。

神戸市公式PDF/告示は神戸市ウェブサイト利用規約に従い出典・加工表示。神戸市GISカタログはCC表示、ポータル利用方針がリンクする表示ライセンスはCC BY2.1日本（sources/license-notes.md）。CODHはCC BY4.0。今回の出典・再配布条件は資料ごとに記録しました。
'''
(R/'audit/final-audit-report.md').write_text(report);(R/'audit/validation-report.md').write_text(report)
(R/'README.md').write_text('''# Kussoon V2 神戸市9区 最終監査データ
調査基準2026-11-15。データ整備/監査のみ。本ZIPは現行町域の全境界確定を意味しません。

'''+report+'''

## 再検証
Python3、PyMuPDF、Shapely、pyproj、pyshpを使用。`python tools/gis_audit.py` でGIS再検査、`python tools/validate_package.py` で構造検査。再構築は `python scripts/build.py` → `python tools/finalize_revision.py`（旧段階の索引整理）→ `python tools/gis_audit.py` → `python tools/apply_final_audit.py` → `python tools/refresh_manifest.py`。PDF校正状態は同一PDFハッシュにのみ適用し、PDFが変われば再校正が必要。

`wards/<code>/boundary_2020.topojson`は元境界、`audit/gis/*-inspection.geojson`は検査用展開。`partial-boundary-relations.json`は監査用部分関係であり本接続用の確定境界割当ではありません。

出典：「神戸市町名一覧表」（神戸市）https://www.city.kobe.lg.jp/a53715/kurashi/registration/jukyo/ichiran.html を加工して作成。
「市区・町丁目・大字境界」（神戸市）https://catalog.city.kobe.lg.jp/dataset/boundary-town-chome-oaza を空間検査に利用。
「国勢調査町丁・字等別境界データセット」（CODH作成）「令和2年国勢調査町丁・字等別境界データ」（e-Stat）を加工 doi:10.20676/00000450
''')
print(json.dumps({'pdf_rows':len(cells),'pdf_mismatches':diff,'gis':gis['case_decisions']},ensure_ascii=False))
