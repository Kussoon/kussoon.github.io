import json,csv,collections,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def load(p):return json.loads((R/p).read_text())
def save(p,x):(R/p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
T=load('city/kobe-town-index.json')['records']; old={x['town_id']:x for x in load('sources/previous-town-index.json')}; td={x['town_id']:x for x in T}
S=[]
for code in ['28101','28102','28105','28106','28107','28108','28109','28110','28111']:S+=load(f'wards/{code}/statistical-areas-index.json')['records']
sd={x['stat_area_id']:x for x in S}
orig=load('sources/secondary-audit-original.json')['records']; decisions=[]
for n,r in enumerate(orig,1):
 d=dict(r);d['original_audit_id']=f'A81-{n:03d}';d['evidence_urls']=['https://www.city.kobe.lg.jp/documents/3992/20240626_chomeiichiranhyo.pdf',f"https://geoshape.ex.nii.ac.jp/ka/resource/{r['ward_code']}.html"]
 if r['side']=='official':
  t=td[r['record_id']];ids=t['statistical_area_ids'];resolved=bool(ids);status='resolved_textual_crosswalk' if resolved else 'unresolved';d['official_town_name']=t['official_town_name'];d['matched_ids']=ids
 else:
  t=sd[r['record_id']];resolved=bool(t['town_ids']);status='resolved_textual_crosswalk' if resolved else ('non_town_excluded_from_learning' if not t['learning_search_eligible'] else 'unresolved');d['codh_name']=t['name'];d['matched_ids']=t['town_ids']
 d['decision']=status
 d['reason']=({'resolved_textual_crosswalk':'原票セルとCODH元名称・区コード・丁目を個別照合。語彙表記差は区別したまま別名対応。形状の現行町域一致は保証しない。','non_town_excluded_from_learning':'水面または名称なし区画。形状とIDは保持し、学習検索対象のみ除外。','unresolved':'2020年資料と現行町名の粒度/時点差、または根拠不足。境界は割り当てない。'}[status])
 if r['category']=='post_2020_added':d['evidence_urls'].append('https://www.city.kobe.lg.jp/a53715/kurashi/registration/jukyo/05_jisitiku.html')
 decisions.append(d)
save('audit/secondary-81-decisions.json',{'records':decisions,'counts':dict(collections.Counter(x['decision'] for x in decisions)),'remaining_by_category':dict(collections.Counter(x['category'] for x in decisions if x['decision']=='unresolved'))})
with (R/'audit/secondary-81-decisions.csv').open('w',newline='',encoding='utf-8-sig') as f:
 fields=['original_audit_id','side','ward_code','record_id','name','category','decision','matched_ids','reason','evidence_urls'];w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(decisions)
alias=[]
for r in decisions:
 if r['side']=='official' and r['category']=='orthographic_variant_candidate':
  t=td[r['record_id']];pairs=[{'stat_area_id':i,'codh_name':sd[i]['name']} for i in t['statistical_area_ids']]
  alias.append({'official_town_id':t['town_id'],'official_name':t['official_town_name'],'source_pdf_page':t['source_pdf_page'],'statistical_names':pairs,'verification':'individual_source_label_ward_and_chome_checked','scope':'textual identity only; no current boundary certification'})
save('audit/orthographic-aliases.json',alias)
changes=[]
for t in T:
 if t['town_id'] not in old:changes.append({'town_id':t['town_id'],'kind':'added_missing_row','after':t})
 else:
  for key in ['official_town_name','town_reading','chome_min','chome_max','residential_display_status']:
   if t.get(key)!=old[t['town_id']].get(key):changes.append({'town_id':t['town_id'],'kind':key,'before':old[t['town_id']].get(key),'after':t.get(key)})
save('audit/revision-history.json',changes)
sumry=load('audit/ward-summary.json')
for w in sumry['wards']:w['unique_town_name_count']=len({x['official_town_name'] for x in T if x['ward_code']==w['ward_code']})
sumry['totals']['unique_town_name_count']=len({(x['ward_code'],x['official_town_name']) for x in T});sumry['totals']['unique_labels_across_wards']=len({x['official_town_name'] for x in T})
save('audit/ward-summary.json',sumry)
save('audit/non-town-statistical-areas.json',[x for x in S if not x['learning_search_eligible']])
counts=collections.Counter(x['page'] for x in load('audit/pdf-cell-audit.json'))
save('audit/pdf-reproofreading-summary.json',{'pages':[{'page':p,'table_row_count':counts[p],'cell_audit':'completed','visual_audit':'completed' if p==9 else 'not_completed'} for p in range(1,21)],'row_count':len(T),'omissions_found':['白川台'],'reading_corrections':0,'existing_chome_range_corrections':0,'new_chome_entries':7,'residential_display_corrections':sum(x['kind']=='residential_display_status' for x in changes),'limitation':'All pages re-extracted using table cell geometry; full 20-page visual proofreading NOT completed. Page9 visually checked.'})
table=['| 区名 | 公式町名行 | 固有町名数 | 丁目展開 | 統計区画ID | 未解決 |','|---|---:|---:|---:|---:|---:|']
for w in sumry['wards']:table.append('| '+w['ward_name']+' | '+' | '.join(str(w[k]) for k in ['official_town_count','unique_town_name_count','chome_expanded_entry_count','statistical_area_count','unresolved_count'])+' |')
a=sumry['totals'];table.append('| **全市** | '+' | '.join(str(a[k]) for k in ['official_town_count','unique_town_name_count','chome_expanded_entry_count','statistical_area_count','unresolved_count'])+' |')
report='''# 神戸市9区 修正版監査結果（2026-11-15）

全20ページを罫線セル方式で再抽出し831行を照合。白川台1〜7丁目を追加し、既存830IDを保持。白川台は28107:T0089。全20ページの画像目視校正は未完了で、画像確認した範囲は9ページのみ。したがって全件目視校正済みの最終確定版とはしません。

'''+ '\n'.join(table)+'''

公式町名行830→831、丁目展開2847→2854。固有町名数は区を区別した町名数826（区を区別せず文字列だけで数えると821）。同一区内で丁目なし・丁目ありの別行は別レコード。統計区画ID2839、形状feature2887を維持。

二次監査81レコード：43件の対応を解決、6件を水面・名称なしとして通常学習検索から除外、32件は境界未対応。未解決の内訳は新設2・丁目粒度6・字粒度8・その他16。元81件のIDと個別採否はsecondary-81-decisions.json/csv。別表記36件は公式/統計の元名称を保持し、同一区・丁目範囲・候補の一意性を個別確認した文字上の対応。現行町域の形状一致を認証したものではありません。

白川台以外の町名行欠落は今回の表セル抽出比較では検出なし。読み修正0、既存丁目範囲修正0、新規丁目7。上祇園町・下祇園町の抽出空白2件と、住居表示状況の複合注記21件を復元。全レコードの原票セルをpdf-cell-audit.jsonに収録。

JSON参照、区別・全市件数、TopoJSON弧参照と輪の閉鎖にエラー0。名称欄欠損警告3件は元CODHに存在する名称なし区画であり保持。自己交差・隣接重複・隙間のGIS位相検査、全件画像目視は未実施。境界は原ファイルから変更せず、同一IDの複数形状を保持。

新設のみずき台（2023-06-01）・山の街（2024-06-26）は公式の変更履歴を参照し、2020年形状を推測割当せず保持。字区画・丁目省略区画も保持し、丁目ごとに同じ形状を複製していません。その他16件は公式一覧にはあるもののCODHに完全対応が確認できず残置。追加の区域図・告示を用いた空間照合が必要です。

神戸市ウェブサイト利用規約（2017-07-01、政府標準利用規約2.0準拠）は出典・加工表示等の条件で複製や公衆送信、商用利用を認め、CC BY 4.0互換と記載。町名一覧/住居表示資料に別条件表示を確認せず、一般規約を根拠として記録。第三者権利・個別条件の除外は規約どおり。CODHはCC BY4.0。出典と加工表示をREADME/ライセンスメモに記載。

全20ページの目視校正と32件の空間対応は残課題です。Kussoon V2への本接続では「2020統計境界」と「現行公式町名」を別属性として利用し、学習対象除外フラグと境界未対応状態を尊重してください。GitHub、既存サイト、PRは変更していません。
'''
(R/'audit/validation-report.md').write_text(report)
(R/'README.md').write_text('# 神戸市9区 V2データ 修正版\n\n調査基準2026-11-15。全件画像目視未完了・境界未対応32件のためレビュー継続版です。\n\n'+report+'\n再構築：python scripts/build.py → python tools/finalize_revision.py → python tools/refresh_manifest.py → python tools/validate_package.py。PyMuPDFが必要。\n\n出典：「神戸市町名一覧表」（神戸市）https://www.city.kobe.lg.jp/a53715/kurashi/registration/jukyo/ichiran.html を加工して作成。\n「国勢調査町丁・字等別境界データセット」（CODH作成）「令和2年国勢調査町丁・字等別境界データ」（e-Stat）を加工 doi:10.20676/00000450\n')
