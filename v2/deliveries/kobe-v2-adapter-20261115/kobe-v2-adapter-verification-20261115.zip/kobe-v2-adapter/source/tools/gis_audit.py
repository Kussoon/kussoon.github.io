#!/usr/bin/env python3
"""pip install shapely pyproj pyshp; run from any directory. No source geometry mutation."""
import json,zipfile,tempfile,collections,hashlib,unicodedata,logging
from pathlib import Path
import shapefile,shapely
from shapely.geometry import shape,mapping,Polygon,MultiPolygon
from shapely.ops import transform,unary_union
from shapely.validation import explain_validity
from shapely.strtree import STRtree
from pyproj import Transformer
R=Path(__file__).resolve().parents[1]; O=R/'audit/gis';O.mkdir(exist_ok=True)
def save(p,x): (O/p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def load(p):return json.loads((R/p).read_text())
proj=Transformer.from_crs('EPSG:4612','EPSG:2447',always_xy=True).transform
# Source CODH metadata explicitly points to datum=2000. Official shape has no PRJ;
# JGD2000 lon/lat is ASSUMED for diagnostic overlay, not surveyed identity.
def topo_geom(g,t):
 def arc(i):
  a=t['arcs'][i if i>=0 else ~i];tr=t.get('transform')
  if tr:
   x=y=0;b=[]
   for dx,dy in a:x+=dx;y+=dy;b.append([x*tr['scale'][0]+tr['translate'][0],y*tr['scale'][1]+tr['translate'][1]])
   a=b
  return list(reversed(a)) if i<0 else a
 def ring(ids):
  p=[]
  for i in ids:
   a=arc(i);p+=a if not p else a[1:]
  return p
 if g['type']=='Polygon':return Polygon(ring(g['arcs'][0]),[ring(a) for a in g['arcs'][1:]])
 if g['type']=='MultiPolygon':return MultiPolygon([Polygon(ring(p[0]),[ring(a) for a in p[1:]]) for p in g['arcs']])
 raise ValueError(g['type'])
records=[];safe=[];ward_city={};validity=[]
for code in ['28101','28102','28105','28106','28107','28108','28109','28110','28111']:
 t=load(f'wards/{code}/boundary_2020.topojson');fc=[]
 for ix,g in enumerate(t['objects']['town']['geometries']):
  p=g.get('properties') or {}; geom=topo_geom(g,t);metric=transform(proj,geom)
  rec={'ward_code':code,'geometry_index':ix,'stat_area_id':str(p.get('KEY_CODE')),'name':p.get('S_NAME'),'bbox':list(geom.bounds),'area_m2':metric.area,'valid':geom.is_valid,'validity_reason':explain_validity(geom),'geometry_type':geom.geom_type}
  records.append(rec);validity.append(rec);safe.append(metric if metric.is_valid else shapely.make_valid(metric))
  fc.append({'type':'Feature','id':f'{code}:{ix}','properties':rec,'geometry':mapping(geom)})
 city=[topo_geom(g,t) for g in t['objects']['city']['geometries']];ward_city[code]=unary_union([transform(proj,g) for g in city])
 (O/f'{code}-inspection.geojson').write_text(json.dumps({'type':'FeatureCollection','crs':{'type':'name','properties':{'name':'EPSG:4612'}},'features':fc},ensure_ascii=False))
save('feature-validity.json',validity)
tree=STRtree(safe);overlaps=[];dups=[]
for i,a in enumerate(safe):
 for j in tree.query(a,predicate='intersects'):
  j=int(j)
  if j<=i:continue
  b=safe[j]
  if a.equals(b):dups.append({'a':records[i],'b':records[j]})
  area=a.intersection(b).area
  if area>1:overlaps.append({'a_id':records[i]['stat_area_id'],'b_id':records[j]['stat_area_id'],'a_ward':records[i]['ward_code'],'b_ward':records[j]['ward_code'],'area_m2':area})
save('overlap-candidates-over-1m2.json',overlaps);save('duplicate-geometries.json',dups)
coverage=[]
for code,city in ward_city.items():
 gs=[g for g,r in zip(safe,records) if r['ward_code']==code];u=unary_union(gs)
 c=city if city.is_valid else shapely.make_valid(city)
 gap=c.difference(u);extra=u.difference(c)
 coverage.append({'ward_code':code,'town_union_area_m2':u.area,'codh_city_area_m2':c.area,'gap_within_source_city_m2':gap.area,'outside_source_city_m2':extra.area,'gap_polygon_count':len(getattr(gap,'geoms',[gap])) if not gap.is_empty else 0,'interpretation':'同一CODH内の集約cityとの比較。水面も含む。独立した行政界との照合ではない。'})
save('coverage-vs-source-city.json',coverage)
# Independent publishing source, but link codes and labels indicate a shared statistical lineage.
with tempfile.TemporaryDirectory() as tmp:
 with zipfile.ZipFile(R/'sources/kobe-official-boundaries.zip') as z:z.extractall(tmp)
 shp=shapefile.Reader(str(next(Path(tmp).glob('*.shp'))),encoding='cp932')
 official=[]
 for i,sr in enumerate(shp.iterShapeRecords()):
  p=sr.record.as_dict();g=shape(sr.shape.__geo_interface__);m=transform(proj,g)
  official.append((p,m if m.is_valid else shapely.make_valid(m)))
stat_by_id=collections.defaultdict(list)
for r,g in zip(records,safe):stat_by_id[r['stat_area_id']].append(g)
towns={x['town_id']:x for x in load('city/kobe-town-index.json')['records']}
def norm(x):return ''.join(c for c in unicodedata.normalize('NFKC',x) if not (0xE0100<=ord(c)<=0xE01EF)).replace(' ','')
cases=[]
for x in load('sources/remaining-32-evidence-original.json'):
 d=dict(x);sid=x['source_id'];code=x['ward_code'];name=norm(x['name']);oc=[];stats=[]
 if x['side']=='official_town':
  oc=[(p,g) for p,g in official if p['区名']==x['ward_name'] and (norm(p['大字_町'])==name or (name=='妙法寺' and norm(p['大字_町']).startswith('妙法寺字')))]
  for p,g in oc:stats.extend(stat_by_id[p['リンクコ']])
 else:
  oc=[(p,g) for p,g in official if p['リンクコ']==sid];stats=stat_by_id.get(sid,[])
 d['official_gis_labels']=[{'link_code':p['リンクコ'],'name':p['大字_町'],'ward':p['区名']} for p,g in oc]
 d['codh_geometry_parts_tested']=len(stats);d['official_geometry_parts_tested']=len(oc)
 d['spatial_metrics']=None
 if stats and oc:
  a=unary_union(stats);b=unary_union([g for p,g in oc]);i=a.intersection(b).area
  d['spatial_metrics']={'codh_area_m2':a.area,'official_area_m2':b.area,'intersection_m2':i,'intersection_over_codh':i/a.area if a.area else None,'intersection_over_official':i/b.area if b.area else None,'symmetric_difference_m2':a.symmetric_difference(b).area,'hausdorff_m':a.hausdorff_distance(b),'bbox_projected':list(a.bounds)}
  d['decision']='部分対応';d['decision_reason']='公式GISの名称付き区画と統計区画を空間比較。親町/丁目の完全一致は未証明。共通の統計由来を示すリンクコードのため独立した法定町界証明とは扱わない。'
 elif x['name'] in ['みずき台','山の街']:
  d['decision']='時点差による未対応';d['decision_reason']='公式の新設日を確認。2020統計形状には割当しない。'
 else:
  d['decision']='名称・階層のみ確認';d['decision_reason']='公式町名一覧等で存在を確認。公式GISに同名の対象区域がなく、類似町名を流用しない。'
 d['geometry_relation_verified']=False;d['official_gis_source']='https://catalog.city.kobe.lg.jp/dataset/boundary-town-chome-oaza';d['coordinate_caveat']='公式shapeにPRJなし。経緯度と判断しJGD2000を仮置き。座標系確認まで精密一致判定不可。'
 cases.append(d)
save('remaining-32-decisions.json',cases)
summary={'library_versions':{'shapely':shapely.__version__},'source_crs':'CODH geographic JGD2000 (EPSG:4612), metadata datum=2000','metric_crs':'EPSG:2447 JGD2000 / Japan Plane Rectangular CS V','official_crs':'no PRJ; assumed same geographic datum for diagnostic only','feature_count':len(records),'statistical_id_count':len(stat_by_id),'invalid_feature_count':sum(not r['valid'] for r in records),'self_intersection_count':sum('self-intersection' in r['validity_reason'].lower() for r in records),'duplicate_geometry_pair_count':len(dups),'overlap_pair_count_over_1m2':len(overlaps),'within_ward_overlap_pairs':sum(x['a_ward']==x['b_ward'] for x in overlaps),'cross_ward_overlap_pairs':sum(x['a_ward']!=x['b_ward'] for x in overlaps),'official_shape_feature_count':len(official),'case_decisions':dict(collections.Counter(x['decision'] for x in cases)),'source_geometry_mutation':False,'repair_policy':'make_valid is used only in memory for diagnostic intersection/union when a geometry is invalid; exported inspection GeoJSON preserves original coordinates.','coverage':coverage}
save('summary.json',summary);print(json.dumps(summary,ensure_ascii=False,indent=2))
