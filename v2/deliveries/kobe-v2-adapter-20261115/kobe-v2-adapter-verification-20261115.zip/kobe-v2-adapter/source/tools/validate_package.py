#!/usr/bin/env python3
"""Validate package JSON references, counts, duplicate statistical IDs, and TopoJSON arcs."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
wards=[('28101','東灘区'),('28102','灘区'),('28105','兵庫区'),('28106','長田区'),('28107','須磨区'),('28108','垂水区'),('28109','北区'),('28110','中央区'),('28111','西区')]
errors=[]; warnings=[]; totals={'towns':0,'chome':0,'statistical_areas':0,'boundary_features':0,'topology_arcs':0}
for p in ROOT.rglob('*.json'):
 try: json.loads(p.read_text(encoding='utf-8'))
 except Exception as exc: errors.append(f'{p.relative_to(ROOT)}: invalid JSON: {exc}')
def j(path): return json.loads(path.read_text(encoding='utf-8'))
def arc_ids(refs):
 if isinstance(refs,int): return [refs]
 if isinstance(refs,list):
  out=[]
  for x in refs: out.extend(arc_ids(x))
  return out
 return []
def geom_rings(g):
 typ=g.get('type'); a=g.get('arcs')
 if typ=='Polygon':return a or []
 if typ=='MultiPolygon':return [r for poly in (a or []) for r in poly]
 return []
def validate_topo(path,ward):
 t=j(path)
 if t.get('type')!='Topology': errors.append(f'{ward}: Topology type missing');return 0,0
 arcs=t.get('arcs',[]); nfeatures=0; ids=[]
 for i,arc in enumerate(arcs):
  if len(arc)<2 or any(not isinstance(pt,list) or len(pt)<2 for pt in arc): errors.append(f'{ward}: malformed arc {i}')
 for oname,obj in t.get('objects',{}).items():
  gs=obj.get('geometries',[]) if obj.get('type')=='GeometryCollection' else [obj]
  for g in gs:
   props=g.get('properties') or {}; key=props.get('KEY_CODE')
   refs=arc_ids(g.get('arcs'))
   for ref in refs:
    ix=ref if ref>=0 else ~ref
    if ix<0 or ix>=len(arcs): errors.append(f'{ward}: invalid arc reference {ref}')
   if oname=='town' and key:
    nfeatures+=1;ids.append(str(key))
    if not props.get('S_NAME'): warnings.append(f'{ward}: {key} has no S_NAME (retained as unmatched statistical area)')
    if str(key)[:5]!=ward: errors.append(f'{ward}: key prefix mismatch {key}')
    if g.get('type') not in ('Polygon','MultiPolygon') or not refs: errors.append(f'{ward}: invalid polygon geometry {key}')
    tr=t.get('transform') or {'scale':[1,1],'translate':[0,0]}
    def decoded_arc(index):
     rev=index<0; ix=index if index>=0 else ~index; raw=arcs[ix]; x=y=0; pts=[]
     for dx,dy,*rest in raw:
      
      if t.get('transform'):
       x+=dx;y+=dy;pts.append([x*tr['scale'][0]+tr['translate'][0],y*tr['scale'][1]+tr['translate'][1]])
      else: pts.append([dx,dy])
     return list(reversed(pts)) if rev else pts
    for ring in geom_rings(g):
     pts=[]
     for ref in ring:
      seg=decoded_arc(ref);pts.extend(seg if not pts else seg[1:])
     if len(pts)<4 or pts[0]!=pts[-1]: errors.append(f'{ward}: open or short ring {key}')
 return nfeatures,len(arcs)
for code,name in wards:
 wd=ROOT/'wards'/code
 town=j(wd/'town-index.json')['records']; ch=j(wd/'chome-index.json')['records']; stats=j(wd/'statistical-areas-index.json')['records']; cw=j(wd/'crosswalk.json')['records']
 topo_count,arc_count=validate_topo(wd/'boundary_2020.topojson',code)
 if topo_count!=sum(x['part_count'] for x in stats): errors.append(f'{code}: TopoJSON boundary part count {topo_count} != indexed parts')
 if len({x['stat_area_id'] for x in stats})!=len(stats): errors.append(f'{code}: duplicate area ids in grouped statistical index')
 if len(cw)!=len(stats): errors.append(f'{code}: crosswalk count mismatch')
 town_ids={x['town_id'] for x in town}
 if len(town_ids)!=len(town):errors.append(f'{code}: duplicate official town IDs')
 if any(x['town_id'] not in town_ids for x in ch):errors.append(f'{code}: chome references unknown town')
 if any(not x.get('town_reading') for x in town):errors.append(f'{code}: missing reading')
 if any(any(tid not in town_ids for tid in x.get('official_town_ids',[])) for x in cw):errors.append(f'{code}: crosswalk references unknown official town')
 totals['towns']+=len(town);totals['chome']+=len(ch);totals['statistical_areas']+=len(stats);totals['boundary_features']+=topo_count;totals['topology_arcs']+=arc_count
alltown=j(ROOT/'city/kobe-town-index.json')['records'];allch=j(ROOT/'city/kobe-chome-index.json')['records'];summary=j(ROOT/'city/kobe-summary.json')
if len(alltown)!=totals['towns']:errors.append('city town index mismatch')
if len(allch)!=totals['chome']:errors.append('city chome index mismatch')
if sum(x['official_town_count'] for x in summary['wards'])!=totals['towns']:errors.append('summary town count mismatch')
if sum(x['chome_expanded_entry_count'] for x in summary['wards'])!=totals['chome']:errors.append('summary chome count mismatch')
if sum(x['statistical_area_count'] for x in summary['wards'])!=totals['statistical_areas']:errors.append('summary statistical count mismatch')
print(json.dumps({'totals':totals,'warnings':warnings,'errors':errors},ensure_ascii=False,indent=2))
sys.exit(1 if errors else 0)
