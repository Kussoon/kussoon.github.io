#!/usr/bin/env python3
"""Refresh city summary and file hash manifest after rebuilding indexes."""
import json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
summary=json.loads((ROOT/'audit/ward-summary.json').read_text(encoding='utf-8'))
summary.update({'city_name':'神戸市','research_cutoff':'2026-11-15','count_definitions':{
 'official_town_count':'公式PDFの町名行。重複町名でも別の丁目範囲等があれば別行として数える。',
 'chome_expanded_entry_count':'丁目範囲を丁目ごとに展開。丁目欄が空欄の町名は1件として含める。',
 'statistical_area_count':'CODH TopoJSON objects.town 内の一意なKEY_CODE数。複数Polygonに分かれる区画はID単位で1件とし、geometry_partsで全形状を参照する。',
 'unresolved_count':'公式町名側未対応 + 統計区画側未対応。検証した別表記対応と学習対象外の水面・名称なしは除く。両側で同一問題を数える場合がある。'}})
(ROOT/'city/kobe-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
dups=json.loads((ROOT/'audit/city-duplicate-check.json').read_text(encoding='utf-8'))
parts=json.loads((ROOT/'audit/multipart-statistical-ids.json').read_text(encoding='utf-8'))
(ROOT/'audit/duplicate-check.json').write_text(json.dumps({'duplicate_town_name_groups':dups['duplicate_name_groups'],'multipart_statistical_ids':parts,'note':'同一統計区画IDの複数Polygonは統計区画数では1件として集約し、全パーツを参照保持。'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
files=[]
for f in sorted(ROOT.rglob('*')):
 if f.is_file() and f.name!='manifest.json':files.append({'path':f.relative_to(ROOT).as_posix(),'size_bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
manifest={'package':'Kussoon V2 Kobe 9 wards town and statistical boundary dataset','version':'1.2.0-final-audit','research_cutoff':'2026-11-15','city_code':'28100','ward_codes':['28101','28102','28105','28106','28107','28108','28109','28110','28111'],'files':files}
(ROOT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
