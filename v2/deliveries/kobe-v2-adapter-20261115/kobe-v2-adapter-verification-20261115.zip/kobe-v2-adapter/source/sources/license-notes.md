# 出典・ライセンス確認（2026-11-15）
神戸市ウェブサイト利用規約：https://www.city.kobe.lg.jp/documents/19135/20170630041802-1.pdf
同規約は、公開情報を条件に従い複製・公衆送信・翻案等に利用でき、商用利用も可能とする。出典記載と加工した旨の明記、第三者の権利尊重、個別法令や別ルール等の除外条件を定める。政府標準利用規約2.0準拠・CC BY4.0互換と記載。今回の町名一覧と住居表示資料に別ルールの表示は確認されなかったため一般規約を利用条件として記録。
出典表示例：「神戸市町名一覧表」（神戸市）https://www.city.kobe.lg.jp/a53715/kurashi/registration/jukyo/ichiran.html を加工して作成。
変更資料：https://www.city.kobe.lg.jp/a53715/kurashi/registration/jukyo/05_jisitiku.html
CODHライセンス：CC BY4.0 https://geoshape.ex.nii.ac.jp/ka/resource/
必要表示：「国勢調査町丁・字等別境界データセット」（CODH作成）「令和2年国勢調査町丁・字等別境界データ」（e-Stat）を加工 doi:10.20676/00000450
元境界は変更せず同梱。検索索引・対応表は本調査の加工物。現行町域の確定図ではない。

## 追加取得した神戸市GIS
出典：「市区・町丁目・大字境界」（神戸市）https://catalog.city.kobe.lg.jp/dataset/boundary-town-chome-oaza を加工して空間検査。カタログはCC表示。ポータル利用方針 https://data.city.kobe.lg.jp/policy/ の表示ライセンスのリンクは https://creativecommons.org/licenses/by/2.1/jp/legalcode （CC BY2.1日本）。出典表示を付して原ZIPを同梱。CODHのCC BY4.0と区別すること。
