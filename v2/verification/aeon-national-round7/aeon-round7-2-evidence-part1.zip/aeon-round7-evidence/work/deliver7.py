from collections import Counter,defaultdict
from pathlib import Path
import argparse,csv,hashlib
from zipfile import ZipFile
from plan7 import prepare
from official7 import capture
from address7 import review
from audit7 import nation,candidates,TANABE,KYOTO,STEM
from food7 import decisions,regi_index,FOOD,GMS,DUPE,ABSENT,HOLD,UNKNOWN
from tables7 import correction_tables,cumulative,persistent
from recover7 import recover
from tables6 import array,sheet_data
from assess6 import url_id
from compare import normalize
from finish700 import make_book
from build_results import csv_write
from run5 import js,write

def digest(path):
    return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()

def inputs(manifest):
    rows=[]
    for line in manifest.read_text().splitlines():
        expected,path=line.split('  ',1)
        p=Path(path)
        if not p.is_file():
            raise FileNotFoundError(path)
        sha=digest(p)
        assert sha==expected,(p,sha,expected)
        rows.append({'ファイル':p.name,'SHA256':sha,'照合':'一致'})
    return rows

def lots(master,addr,food,ops,new,prior,scope):
    groups=defaultdict(set)
    for m in master:
        op,pref,uid=m['系列分類'],m['都道府県'],m['全国統合ID']
        for k in (('全国','',''),('都道府県','',pref),('系列',op,''),('系列×都道府県',op,pref)):groups[k].add(uid)
    f={r['全国統合ID'] for r in food if r['第7回累計判定'] in (FOOD,GMS)}
    food_done={r['全国統合ID'] for r in food if r['第7回累計判定'] in (FOOD,GMS,ABSENT,DUPE)}
    normal={r['全国統合ID'] for r in master if r['掲載区分']=='通常候補'}
    visited={r['全国統合ID'] for r in new}
    fresh={r['全国統合ID'] for r in new if r['公式住所']}
    proof={r['全国統合ID'] for r in addr if r['公式住所原文']}
    count={r['全国統合ID'] for r in ops if r['営業判定'] not in ('未確認','未判定','要確認','不明')}
    sc={(r['系列'],r['都道府県']):r['第7回判定'] for r in scope}
    address=prior|fresh
    out=[]
    for (axis,op,pref),ids in sorted(groups.items()):
        n=len(ids); a=len(address&ids); ff=len(f&ids);fd=len(food_done&ids)
        out.append({'単位':axis,'系列':op,'都道府県':pref,'台帳行数':n,'通常候補':len(ids&normal),'前回住所確認':len(prior&ids),
            '第7回選定':len(visited&ids),'第7回住所確認':len(fresh&ids),'累計住所確認':a,'累計未確認':n-a,
            '住所確認率':f'{a/n:.1%}','証跡から住所原文を再掲できた行':len(proof&ids),
            '通常候補住所確認':len(ids&normal&address),'食品根拠あり':ff,'食品根拠率':f'{ff/n:.1%}',
            '適格性結論あり':fd,'適格性結論率':f'{fd/n:.1%}','適格性に結論なし':n-fd,
            '営業判定あり':len(count&ids),'公式一覧監査':sc.get((op,pref),'')})
    c=out[0];assert c['単位']=='全国' and c['台帳行数']==4701
    for level in ('都道府県','系列','系列×都道府県'):
        for key,v in c.items():
            if isinstance(v,int):assert sum(x[key] for x in out if x['単位']==level)==v,(key,level)
    return out

def trial(master,targets,new,rev):
    assert len(targets)==3
    carry={TANABE:'対象外',KYOTO:'対象外'}
    cats={'通常候補':'通常掲載','除外':'対象外','履歴・休業・予定':'履歴','要確認':'参考・保留'}
    before=defaultdict(Counter);after=defaultdict(Counter);units=defaultdict(Counter)
    def keys(pref,op):
        return (('全国','',''),('都道府県','',pref),('系列',op,''),('系列×都道府県',op,pref))
    def apply(t,op,pref,k):
        for x in keys(pref,op):t[x][k]+=1
    db={r['全国統合ID']:r for r in new}
    staging=[]
    for m in master:
        uid=m['全国統合ID'];p=m['都道府県'];op=m['系列分類']; b=cats.get(m['掲載区分'],'参考・保留')
        apply(before,op,p,b)
        op2=op
        a=carry.get(uid,b)
        apply(after,op2,p,a)
        if a!=b or op2!=op:
            staging.append({'全国統合ID':uid,'店舗名':m['店舗名'],'都道府県':p,'試算前系列':op,'試算後系列':op2,
                            '試算前掲載区分':b,'試算後掲載区分':a,'既存対応ID':db[uid].get('既存対応候補ID',''),
                            '根拠URL':db[uid]['住所根拠URL']})
    for r in targets:apply(after,r['系列'],r['都道府県'],'新規追加')
    base_keys={r['候補キー'] for r in targets}
    for r in rev:
        if r['第7回採否案']=='新規掲載' and r['既往候補キー'] not in base_keys:apply(units,r['系列'],r['都道府県'],'新規追加')
    out=[]
    for k in sorted(before.keys()|after.keys()|units.keys()):
        axis,op,pref=k
        row={'単位':axis,'系列':op,'都道府県':pref}
        for t in cats.values():
            row['現行'+t]=before[k][t];row['試算'+t]=after[k][t]
        row['採用案3店を加えた新規']=after[k]['新規追加']
        row['試算の公開対象店舗数']=after[k]['通常掲載']+after[k]['新規追加']
        row['追加審査後に反映可能な逆引き新規']=units[k]['新規追加']
        row['逆引き案も採用する場合']=row['試算の公開対象店舗数']+units[k]['新規追加']
        out.append(row)
    assert out[0]['現行通常掲載']==4658
    for axis in ('都道府県','系列','系列×都道府県'):
        for k,v in out[0].items():
            if isinstance(v,int):assert v==sum(x[k] for x in out if x['単位']==axis),(axis,k)
    return out,staging

def acquisition(work,r4,src):
    out=[]
    for p in sorted(work.glob('*-log.json')):
        stage=p.name.removesuffix('-log.json')
        folder='web' if stage=='http' else stage
        for r in js(p):
            tags=r.get('用途','')
            if isinstance(tags,list):tags=' ／ '.join(tags)
            if r.get('file'):assert digest(work/folder/r['file'])==r['sha256']
            out.append({'区分':'第7回取得','ログ':p.name}|r|{'用途':tags})
    for row in js(r4/'roster-pages.json'):
        out.append({'区分':'保存証跡の参照','ログ':'第4回roster-pages.json','url':row['request'],'final':row['final'],
                    'status':row['status'],'fetched_at':row['fetched_at'],'sha256':row['sha256'],'用途':row['series']+'・'+row['pref']})
    for uid,row in js(work/'address-indexed.json').items():
        out.append({'区分':'公開索引で公表内容を確認（原文ハッシュなし）','全国統合ID':uid,'url':row['URL'],
                    '確認日JST':row['照合日'],'用途':row['同一性']})
    for fn,k in (('food-indexed.json','所見'),('address-retained.json','所見')):
        for uid,row in js(work/fn).items():
            out.append({'区分':'索引または保存資料の補足採録','全国統合ID':uid,'url':row['URL'],
                        '確認日JST':'2026-11-24','用途':row[k]})
    return out

def assemble(a):
    a.out.mkdir(parents=True,exist_ok=True)
    before=inputs(a.work/'inputs.sha256')
    master,excluded,confirmed,history,picks=prepare(a.master,a.r4,a.r5e,a.r6r,a.r6e,a.work)
    src=capture(a.work)
    new,batches,cards=review(master,excluded,history,picks,a.r4,a.work,src)
    recovered=recover(master,a.r4,a.work,src)
    food,old_gaps,food_updates=decisions(master,excluded,history,[],new,a.r4,a.r5e,a.r6r,a.r6e,a.master,a.work,src,cards,recovered)
    scope,scope_cards=nation(a.r6r,master,new,cards,src,js(a.r4/'enriched-roster.json'))
    candidate,sight,restored,targets,reverse,changes=candidates(a.r6r,master,src,cards,regi_index(src)[0])
    cases,older,future=persistent(a.r6r,master,src)
    with (a.r4/'delivery/prior-followup-01.csv').open(encoding='utf-8-sig') as f:
        older_r4=list(csv.DictReader(f))
    ca,ch,focus,ca7,cach=correction_tables(a.r6r,master,new,food_updates,cases)
    chosen={r['全国統合ID'] for r in new}
    assert len(chosen)==341 and not chosen&excluded and len(chosen|excluded)==4701
    urls=[url_id(r['個店公式URL']) for r in new if r['個店公式URL']]
    assert len(urls)==len(set(urls)) and not set(urls)&{url_id(r['個店公式URL']) for r in history if r['個店公式URL']}
    confirm=confirmed|{r['全国統合ID'] for r in new if r['公式住所']}
    address,ops=cumulative(master,a.master,confirm,history,new,food,a.r4,a.r5r,recovered,cases)
    progress=lots(master,address,food,ops,new,confirmed,scope)
    scenario,updates=trial(master,targets,new,reverse)
    logs=acquisition(a.work,a.r4,src)
    eligible={r['全国統合ID']:r for r in food}
    for r in new:
        f=eligible[r['全国統合ID']]
        r['掲載適格性・最終']=f['第7回累計判定'];r['最終食品根拠URL']=f['根拠URL']
        r['最終食品根拠・保留理由']=f['根拠または未確認理由']
    groups=[r for r in progress if r['単位']=='全国']
    a7=a.out
    books={
      '01-残り341行公式照合':[('選定341行',new),('8バッチ検証',batches)],
      '02-全国4701行累計公式照合':[('全国4701行',address),('旧回判定継承・住所原文欠落',[r for r in address if not r['公式住所原文']])],
      '03-掲載適格性と営業状況':[('全4701行の掲載適格性',food),('全4701行の営業判定',ops),('前回未判定800行',old_gaps),
            ('第7回追加の食品根拠等',food_updates),('掲載適格性の未確定行',[r for r in food if r['第7回累計判定'] in (HOLD,UNKNOWN)]),
            ('営業根拠が不足する行',[r for r in ops if r['営業判定'] in ('未確認','未判定','要確認','不明')])],
      '04-公式一覧全国752組':[('全国752組',scope),('前回保留・全国範囲未判定',[r for r in scope if r['第6回判定'] in ('一部保留','台帳行なし・公式全域未判定')]),
            ('保留県の店舗カード個別比較',scope_cards),('逆引き18店舗',reverse),('全国範囲の継承証跡',sheet_data(a.r6r,STEM,'運営会社の全国範囲根拠'))],
      '05-掲載漏れ重複と最終採否案':[('採用案3店舗',targets),('全159キーと採否案',candidate),('全290検出履歴',sight),
            ('第5回修復の16判定',restored),('採否案の変更履歴',changes),('逆引き18店舗',reverse),
            ('その他の新規掲載提案',[r for r in reverse if r['第7回採否案']=='新規掲載' and r['既往候補キー'] not in {x['候補キー'] for x in targets}]),
            ('既存ID重複・区分整理案',updates)],
      '06-累計修正候補と反映審査':[('全管理キーの最終判断',ca),('267重点審査',focus),('候補判断の累計履歴',ch),
            ('第7回の履歴追記',ca7),('第7回変更の管理キー',cach),('住所表記差', [r for r in ca if r['反映審査結果']=='表記差のみ・現行値維持']),
            ('住所原文の採録候補',[r for r in ca if r['反映審査結果']=='公式住所原文の採録'])],
      '07-最終未解決事項と基準日後':[('個別案件の追加調査',cases),('過去の根拠と判断',older),('第4回引継ぎ原文',older_r4),('基準日後の事象',future),
            ('全国一覧の残る保留',[r for r in scope if r['第7回判定']=='一部保留']),
            ('修正審査保留',[r for r in ca if r['反映審査結果']=='判断保留'])],
      '08-全国都道府県系列の進捗と試算':[(k,[r for r in progress if r['単位']==k]) for k in ('全国','都道府県','系列','系列×都道府県')]
           + [('Ver1.2試算',scenario),('試算で区分変更した既存行',updates)],
    }
    for n,parts in books.items():
        if not a.no_xlsx:make_book(a7/(n+'.xlsx'),[(s,array(d)) for s,d in parts])
    qa=a.work/'qa';qa.mkdir(exist_ok=True)
    raws={'round7-341':new,'national-4701':address,'eligibility-4701':food,'operation-4701':ops,
          'national-752':scope,'correction-latest':ca,'candidate-assessments':candidate,'candidate-changes':changes,
          'correction-changes':cach,'batch-validation':batches,'acquisition-log':logs,'final-progress':progress,'scenario':scenario,
          'input-sha256-verification':before}
    for k,v in raws.items():
        csv_write(qa/(k+'.csv'),array(v))
    if not a.no_xlsx:
        make_book(qa/'公式情報取得ログ.xlsx',[('取得ログと索引',array(logs))])
    assert before==inputs(a.work/'inputs.sha256')
    summary={'集計':groups[0],'監査':dict(Counter(r['第7回判定'] for r in scope)),
          '食品区分':dict(Counter(r['第7回累計判定'] for r in food)),
          '旧800行のうち資料で再判定':len(food_updates),'旧800行の四一覧にない行':sum(r['800未判定だが既報の4一覧に表示なし'] for r in old_gaps),
          '旧800行のうち四一覧重複':sum(' ／ ' in r['持越し表'] for r in old_gaps),
          '旧800行のうちイオンリテール':sum(r['系列分類']=='イオンリテール' for r in old_gaps),
          'イオンリテール食品根拠追加':sum(r['系列分類']=='イオンリテール' and r['第7回累計判定'] in (FOOD,GMS) for r in food_updates),
          '採否案':dict(Counter(r['第7回採否案'] for r in candidate)),
          '逆引き18':dict(Counter(r['第7回採否案'] for r in reverse)),
          '第7回修正履歴追加':len(ca7),'累計修正履歴':len(ch),'管理キー':len(ca),'重点審査キー':len(focus),
          '267重点審査結果':dict(Counter(r['反映審査結果'] for r in focus)),
          '営業':dict(Counter(r['営業判定'] for r in ops)),
          '住所原文補完の既選定件数':sum(r['確認段階']=='第7回既選定再調査（累計への加算なし）' for r in address),
          '既存ID選定重複':0,'新規個店割当重複':0,'候補復元継承':len(restored),
          '検出履歴':len(sight),'入力一致':len(before),'全4,701行を網羅':True,
          'バッチ':batches,'試算全国':scenario[0]}
    write(qa/'validation.json',summary)
    write(a.out/'集計と検証.json',summary)
    print(summary)
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for n in ('master','r4','r5r','r5e','r6r','r6e','work','out'):p.add_argument(n,type=Path)
    p.add_argument('--no-xlsx',action='store_true')
    assemble(p.parse_args())
