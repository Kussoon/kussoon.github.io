from collections import defaultdict
from pathlib import Path
import csv
from compare import normalize,nf
from assess6 import EQUAL
from address_cases import address_check
from evaluate700 import take_detail,compare_name
from index700 import Index,store_key
from fetch import cleanurl,host,text
from analyse import document
from eligibility6 import food_brand,page_text
from run5 import js,write
from address7 import label

def gap_requests(master,r4,work):
    ix=Index(js(r4/'enriched-roster.json'))
    r=[r for r in csv.DictReader((work/'qa/national-4701.csv').open(encoding='utf-8-sig')) if not r['公式住所原文']]
    f=[r for r in csv.DictReader((work/'qa/eligibility-4701.csv').open(encoding='utf-8-sig')) if r['第7回累計判定'] in ('根拠不足による未確認','専門業態・一般利用条件等による判断保留')]
    by_id={r['全国統合ID']:r for r in master}
    urls={}; roles={}
    for uid in dict.fromkeys(x['全国統合ID'] for x in r+f):
        m=by_id[uid];op=m['系列分類'];name=m['店舗名']
        if not (op in {'カスミ','ダイエー・イオンフードスタイル','ビッグ・エー','イオン琉球','イオン北海道','イオン東北','イオン九州','マックスバリュ東海','まいばすけっと'} or m['公式店舗URL']):continue
        choices=[]
        for c in ix.lookup(m):
            if c['kind']!='company' or c['pref']!=m['都道府県']:continue
            if store_key(c['name_compare'],op)!=store_key(name,op) and label(c['name_compare'])!=label(name):continue
            choices+=c.get('detail_links',[])
        if m['公式店舗URL']:choices.insert(0,m['公式店舗URL'])
        choices=[cleanurl(u) for u in dict.fromkeys(choices) if host(u) and host(u)!='aeon.com']
        if not choices:continue
        roles[uid]=choices[:2]
        for u in choices[:2]:urls.setdefault(u,[]).append(uid)
    write(work/'restore-requests.json',urls)
    write(work/'restore-map.json',roles)
    print(len(roles),len(urls))

def recover(master,r4,work,src):
    if not (work/'restore-map.json').exists():return {}
    ix=Index(js(r4/'enriched-roster.json'))
    routes=js(work/'restore-map.json')
    out={}
    for m in master:
        uid=m['全国統合ID']
        for u in routes.get(uid,[]):
            if u not in src:continue
            a,p=src[u]
            if a['status']!=200:continue
            f=take_detail(m,a,p.read_bytes(),ix.lookup(m))
            if not f or not f['address'] or address_check(m,f['address']) not in EQUAL or compare_name(m,f['name']) not in ('原文一致','表記差のみ'):continue
            s=label(text(document(p.read_bytes())))
            op=m['系列分類'];nm=f['name']
            brand=food_brand(op,nm) or op=='ダイエー・イオンフードスタイル' and any(x in label(nm).lower() for x in ('kohyo','foodstyle','グルメシティ','ダイエー','foodium','maxvalu'))
            if any(x in label(nm) for x in ('ファミリーマート','LABO','ショッピングセンター','専門店街','ショッピングプラザ')):brand=False
            gms=any(mark in s for mark in ('食品売場','食品の営業時間','食料品売場','食品フロア','生鮮食品売場'))
            # The explicit wording must be store-local, excluding the facility title and menu-only extraction.
            out[uid]={'addr':f['address'],'name':nm,'url':f['url'],'stamp':a['fetched_at'],'sha':a['sha256'],
                      'food':'brand' if brand else 'gms' if gms else '',
                      'status':f.get('status','')}
            break
    for uid,row in js(work/'address-retained.json').items():
        u=cleanurl(row['URL']);a,p=src.get(u,({},None))
        s=label(page_text(p,a.get('content_type',''))) if p else ''
        if s:
            assert label(row['住所']) in s or label(row['住所']).replace('　','') in s,(uid,row['住所'])
        out[uid]={'addr':row['住所'],'name':row['公式店舗名'],'url':row['URL'],
                  'stamp':a.get('fetched_at',''),'sha':a.get('sha256',''),'food':row['食品'],
                  'status':'営業中','所見':row['所見']}
    return out

if __name__=='__main__':
    import sys
    from plan7 import prepare
    master,r4,r5e,r6r,r6e,w=map(Path,sys.argv[1:])
    rows,*_=prepare(master,r4,r5e,r6r,r6e,w)
    gap_requests(rows,r4,w)
