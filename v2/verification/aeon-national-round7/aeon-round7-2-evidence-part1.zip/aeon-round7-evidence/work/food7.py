"""Track all eligibility decisions by existing national ID, including the 800 prior gaps."""
import csv,io,re
from zipfile import ZipFile
from collections import defaultdict,Counter
from analyse import document
from compare import nf
from coverage import PREFS
from fetch import text,cleanurl
from assess6 import url_id
from eligibility6 import POS,NEG,earlier,recheck
from tables6 import sheet_data
from run5 import js
from address7 import label,SPL

REGI='https://www.regigo.jp/'
FAQ='https://www.regigo.jp/faq/'
GMS='総合スーパーの食品売場確認'
FOOD='食品スーパー業態として確認'
ABSENT='食品を取り扱わないため対象外'
DUPE='施設と食品核店舗・既存店舗の重複'
HOLD='専門業態・一般利用条件等による判断保留'
UNKNOWN='根拠不足による未確認'

def regi_index(src):
    log,p=src[REGI]
    p2=src[FAQ][1]
    assert '食品売場にて利用可能' in text(document(p2.read_bytes()))
    ix=defaultdict(list)
    for a in document(p.read_bytes()).xpath('//a[contains(concat(" ",normalize-space(@class)," ")," shopList_btn ")]'):
        name=' '.join(t.strip() for t in a.xpath('./text()') if t.strip())
        pref=[text(n) for n in a.xpath('ancestor::div[contains(concat(" ",normalize-space(@class)," ")," shopList_area_wrap ")][1]/preceding-sibling::p[contains(@class,"shopList_area")][1]') if text(n) in PREFS]
        if name and a.get('href') and len(pref)==1:
            ix[label(name).removesuffix('店'),pref[0]].append(a.get('href'))
    return ix,log

def category(status,root_name):
    if status=='公式の食品スーパー屋号':return FOOD
    if status=='食品売場・食品の根拠あり':return GMS
    if status==NEG:return HOLD
    return UNKNOWN

def decisions(master,excluded,history,fifth,new,r4,r5e,r6r,r6e,masterpath,work,src,region,recovered):
    by={r['全国統合ID']:r for r in master}
    first=excluded-{r['全国統合ID'] for r in history}
    old_comparable=earlier(masterpath,r4,master,first)
    prior_food={}
    for row in old_comparable:
        if row['判定'] in POS:
            prior_food[row['全国統合ID']]=(FOOD,row['根拠URL'],row['根拠要約'],row['取得日時UTC'],'第1〜3回')
    for row in history:
        status=row['食品スーパーの掲載適格性']
        if status in POS:
            prior_food[row['全国統合ID']]=(category(status,row['元店舗名']),row['食品根拠URL'] or row['住所根拠URL'],
               row['食品根拠'],row['住所確認日時UTC'],'第4〜6回')
        elif status==NEG:
            prior_food[row['全国統合ID']]=(HOLD,row['食品根拠URL'],row['食品根拠'],row['住所確認日時UTC'],'第5回対象外案')
    old_opinions=sheet_data(r6r,'05-未解決事項と掲載適格性','前回食品保留65件の再調査')
    for row in old_opinions:
        if row['第6回掲載適格性'] in POS:
            prior_food[row['全国統合ID']]=(GMS,row['根拠URL'],row['第6回根拠'],row['取得日時UTC'],'第6回再調査')
    for uid,url in {'AE-8154504F857E2B1E':'https://www.aeon-hokkaido.jp/aeon/shop/hiragishi/floorguide.html',
                    'AE-FD7E7C7B438FDFE3':'https://www.aeon-hokkaido.jp/aeon/shop/asahikawaekimae/floorguide.html',
                    'AE-9A4EFC381CF88D47':'https://www.aeon-kyushu.info/files/management_news/1993/pdf.pdf'}.items():
        prior_food[uid]=(GMS,url,'第5回の公式食品売場・核店舗の再調査','','第5回再調査')
    assert len(prior_food)==3901,len(prior_food)
    tracker=defaultdict(list)
    for s in ('第5回食品保留の残り','第6回食品判定保留','第1〜3回食品の保留','住所残件一覧'):
        for r in sheet_data(r6r,'07-第7回残件一覧・最終調査計画',s):
            tracker[r['全国統合ID']].append(s)
    assert set(tracker)<=by.keys()
    gaps=set(by)-prior_food.keys()
    assert len(gaps)==800
    reg,reglog=regi_index(src)
    company_links=defaultdict(set)
    for c in region:
        company_links[c['pref'],label(c['name_compare']).removesuffix('店')].update(url_id(u) for u in c['detail_links'])
    new_by={r['全国統合ID']:r for r in new}
    linked={r['全国統合ID']:r for r in history+new}
    candidates=defaultdict(int)
    for m in master:candidates[m['都道府県'],label(m['店舗名']).removesuffix('店')]+=1
    manual=js(work/'food-indexed.json') if (work/'food-indexed.json').exists() else {}
    output=[];unknown=[];updates=[]
    for m in master:
        uid=m['全国統合ID']; name=m['店舗名']; pref=m['都道府県'];op=m['系列分類']
        status,source,note,stamp,edition=prior_food.get(uid,(UNKNOWN,'','店舗固有の食品売場・運営会社業態を同定できる根拠が未確認','',''))
        original=status
        joint=''
        if uid in gaps:
            k=pref,label(name).removesuffix('店')
            urls=reg.get((k[1],pref),[])
            rr=linked.get(uid,{})
            known={url_id(u) for u in (m['公式店舗URL'],rr.get('個店公式URL')) if u}
            known|=company_links[k]
            good=[u for u in urls if url_id(u) in known]
            if urls and (good or len(urls)==1 and candidates[k]==1) and m['掲載区分']=='通常候補':
                status,source,note,stamp,edition=(GMS,REGI,'公式導入店舗に当該支店。公式FAQで食品売場での利用を明記。',
                                                reglog['fetched_at'],'第7回')
                joint=FAQ+' ／ '+(good or urls)[0]
            rec=recovered.get(uid,{})
            if rec.get('food') and status==UNKNOWN:
                status,source,note,stamp,edition=(FOOD if rec['food']=='brand' else GMS,rec['url'],
                     '同一名・同一住所の運営会社個店から食品スーパー業態または店舗の食品売場を確認。',rec['stamp'],'第7回')
            if uid in manual and status==UNKNOWN:
                item=manual[uid]
                status,source,note,stamp,edition=(item.get('判定',GMS),item['URL'],item['所見'],'','第7回')
            if uid in new_by:
                r=new_by[uid];cat=r['食品スーパーの掲載適格性']
                if r['系列分類']=='まいばすけっと' and cat in POS:
                    status,source,note,stamp,edition=(FOOD,r['食品根拠URL'] or r['住所根拠URL'],
                                 '運営会社公式の小型食品スーパー業態と店舗を確認。',r['住所確認日時UTC'],'第7回')
                if uid in SPL and r['公式住所'] and uid!='AE-612160AC0FB9C9D5':
                    status,source,note,stamp,edition=(DUPE if r.get('既存対応候補ID') else FOOD,r['住所根拠URL'],
                                 'ダイエーの運営会社個店で食品スーパー業態と店舗同一性を確認。',r['住所確認日時UTC'],'第7回')
        if uid=='AE-612160AC0FB9C9D5':
            status,source,note,stamp,edition=(ABSENT,'https://aeonmobile.jp/shoplist/funabashi/',
                    '運営会社公式の携帯通信専門店。施設内の食品スーパーは別行。','','第7回')
        if status==UNKNOWN:
            if 'LABO' in (name or '').upper() or 'ウエルシア' in (name or '') or 'ファミリーマートプラス' in (name or '') or m['掲載区分']=='要確認':
                status=HOLD;note='店舗の一般利用条件・業態・採否を確認する根拠が不足。'
            elif m['掲載区分']=='除外' and m['関連全国統合ID']:
                status=DUPE;note='既存台帳の除外指定・関連IDを保持。公式の核店舗を別に照合。'
            elif m['掲載区分']=='履歴・休業・予定':
                note='履歴・休業・予定行。基準日の食品売場の一般営業を確認できる資料が不足。'
        r={'全国統合ID':uid,'系列分類':op,'都道府県':pref,'店舗名':name,'掲載区分':m['掲載区分'],
           '第6回判定記録あり':uid in prior_food,'第6回引継ぎ分類':original,'第6回引継ぎ資料URL':prior_food.get(uid,('',''))[1],
           '第7回累計判定':status,'根拠URL':source,'補足資料URL':joint,'取得日時UTC':stamp,
           '根拠または未確認理由':note,'採用回':edition,'確認日JST':'2026-11-24' if edition=='第7回' else '', '持越し表':' ／ '.join(tracker.get(uid,[])),
           '既報の800未判定に該当':uid in gaps,'800未判定だが既報の4一覧に表示なし':uid in gaps and uid not in tracker}
        output.append(r)
        if uid in gaps:unknown.append(r)
        if uid in gaps and edition=='第7回':updates.append(r)
    assert len(output)==4701 and len(unknown)==800
    return output,unknown,updates
