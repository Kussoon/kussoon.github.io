from collections import Counter,defaultdict
from tables6 import sheet_data
from analyse import document
from eligibility6 import page_text
from address7 import label
from compare import normalize
from fetch import text,cleanurl
from index700 import store_key
from run5 import js

STEM='03-掲載漏れ重複と全国一覧監査'
RETAIL='イオンリテール'
NATION='https://recruit.aeon.info/digital/aboutus/business/1338/'
TOHOKU='https://www.aeon.info/news/release_28369/'
WEST='https://www.nishinihon.aeonretail.jp/pages/information'
BIG='https://www.aeonbig.co.jp/stores/'
KASUMI='https://www.kasumi.co.jp/tenpotop/area/tokyo/'
CHIBA='https://www.maruetsu.co.jp/store/shop_area/chiba-ken/'
ABSENT='公式一覧に基づき出店なしを確認'
COMPLETED='全件突合完了'
TANABE='AE-DF71F8365C4FCD13'
KYOTO='AE-C21921EE6375BF6B'
def plain(src,u):
    rec,p=src[cleanurl(u)]
    return label(page_text(p,rec.get('content_type','')))
def nation(r6r,master,new,cards,src,old_cards):
    scope=sheet_data(r6r,STEM,'全国752組の一覧監査')
    assert len(scope)==752 and len({(x['系列'],x['都道府県']) for x in scope})==752
    area=plain(src,NATION)
    assert '東北を除く' in area and all(x in area for x in ('本州','四国'))
    region_by=defaultdict(list)
    for c in cards:region_by[c['pref']].append(c)
    exact=defaultdict(list)
    for m in master:
        if m['系列分類']==RETAIL:
            exact[m['都道府県'],label(m['店舗名']).removesuffix('店')].append(m['全国統合ID'])
    out=[]; checks=[]
    for r in scope:
        op,pref,previous=r['系列'],r['都道府県'],r['第6回判定']
        verdict=previous; url=r['第6回根拠URL'] or r['逆引き根拠URL']
        note=r['第6回確認範囲・残る理由'] or r['逆引き備考']
        open_cards=[]
        if previous=='台帳行なし・公式全域未判定':
            assert op==RETAIL and pref in '北海道 青森県 岩手県 宮城県 秋田県 山形県 福島県 福岡県 佐賀県 長崎県 熊本県 大分県 宮崎県 鹿児島県 沖縄県'.split(),pref
            verdict=ABSENT;url=NATION+' ／ '+TOHOKU
            note='イオンリテールの食品スーパー範囲は本州（東北を除く）・四国。地域別事業会社の運営と区別して判定。'
        if previous=='一部保留' and op==RETAIL:
            direct=region_by[pref]
            saved=[c for c in old_cards if c.get('kind')=='company' and c.get('series')==RETAIL and c.get('pref')==pref]
            audited=direct or saved
            refs=' ／ '.join(dict.fromkeys(c['url'] for c in audited))
            url=refs or url
            for c in audited:
                key=label(c['name_compare']).removesuffix('店')
                ids=exact[pref,key]
                if len(ids)!=1:open_cards.append(c['name_compare'])
                checks.append({'系列':op,'都道府県':pref,'公式店舗カード':c['name_compare'],'対応ID':' ／ '.join(ids),
                               '判定':'対応確認' if len(ids)==1 else '施設・別名称・掲載候補等を個別審査',
                               '根拠URL':c['url'],'取得日時UTC':c['fetched_at']})
            current=[n for n in new if n['系列分類']==op and n['都道府県']==pref]
            assert current and all(n['公式住所'] for n in current)
            if audited and len(audited)==r['運営会社一覧カード'] and not open_cards:
                verdict=COMPLETED
                note=f'公式会社一覧の指名カード{len(audited)}件の全対応を確認。第7回住所残件{len(current)}件を補完。'
            else:
                note=f'第7回住所残件{len(current)}件を補完。公式カードの個別対応または最新全域取得を保留（地域一覧{len(direct)}件、旧証跡{len(saved)}件、名称完全一致を確認できないカード{len(open_cards)}件）。'
        if previous=='一部保留' and op=='マルエツ':
            note='千葉県一覧照合を引き継ぎ。初石店の旧公式URLはトップへ移動。閉店の運営会社告知原文を確保できず保留。'
        out.append(r|{'第7回判定':verdict,'第7回根拠URL':url,'第7回判定理由':note,
                      '第7回未解決カード':' ／ '.join(dict.fromkeys(open_cards))})
    assert sum(x['第7回判定']==ABSENT for x in out)==635
    return out,checks

def propose(r):
    v=r['継承後判定']
    if v.startswith('既存IDあり'):return '既存IDで掲載済み'
    if any(s in v for s in ('閉店・追加','建て替え','休業','後開店','一時閉店')):return '閉店・休業・予定の別管理'
    if any(s in v for s in ('施設名は追加不要','商業施設・追加不要')):return '商業施設・食品核店舗の重複'
    if '対象外' in v or '画面操作' in v:return '対象外'
    return '判断保留'

def candidates(r6r,master,src,regional,reg):
    ledger=sheet_data(r6r,STEM,'既往159候補')
    origin=sheet_data(r6r,STEM,'既往290件の検出履歴')
    restored=sheet_data(r6r,STEM,'第5回の16件判定復元')
    targets=sheet_data(r6r,STEM,'採用候補3店')
    reverse=sheet_data(r6r,STEM,'台帳にない系列県の表示')
    keyed={r['候補キー']:r for r in ledger}
    assert len(keyed)==159 and len(origin)==290 and len(restored)==16 and len(reverse)==18
    assert all(keyed[r['候補キー']]['継承後判定']!='要追加調査' for r in restored)
    adopt={x['候補キー']:x for x in targets}
    diff={}; checked=[]
    for r in reverse:
        op,pref,name=r['系列'],r['都道府県'],r['公式名']
        key=store_key(name,op)
        addr=r['公式住所']
        u=r['一覧URL']
        retail_addr={'イオン防府店':'山口県防府市中央町1-3','イオン光店':'山口県光市浅江木園1756-1'}
        if op==RETAIL:addr=retail_addr[name]
        same=[];near=[]
        for m in master:
            if m['都道府県']!=pref:continue
            a=normalize(addr or '')
            b=normalize(m['住所'] or '')
            mn=store_key(m['店舗名'],op)
            if m.get('公式店舗URL') and r['個店導線']==m['公式店舗URL'] or mn and key==mn:
                same.append(m)
            elif a and b and a==b:near.append(m)
        present=label(name) in plain(src,u) if cleanurl(u) in src else False
        if op==RETAIL:
            present=any(c['pref']==pref and label(c['name_compare'])==label(name) for c in regional)
        if same:
            judgment='既存IDで掲載済み' if all(m['系列分類']==op for m in same) else '既存IDの名称・住所・系列等の修正'
            note='公式URLまたは名称を都道府県・台帳全系列で再突合。属性を個別確認。'
        elif op=='イオン九州':
            judgment='対象外';note='会社公式のホームセンター業態。食品スーパーの追加対象外。'
        elif r['既往候補キー'] in adopt:
            judgment='新規掲載';note='第6回採用案を継承。店舗・業態・開店根拠を維持。'
        elif present and addr and not near and op in ('イオンビッグ','カスミ',RETAIL):
            judgment='新規掲載';note='運営会社公式一覧の食品小売店舗。台帳全系列の同県、名称、個店URL、正規化住所に既存対応なし。'
        else:
            judgment='判断保留';note='公式表示を確認。食品売場・既存同地番・速報値の適用には追加審査が必要。'
        food_url='https://www.aeon.com/store/イオン/'+name+'/shop_info/hours/' if op==RETAIL else ''
        if food_url and judgment=='新規掲載':
            note+=' 店舗別の公式食品売場営業時間と所在地を公開索引で確認。'
        joint=' ／ '.join(m['全国統合ID'] for m in same or near)
        entry=r|{'第7回公式住所・候補':addr,'第7回採否案':judgment,'第7回既存照合ID':joint,
                 '第7回根拠URL':u,'食品売場・住所の補足公式URL':food_url,'第7回理由':note,'現行一覧でカード名を確認':present,'照合日JST':'2026-11-24'}
        checked.append(entry)
        if r['既往候補キー'] not in adopt and judgment!='判断保留':
            diff[r['既往候補キー']]=entry
    output=[];changes=[]
    for r in ledger:
        k=r['候補キー']
        v=propose(r);u=r['採用した判定URL'] or r['補足根拠URL'] or r['補完個店URL'] or r['公式一覧URL']
        note=r['採用した判定理由'] or r['判断理由'] or '既往判定区分を維持。'
        if k in adopt:
            v='新規掲載';u=adopt[k]['営業根拠URL'];note='既往採用案を継承。'; 
        elif k in diff:
            d=diff[k];v=d['第7回採否案'];u=d['第7回根拠URL'];note=d['第7回理由']
            if v!=propose(r):
                changes.append({'候補キー':k,'旧判定':r['継承後判定'],'旧根拠URL':r['採用した判定URL'],
                   '旧判定日':r['採用した判定確認日'],'第7回採否案':v,'新根拠URL':u,'照合日':'2026-11-24','変更理由':note})
        output.append(r|{'第7回採否案':v,'第7回根拠URL':u,'食品売場・住所の補足公式URL':food_url,'第7回理由':note,'正式全国統合ID':''})
    return output,origin,restored,targets,checked,changes
