import argparse,hashlib
from pathlib import Path
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from fetch import Finder,host,cleanurl
from run5 import js,write

def receive(source,work,stage):
    cfg=js(source/'config.json')
    requests=js(work/(stage+'-requests.json'))
    # Each URL is an identified public source. Scope its redirects to the selected source domains.
    domains={host(url) for url in requests if url and host(url)!='aeon.com'}
    cfg['operators'].append(['公式補完',sorted(domains),[]])
    f=Finder(cfg,work/stage)
    groups=defaultdict(list)
    for url,tags in requests.items():
        if host(url)!='aeon.com':
            groups[host(url)].append((cleanurl(url),tags))
    def run(entries):
        for url,tags in entries:
            record,_=f.fetch(url)
            if record:
                record['用途']=tags
                print(record.get('status'),url,flush=True)
    with ThreadPoolExecutor(max_workers=14) as pool:
        list(pool.map(run,groups.values()))
    write(work/(stage+'-log.json'),list(f.cache.values()))
    write(work/(stage+'-robots.json'),[r for _,r in f.robots.values()])

def capture(work):
    set_={}
    for log in sorted(work.glob('*-log.json')):
        stage=log.name.removesuffix('-log.json')
        stage='web' if stage=='http' else stage
        for row in js(log):
            if row.get('file'):
                p=work/stage/row['file']
                assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],p
                set_[cleanurl(row['url'])]=(row,p)
    return set_

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('source',type=Path);p.add_argument('work',type=Path);p.add_argument('stage')
    a=p.parse_args();receive(a.source,a.work,a.stage)
