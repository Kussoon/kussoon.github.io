from run5 import write
P={
 'AE-C21921EE6375BF6B':['https://www.daiei.co.jp/stores/4469/','https://kyoto.aeonmall.jp/shop/0ae16330-7673-487e-ab3a-39286e0f33c9'],
 'AE-DF71F8365C4FCD13':['https://www.daiei.co.jp/stores/d0843/'],
 'AE-612160AC0FB9C9D5':['https://aeonmobile.jp/shoplist/funabashi/'],
 'AE-71AFEACB05C061F8':['https://www.aeonretail.jp/pdf/251013R_1.pdf','https://www.city.sanjo.niigata.jp/soshiki/sanjoukyouiku/kyoikuiinkaijimukyoku/kosodateshienka/7/101/121/19699.html','https://www.aeon.jp/sc/soyora-sanjosugoro/'],
 'AE-1B86D34EF2397E7B':['https://laketown.aeonmall.jp/news/mallnews/0cf5ae6a-3f09-430b-b5e9-c8e6d0cf5bba'],
 'AE-59F0323A6A2A2B7B':['https://takasaki.aeonmall.jp/shop/9b6e867f-785a-4c58-8a89-d701b7ed22f8'],
 'AE-0DEE08C172200552':['https://ota.aeonmall.jp/shop/6ea2bcf9-7614-4831-a32e-a429903e94f0'],
 'AE-F624E417505917D2':[],
 '全国範囲':['https://recruit.aeon.info/digital/aboutus/business/1338/','https://recruit.aeon.info/recruit_info/766/','https://recruit.aeon.info/information/11347/','https://www.aeontohoku.co.jp/company/pages/co-history','https://www.aeon.info/news/release_28369/'],
}
d={}
for uid,urls in P.items():
 for u in urls:d.setdefault(u,[]).append(uid)
write('more-requests.json',d);write('more-source-map.json',P)
