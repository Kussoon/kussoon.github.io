"""Audit the final 341 selected IDs, preserving original source dates and categories."""
import re
from collections import defaultdict,Counter
from urllib.parse import urlsplit
from address_cases import address_check
from addresses import address_result
from analyse import document
from compare import normalize,nf
from evaluate700 import level_and_row,take_detail,compare_name,jst,IND,LIST
from index700 import Index,store_key,special_page
from fetch import text,cleanurl,host
from eligibility6 import page_text
from assess6 import url_id,EQUAL
from run5 import js,write

REGIONAL_DOMAINS={'chubu.aeonretail.jp','nishinihon.aeonretail.jp','minami.aeonretail.jp','kitakanto.aeonretail.jp'}
STATUS={
 'AE-9167000B6C6E7210':'一時閉店','AE-45880BB2CDA1763B':'一時閉店',
 'AE-A19AA56C3F8236A2':'一時閉店',
}
SPL= {'AE-C21921EE6375BF6B':('KOHYO京都店','株式会社ダイエー','KOHYO'),
      'AE-DF71F8365C4FCD13':('ダイエー田辺SC店・イオンフードスタイル','株式会社ダイエー','イオンフードスタイル'),
      'AE-612160AC0FB9C9D5':('イオンモバイル船橋','イオンリテール株式会社','イオンモバイル')}
def label(s):
    return re.sub(r'\s+','',nf(s)).removeprefix('(一時閉店)').removeprefix('マーケットガーデン')

def region_cards(capture):
    out=[]
    for url,(log,body) in capture.items():
        if host(url) not in REGIONAL_DOMAINS or log['status']!=200:continue
        out+=special_page(log,body.read_bytes(),'','イオンリテール','company')
    return out

def grade_source(url):
    h=host(url)
    if h in ('daiei.co.jp','aeonmobile.jp'):return '運営会社個店'
    if h=='aeonretail.jp' or h.endswith('.aeonretail.jp') or h=='aeon.jp':return '運営会社公式資料'
    if h=='aeon.com':return 'イオングループ公式掲載（索引）'
    if h.endswith('aeonbank.co.jp'):return 'グループ会社公式・店内施設'
    if h.endswith(('aeonmall.jp','aeonmall.com','aeontown.co.jp')):return '施設運営会社公式'
    if h.endswith(('.lg.jp','.go.jp')):return '自治体公表資料'
    return 'グループ等の補完公表資料'

def addr_from_text(row,url,body):
    base=row['住所']
    city=row['市区町村']
    if not base or not city:return ''
    name=label(SPL.get(row['全国統合ID'],(row['店舗名'],))[0])
    f=re.sub(r'\s+',' ',nf(body))
    if name not in label(f) and name.removesuffix('店') not in label(f):
        return ''
    alternatives=[]
    if row['全国統合ID']=='AE-626F50FF771E281B':
        alternatives.append('高岡市江尻333-11')
    if row['全国統合ID']=='AE-08B8757C739CA987':
        alternatives.append('木津川市相楽台1-1-1')
    def crop(raw):
        return re.split(r'(?=\s+(?:\d{2,4}[-ー]\d{2,4}[-ー]\d{3,4}|T\s*E\s*L|電話|営業時間|イオン|地図|MAP|〒|[A-Za-z]{3,}))|[\s　]{2,}',raw,1)[0].strip()
    # Read the postal-address text from the matching municipality. On broad lists keep a branch-name/address window.
    city_names=[city,city.replace('市','',1)] if city.startswith('さいたま市') else [city]
    for m in re.finditer(re.escape(city_names[0]),f):
        around=label(f[max(0,m.start()-460):m.start()+330])
        if name not in around and name.removesuffix('店') not in around and ('housing08' in url or len(f)>180000):
            continue
        raw=f[m.start():m.start()+180]
        raw=crop(raw)
        pattern=r'^(.{2,95}?\d+(?:(?:\s*[-－ー]\s*|\s*丁目\s*|\s*番地?(?:の)?\s*|\s*の\s*)\d+)*(?:\s*(?:番地|番|号))?)'
        chosen=re.match(pattern,raw)
        if not chosen:continue
        candidate=chosen.group(1).replace(' ','')
        full=row['都道府県']+candidate
        if address_check(row,full) in EQUAL or normalize(candidate) in {normalize(a) for a in alternatives}:
            return full
    return ''

def retail(row,cards,src,manual,refs,verified):
    uid=row['全国統合ID']
    company=[c for c in cards if c['kind']=='company' and label(c['name_compare'])==label(row['店舗名'])]
    group=[c for c in cards if c['kind']=='group' and label(c['name_compare'])==label(row['店舗名']) and c['address']]
    res=level_and_row(row,company,None,[])
    official_name=(company or group or [{}])[0].get('name_compare','')
    address=''; url=''; stamp=''; digest=''; basis=''; typ=''; supplementary=''
    direct_checks=[]
    for u in refs:
        key=cleanurl(u)
        if key not in src:continue
        rec,body=src[key]
        if rec['status']!=200:continue
        direct_checks.append(key)
        raw=page_text(body,rec.get('content_type',''))
        a=addr_from_text(row,key,raw)
        if a:
            address,url,stamp,digest=a,key,rec['fetched_at'],rec['sha256']
            typ=grade_source(key)
            basis='店舗名を確認した公式資料の所在地欄。補完資料は運営会社・地域表示との対応を確認。'
            if typ in (IND,'運営会社公式資料'):break
    if uid in manual and (not address or uid=='AE-08B8757C739CA987'):
        data=manual[uid]
        address,url=data['住所'],data['URL']
        typ=data.get('資料種別',grade_source(url))
        basis=data['同一性']
        digest=stamp=''
        direct=src.get(cleanurl(url))
        if direct and direct[0]['status']==200 and addr_from_text(row,url,page_text(direct[1],direct[0].get('content_type',''))) and address_check(row,address) in EQUAL:
            stamp,digest=direct[0]['fetched_at'],direct[0]['sha256']
            typ=typ.replace('（公開索引）','')
    if not address:
        choices=[c for c in group if address_check(row,c['address']) in EQUAL]
        if choices and company:
            c=choices[0]
            address,url,stamp,digest=c['address'],c['url'],c['fetched_at'],c['sha256']
            typ='保存済みイオングループ公式一覧＋運営会社公式地域一覧'
            assert (url,digest) in verified
            basis='運営会社地域一覧の同名店と、グループ一覧の同一支店名・住所を突合。'
    if not address and company:
        choices=[c for c in group if c['address']]
        if choices and len({normalize(c['address']) for c in choices})==1:
            c=choices[0]
            if row['市区町村'] in c['address']:
                # The identity can be established, but a changed numeric address needs an independent reference.
                res['未採用の公式候補住所']=c['address']
    opname='イオンリテール株式会社' if company or group else ''
    if uid in SPL:
        official_name,opname,brand=SPL[uid]
    else:
        nm=official_name or row['店舗名']
        brand='イオンスタイル' if nm.startswith('イオンスタイル') else 'イオン' if 'イオン' in nm else (row['屋号'] or '')
    address_result_value={'一致':'原文一致','表記のみ相違':'表記差のみ'}.get(address_check(row,address),address_check(row,address))
    res.update({'公式住所':address,'住所比較':address_result_value,'元正規化住所':normalize(row['住所']),'公式正規化住所':normalize(address),
                '公式店舗名':official_name,'公式運営会社':opname,'公式屋号':brand if official_name else '',
                '名称比較':compare_name(row,official_name) if uid not in SPL else ('名称相違' if official_name!=row['店舗名'] else '原文一致'),
                '運営会社比較':('法人・系列表記の差（要照合）' if uid in ('AE-C21921EE6375BF6B','AE-DF71F8365C4FCD13') else '地域公式の系列表示を確認') if opname else '未確認',
                '住所資料種別':typ or '公式住所未確認','住所根拠URL':url,'住所確認日時UTC':stamp,
                '住所確認日JST':jst(stamp),'住所応答SHA256':digest,'個店公式URL':url if typ==IND else '',
                '同一性根拠':basis,'照合実施日JST':'2026-11-24',
                '確認レベル':('C' if address_result_value=='実質的な住所相違' else 'A' if typ==IND else 'B') if address else 'D',
                '公式一覧掲載':'同名店表示あり' if company else '補完資料で同定' if address else '未確認',
                '公式一覧URL':company[0]['url'] if company else '',
                '一覧取得日時UTC':company[0]['fetched_at'] if company else '',
                '一覧応答SHA256':company[0]['sha256'] if company else '',
                '確認したURL':' ／ '.join(dict.fromkeys(refs+[c['url'] for c in company+group])),
                'URL試行数':len(direct_checks),
                '調査結果・未解決理由':('' if address_result_value!='実質的な住所相違' else '同一店舗の公式所在地。旧住所と番地表記の関係は別途審査。') if address else '運営会社の地域一覧、保存証跡、補完資料で採録可能な所在地が不足。'})
    res['営業根拠URL']=''
    if uid in STATUS:
        res['営業判定']=STATUS[uid];res['営業判定根拠']='イオングループ公式の一時閉店表示。基準日後の営業再開は別管理。'
        res['営業根拠URL']=url
    elif uid in SPL and address:
        res['営業判定']='営業中（公式一覧基準）';res['営業判定根拠']='実運営会社個店の店舗情報と通常営業時間。'
    elif company and not company[0]['status']:
        res['営業判定']='営業中（公式一覧基準）';res['営業判定根拠']='運営会社の公式地域一覧に掲載、休閉業等の表示なし。'
    elif uid!='AE-F624E417505917D2' and company and company[0]['status']:
        res['営業判定']=company[0]['status'];res['営業判定根拠']='運営会社の公式地域一覧の営業例外表示。'
    else:
        res['営業判定']='未確認';res['営業判定根拠']='当該店舗の運営会社公式一覧で基準日の営業根拠を特定できない。'
    if company:
        if not res['営業根拠URL']:res['営業根拠URL']=company[0]['url']
        res['営業確認日JST']=jst(company[0]['fetched_at'])
        res['営業の確認日時UTC']=company[0]['fetched_at']
    return res

def review(master,excluded,history,picks,r4,work,src):
    region=region_cards(src)
    ix=Index(region+js(r4/'enriched-roster.json'))
    requests=js(work/'requests.json')
    extra=js(work/'address-source-map.json')
    more=js(work/'more-source-map.json')
    if (work/'latest-source-map.json').exists():
        for k,v in js(work/'latest-source-map.json').items():more.setdefault(k,[]).extend(v)
    manual=js(work/'address-indexed.json') if (work/'address-indexed.json').exists() else {}
    verified={(p['final'],p['sha256']) for p in js(r4/'roster-pages.json') if p.get('sha256')}
    owners={url_id(r['個店公式URL']):r['全国統合ID'] for r in history if r['個店公式URL']}
    urls=set(owners)
    for r in master:
        if r['住所確認根拠URL'] and r['住所確認資料種別']=='運営会社個店':
            key=url_id(r['住所確認根拠URL'])
            urls.add(key)
            owners.setdefault(key,r['全国統合ID'])
    rows=[];checks=[];allproof=[]
    root=work/'batches';root.mkdir(exist_ok=True)
    for b in range(1,9):
        result=[];proof=[]
        for row in [r for r in picks if r['バッチ']==b]:
            uid=row['全国統合ID'];cards=ix.lookup(row)
            tries=[];detail=None
            if row['系列分類']=='まいばすけっと':
                for u in requests[uid]:
                    k=cleanurl(u)
                    if k not in src:continue
                    attempt,p=src[k]
                    tries.append(attempt)
                    if attempt['status']!=200:continue
                    f=take_detail(row,attempt,p.read_bytes(),cards)
                    if f and url_id(f['url']) not in urls and compare_name(row,f['name']) in ('原文一致','表記差のみ'):
                        detail=f;break
                current=level_and_row(row,cards,detail,tries)
                if current['公式住所'] and not detail:
                    assert any(c['kind']=='company' and c['address']==current['公式住所'] for c in cards)
            else:
                refs=list(dict.fromkeys(more.get(uid,[])+extra.get(uid,[])+['https://www.aeonbank.co.jp/aeonbank/loan/housing/housing08SelPage/open/']))
                current=retail(row,cards,src,manual,refs,verified)
            if uid=='AE-C21921EE6375BF6B':
                peer=next(m for m in master if m['全国統合ID']=='AE-803C5CB80A357E2D')
                assert url_id(current['個店公式URL'])==url_id(peer['公式店舗URL'])
                assert normalize(current['公式住所']) in normalize(peer['住所'])
                current.update({'個店公式URL':'','既存対応候補ID':peer['全国統合ID'],
                   '住所資料種別':'既存行の運営会社個店証跡','同一性根拠':'ダイエーの同じ個店URLと住所の既存KOHYO行に対応。'})
            if current['個店公式URL']:
                key=url_id(current['個店公式URL'])
                if key in urls:
                    assert row['系列分類']=='イオンリテール' and uid in SPL and key in owners,(uid,key)
                    current.update({'個店公式URL':'','既存対応候補ID':owners[key],
                                    '住所資料種別':'既存行の運営会社個店証跡',
                                    '同一性根拠':'公式個店URLは同住所の既存IDで採録。店舗重複を別欄で提示。'})
                else:
                    urls.add(key)
                    owners[key]=uid
            current.setdefault('営業根拠URL',current['公式一覧URL'] or current['個店公式URL'] or current['住所根拠URL'])
            if not current['営業根拠URL'] and current['営業判定']!='未確認':current['営業根拠URL']=current['住所根拠URL']
            current['住所採録状態']='取得済み' if current['公式住所'] else '未取得'
            current['照合実施日JST']='2026-11-24'
            proof.append({'id':uid,'directory_cards':cards,'個店':detail,'attempts':tries,'採用住所資料':current['住所根拠URL'],
                          '採用資料ハッシュ':current['住所応答SHA256']})
            result.append(current)
        ids=[r['全国統合ID'] for r in result]
        assert 0<len(ids)<=50 and len(ids)==len(set(ids)) and not set(ids)&excluded and ids==[r['id'] for r in proof]
        checks.append({'バッチ':b,'系列':result[0]['系列分類'],'件数':len(ids),'選定・結果・証跡ID一致':True,'過去対象重複':0,
                       '住所確認':sum(bool(r['公式住所']) for r in result),'保留':sum(not r['公式住所'] for r in result)})
        for tag,data in [('results',result),('evidence',proof),('validation',checks[-1])]:
            write(root/f'batch-{b:02}-{tag}.json',data)
        rows+=result
    assert len(rows)==341 and len({r['全国統合ID'] for r in rows})==341
    write(work/'results.json',rows)
    return rows,checks,region
