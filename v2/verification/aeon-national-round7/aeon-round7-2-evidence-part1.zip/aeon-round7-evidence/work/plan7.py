from pathlib import Path
from collections import Counter
import sys
from plan6 import load
from run5 import js,write
from tables6 import sheet_data
from index700 import Index
from store_plan import plan
from fetch import kind,host
def prepare(master,r4,r5e,r6r,r6e,work):
    rows,excluded,confirmed,h=load(master,r4,r5e)
    six=js(r6e/'results.json')
    r6ids={r['全国統合ID'] for r in six}
    assert len(r6ids)==1000 and not r6ids&excluded and all(r['公式住所'] for r in six)
    excluded=excluded|r6ids
    by={r['全国統合ID']:r for r in rows}
    picks=sheet_data(r6r,'07-第7回残件一覧・最終調査計画','住所残件一覧')
    assert {r['全国統合ID'] for r in picks}==by.keys()-excluded
    assert Counter(r['系列分類'] for r in picks)=={'まいばすけっと':232,'イオンリテール':109}
    ix=Index(js(r4/'enriched-roster.json'))
    cfg=js(r4/'config.json')
    result=[];requests={}
    for op,start in [('まいばすけっと',1),('イオンリテール',6)]:
        chosen=[by[r['全国統合ID']] for r in picks if r['系列分類']==op]
        for i,r in enumerate(chosen):
            uid=r['全国統合ID']
            result.append(r|{'バッチ':start+i//50,'選定理由':'第6回の住所残件一覧に収録'})
            requests[uid]=[u for u in plan(r,ix,cfg) if kind(u)=='個店候補']
    assert Counter(r['バッチ'] for r in result)=={1:50,2:50,3:50,4:50,5:32,6:50,7:50,8:9}
    write(work/'selection.json',result);write(work/'requests.json',requests)
    return rows,excluded,confirmed|r6ids,h+six,result
if __name__=='__main__':prepare(*map(Path,sys.argv[1:]))
