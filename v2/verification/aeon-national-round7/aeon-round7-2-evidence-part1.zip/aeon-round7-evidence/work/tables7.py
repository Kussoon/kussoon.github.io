import csv,io
from collections import defaultdict,Counter
from zipfile import ZipFile
from tables6 import sheet_data
from finish700 import corrections
from address_cases import address_check
from assess6 import EQUAL,url_id
from index700 import Index
from address7 import label
from compare import normalize,nf
from eligibility6 import POS
from food7 import FOOD,GMS,ABSENT,DUPE
from run5 import js
from audit7 import TANABE,KYOTO

VALUE_COL={'住所':'住所','店舗名':'店舗名','運営会社':'運営会社','系列':'系列分類','屋号':'屋号',
           '掲載区分':'掲載区分','営業状況':'営業状態'}
ADDRESS_CASES=('白岡原ヶ井戸店','マックスバリュ武富店','ビッグ・エー木下店','ビッグ・エーみさと団地店','カスミけやき台店')
ABIKO='https://www.daiei.co.jp/stores/0003/'
ABIKO_NEWS='https://www.daiei.co.jp/news/000011/'

def persistent(r6r,master,src):
    s='05-未解決事項と掲載適格性'
    prior=sheet_data(r6r,s,'個別案件の追加調査')
    context=sheet_data(r6r,s,'前回の判断原文')
    future=sheet_data(r6r,s,'基準日後の事象')
    current=[]
    for r in prior:
        n=r['対象']; text=r['第6回調査結果']; action=r['第6回判定']
        a='判断保留。統合時は従来区分・根拠を維持。'
        if n in ADDRESS_CASES:a='運営会社公式住所を原文欄へ採録。旧地番・枝番・住号の関係は保留。'
        if n=='イオン高知旭町店':a='履歴・休業区分を維持。再開時点は保留。'
        if n=='イオンスタイル伊達':a='住所は公式の事業地内表記で採録。一般営業・グランド開店日は別管理。'
        if n=='イオン福岡東ショッピングセンター':a='公式ブランド変更を食品核店舗に対応付け、施設の重複新規掲載を回避。'
        current.append(r|{'第7回判定':action,'最終統合の扱い':a,'第7回根拠または保留理由':text})
    m=[m for m in master if 'あびこ駅前' in m['店舗名'] and 'Food' in m['店舗名']]
    if not m:m=[m for m in master if 'あびこ駅前' in m['店舗名'] and 'ダイエー' in m['系列分類']]
    assert len(m)<=1,[r['店舗名'] for r in m]
    current.append({'対象':'FoodStyleあびこ駅前店','全国統合ID':m[0]['全国統合ID'] if m else '',
                    '第7回判定':'営業中（公式一覧基準）','最終統合の扱い':'同一行の屋号・営業根拠に反映する候補。',
                    '第7回根拠または保留理由':'運営会社の開店発表は2026年4月25日。現行の個店に営業時間。旧屋号の閉店・改装とは区別。',
                    '根拠URL':ABIKO+' ／ '+ABIKO_NEWS,'確認日JST':'2026-11-24','取得日時UTC':src[ABIKO][0]['fetched_at']})
    return current,context,future

def correction_tables(r6r,master,new,food_updates,cases):
    root='02-修正候補と累計管理'
    prior=sheet_data(r6r,root,'候補判断履歴')
    prev=sheet_data(r6r,root,'管理キー別最新版')
    key=lambda r:(r['全国統合ID'],r['修正項目'])
    hist=defaultdict(list)
    for r in prior:hist[key(r)].append(r)
    p_by={key(r):r for r in prev}
    assert len(prior)==2251 and len(p_by)==1981
    assert sum(r['管理状態']=='履歴に差異あり・適用前に要確認' for r in prev)==267
    m_by={m['全国統合ID']:m for m in master}
    new_by={r['全国統合ID']:r for r in new}
    generated=corrections(new,{})
    for r in food_updates:
        if not r['根拠URL']:continue
        generated.append({'全国統合ID':r['全国統合ID'],'項目':'掲載適格性','候補値':r['第7回累計判定'],'旧値':r['第6回引継ぎ分類'],
            '確度':'新規食品判定資料','理由':r['根拠または未確認理由'],'根拠URL':r['根拠URL'],'補足根拠URL':r['補足資料URL'],
            '取得日時UTC':r['取得日時UTC'],'確認日':'2026-11-24'})
    for uid, item, value, reason in (
        (TANABE,'重複整理','既存ダイエー行へ対応','実運営会社個店URLと所在地が既存行と一致。全国統合IDは出典履歴に保持。'),
        (KYOTO,'重複整理','既存KOHYO京都店行へ対応','ダイエーの個店URLと所在地が既存KOHYO京都店行と一致。KOHYO屋号と法人は既存行へ。')):
        r=new_by[uid]
        generated.append({'全国統合ID':uid,'項目':item,'候補値':value,'旧値':m_by[uid].get(VALUE_COL.get(item),''),
                 '確度':'第7回の実運営会社個店で明示','理由':reason,'根拠URL':r['住所根拠URL'],'確認日':'2026-11-24'})
    for r in cases:
        if r['対象']=='FoodStyleあびこ駅前店' and r['全国統合ID']:
            generated.append({'全国統合ID':r['全国統合ID'],'項目':'営業状況','候補値':r['第7回判定'],
                              '旧値':m_by[r['全国統合ID']]['営業状態'],'確度':'公式個店・開店発表',
                              '理由':r['第7回根拠または保留理由'],'根拠URL':r['根拠URL'],'確認日':'2026-11-24'})
    adds=[]
    for r in generated:
        uid=r['全国統合ID']; m=m_by[uid]
        field={'運営会社または系列':'運営会社'}.get(r['項目'],r['項目'])
        proof=new_by.get(uid,{})
        z={'回次':'第7回','全国統合ID':uid,'店舗名':m['店舗名'],'都道府県':m['都道府県'],
           '修正項目':field,'原文項目':r['項目'],'旧値':r['旧値'],'候補値':r['候補値'],'判定':r['確度'],
           '反映区分':r.get('自動反映可能か','承認後に判断'),'理由':r['理由'],'根拠URL':r['根拠URL'],
           '補足根拠URL':r.get('補足根拠URL',''),'確認日JST':r['確認日'] or '2026-11-24',
           '取得日時UTC':r.get('取得日時UTC') or (proof.get('住所確認日時UTC','') if proof.get('住所根拠URL')==r['根拠URL'] else '')}
        if hist[key(z)] and any(all(x.get(f)==z.get(f) for f in ('候補値','判定','根拠URL')) for x in hist[key(z)]):continue
        if z['候補値'] and z['根拠URL']:
            hist[key(z)].append(z);adds.append(z)
    focus=[];latest=[];changes=[]
    case_by={r['全国統合ID']:r for r in cases if r['全国統合ID']}
    for k, entries in sorted(hist.items()):
        uid,field=k; m=m_by[uid]; old=p_by.get(k,{})
        pick=next((r for r in reversed(entries) if r['回次']=='第7回'),old or entries[-1])
        base=m.get(VALUE_COL.get(field),'') or (pick['旧値'] or '')
        value=pick['候補値']; url=pick['根拠URL']; verdict='判断保留'
        why=pick['理由'] or '根拠・発効日・値の整合の確認を要する。'
        signature={(r['候補値'],r['判定']) for r in entries}
        values=list(dict.fromkeys(str(r['候補値']) for r in entries if r['候補値']))
        source_conflict=old.get('管理状態')=='履歴に差異あり・適用前に要確認'
        if field=='住所':
            equivalent=bool(values) and all(address_check(m,v) in EQUAL for v in values)
            if equivalent:
                verdict='表記差のみ・現行値維持'
                why='履歴の全住所候補を現行値と比較し、数字・街区の実質差なし。'
            elif url and value and (pick['回次']=='第7回' or uid in case_by or '公式現行住所' in pick['判定']):
                verdict='公式住所原文の採録'
                why='公式所在地を別欄へ記入。旧住所との対応・基準日への反映は別審査。 '+why
            elif '反映不要' in pick['判定'] and not source_conflict:
                verdict='反映見送り'
        elif field=='重複整理':
            verdict='重複整理'
        elif nf(str(value))==nf(str(base)) and value and field in VALUE_COL:
            verdict='反映見送り';why='現行値と同じ値。履歴・公式根拠を保持。'
        elif field=='掲載適格性' and url and ('根拠を追加' in pick['判定'] or pick['回次']=='第7回'):
            verdict='公式根拠により反映推奨'
        elif field in ('営業状況','掲載区分') and pick['回次']=='第7回' and url:
            verdict='営業状況・掲載区分の変更'
        elif field in ('運営会社','系列','屋号') and url and ('公式個店で実運営法人を確認' in pick['判定'] or '統合発効日の' in pick['判定'] or '実運営会社個店で明示' in pick['判定']):
            verdict='運営会社・系列・屋号の変更'
        elif pick['判定']=='反映済み' and not source_conflict:
            verdict='反映見送り'
        elif field=='屋号' and url and value and not m['屋号'] and len(values)==1 and '公式名または専用サイト表記' in pick['判定']:
            verdict='運営会社・系列・屋号の変更'
        elif url and pick['反映区分']=='承認後可能' and not source_conflict:
            verdict='公式根拠により反映推奨'
        z=pick|{'履歴行数':len(entries),'候補値・判定の種類':len(signature),'旧管理状態':old.get('管理状態',''),
                '台帳現行値':base,'反映推奨値':base if verdict in ('表記差のみ・現行値維持','反映見送り') else value if verdict!='判断保留' else '',
                '反映審査結果':verdict,'反映審査理由':why,'すべての過去値・候補値':' ／ '.join(values),
                '元の最新候補値':old.get('候補値',''),'元の最新根拠URL':old.get('根拠URL',''),
                '審査日JST':'2026-11-24'}
        latest.append(z)
        if source_conflict:focus.append(z)
        if pick['回次']=='第7回':changes.append(z)
    assert len(focus)==267 and len(latest)==len(hist)
    return latest,prior+adds,focus,adds,changes

def cumulative(master,masterzip,confirmed,history,new,food,r4,r5r,recovered,cases):
    with ZipFile(masterzip) as z:
        first={r['全国統合ID']:r for r in csv.DictReader(io.StringIO(z.read('delivery/official-history-650.csv').decode('utf-8-sig')))}
    hist={r['全国統合ID']:r for r in history+new}
    new_ids={r['全国統合ID'] for r in new}
    retest=sheet_data(r5r,'05-過去未解決事項の再調査','既選定の住所再調査')
    ret={r['全国統合ID']:r for r in retest if r.get('住所再加算')}
    ix=Index(js(r4/'enriched-roster.json'))
    food_by={r['全国統合ID']:r for r in food}
    exact=[];operation=[]
    case_by={r['全国統合ID']:r for r in cases if r['全国統合ID']}
    dupes={r['全国統合ID'] for r in new if r.get('既存対応候補ID')}
    for m in master:
        uid=m['全国統合ID']; p=hist.get(uid,{}); f=first.get(uid,{}); retp=ret.get(uid,{})
        c=p.get('公式住所') or f.get('公式住所（掲載表記）') or m['公式住所（掲載表記）']
        source=p.get('住所根拠URL') or f.get('住所等根拠URL') or m['住所確認根拠URL']
        stamp=p.get('住所確認日時UTC') or f.get('取得日時UTC') or m['住所確認日時UTC']
        digest=p.get('住所応答SHA256') or f.get('住所等応答SHA-256') or m['住所応答SHA-256']
        typ=p.get('住所資料種別') or f.get('住所確認資料種別') or m['住所確認資料種別']
        if uid not in hist and uid not in first:
            round_='第1〜3回集計の継承'
        elif uid in new_ids:round_='第7回'
        elif uid in hist:
            round_='第4〜6回'
        else:round_='第1〜2回保存資料'
        if retp and not c:
            c=retp.get('公式住所',''); source=retp.get('根拠URL') or source
            stamp=retp.get('取得日時UTC') or stamp; digest=retp.get('応答SHA256') or digest
            typ=retp.get('資料種別') or typ;round_='第5回再調査'
        options=[]
        if not c or not p and not f:
            options=[d for d in ix.lookup(m) if d['kind']=='company' and d['pref']==m['都道府県']
               and label(d['name_compare']).removesuffix('店')==label(m['店舗名']).removesuffix('店') and d.get('address') and address_check(m,d['address']) in EQUAL]
            values={normalize(d['address']) for d in options}
            if not c and len(values)==1:
                d=options[0];c=d['address']; source=d['url'];stamp=d['fetched_at'];digest=d['sha256'];typ='保存済み公式一覧（補完）'
        rec=recovered.get(uid,{})
        if not c and rec:
            c,source,stamp,digest,typ=rec['addr'],rec['url'],rec['stamp'],rec['sha'],'第7回の既選定再調査・会社公式個店' if rec['stamp'] else '第7回の既選定再調査・会社公式個店の公開索引'
            round_='第7回既選定再調査（累計への加算なし）'
        status=p.get('営業判定') or f.get('営業判定') or ''
        stat_note=p.get('営業判定根拠') or f.get('営業判定根拠') or ''
        stat_url=(p.get('営業根拠URL') or p.get('公式一覧URL') or p.get('個店公式URL') or p.get('住所根拠URL')) if p else f.get('営業根拠URL') or m['営業判定根拠URL']
        stat_stamp=p.get('営業の確認日時UTC') or f.get('営業確認日時UTC') or m['営業確認日時UTC']
        if not status or status in ('未判定','未確認'):
            if len(options)==1 and m['掲載区分']=='通常候補' and not options[0]['status'] and '閉店' not in (m['営業状態'] or ''):
                status='営業中（公式一覧基準）'; stat_url=options[0]['url'];stat_stamp=options[0]['fetched_at']
                stat_note='保存公式会社一覧で同一住所の支店を確認。休閉業等の表示なし。'
            elif not status:
                status='未確認';stat_note='根拠付きの過去判定を個別に復元できない。台帳の営業欄は別列で保持。'
        if status in ('未確認','未判定','要確認') and rec and rec['status']=='営業中':
            status='営業中（公式一覧基準）';stat_url=rec['url'];stat_stamp=rec['stamp'];stat_note='運営会社公式個店の営業表示。'
        if case_by.get(uid,{}).get('対象')=='FoodStyleあびこ駅前店':
            status='営業中（公式一覧基準）';stat_url=ABIKO+' ／ '+ABIKO_NEWS;stat_stamp=case_by[uid].get('取得日時UTC','');stat_note=case_by[uid]['第7回根拠または保留理由']
        if uid in dupes:
            stat_note+='。既存IDと同一の店舗営業。'
        base={k:m[k] for k in ('全国統合ID','都道府県','市区町村','系列分類','店舗名','掲載区分')}
        op=base|{'台帳営業欄':m['営業状態'],'基準日':'2026-11-23','営業判定':status,'営業根拠URL':stat_url,
             '営業根拠取得日時UTC':stat_stamp,'判定根拠・未確認理由':stat_note or '過去回の営業判定のみ継承。'}
        operation.append(op)
        exact.append(base|{'再確認の補足':rec.get('所見',''),'台帳住所':m['住所'],'台帳屋号':m['屋号'],'台帳運営会社':m['運営会社'],'台帳公式URL':m['公式店舗URL'],
             '住所確認':uid in confirmed,'公式住所原文':c,'住所確認資料種別':typ,
             '住所照合結果':p.get('住所比較') or f.get('住所照合結果') or (address_check(m,c) if c else ''),
             '公式店舗名':p.get('公式店舗名') or f.get('公式店舗名（掲載表記）') or rec.get('name') or m['現行公式名'],
             '公式屋号':p.get('公式屋号',''),'公式運営会社':p.get('公式運営会社') or f.get('公式運営会社') or m['確認済み運営会社'],
             '住所証跡URL':source,'取得日時UTC':stamp,'住所応答SHA256':digest,'確認段階':round_,
             '住所原文の状態':'採録あり' if c else '過去の集計判定を継承。住所原文の個別証跡未収録。',
             '営業判定':status,'掲載適格性':food_by[uid]['第7回累計判定'],'基準日':'2026-11-23'})
    assert len(exact)==len({r['全国統合ID'] for r in exact})==len(operation)==4701
    return exact,operation
