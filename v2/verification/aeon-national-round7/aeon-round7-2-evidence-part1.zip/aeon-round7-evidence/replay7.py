"""Rebuild Round 7 from the provided input ZIPs and the saved Round 7 captures."""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys
from zipfile import ZipFile
from tempfile import TemporaryDirectory

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()

def find_input(root, filename):
    options=[p for p in root.rglob('*.zip') if p.name==filename or p.name.endswith('-'+filename)]
    if len(options)!=1:raise ValueError(f'{filename}: expected one ZIP under {root}, found {len(options)}')
    return options[0].resolve()

def replay(inputs,output,include_excel):
    package=Path(__file__).resolve().parent
    saved=package/'work'
    expectation={}
    for line in (package/'input-sha256.txt').read_text(encoding='utf-8').splitlines():
        digest,name=line.split('  ',1)
        p=find_input(inputs,name)
        if sha(p)!=digest:raise ValueError(f'Input SHA-256 differs: {p}')
        expectation[name]=(digest,p)
    original=lambda name:expectation[name][1]
    master=original('aeon-national-master-phase2c-20261123.zip')
    with TemporaryDirectory(prefix='aeon-r7-') as tmp:
        root=Path(tmp)
        def extract(name,destination):
            target=root/destination
            with ZipFile(original(name)) as z:z.extractall(target)
            return target
        r4=extract('aeon-round4-1-results.zip','r4')
        extract('aeon-round4-2-evidence.zip','r4')
        r5r=extract('aeon-round5-1-results.zip','r5r')
        r5e=extract('aeon-round5-2-evidence.zip','r5e')
        r6r=extract('aeon-round6-1-results.zip','r6r')
        r6e=extract('aeon-round6-2-evidence-part1.zip','r6e')
        extract('aeon-round6-2-evidence-part2.zip','r6e')
        work=root/'work'
        shutil.copytree(saved,work,ignore=shutil.ignore_patterns('qa','batches'))
        (work/'inputs.sha256').write_text(''.join(f'{h}  {p}\n' for h,p in expectation.values()))
        env=os.environ.copy();env['PYTHONPATH']=os.pathsep.join(str(p) for p in (r6e,r5e,r4))
        output.mkdir(parents=True,exist_ok=True)
        cmd=[sys.executable,str(work/'deliver7.py'),*(str(p) for p in (master,r4,r5r,r5e,r6r,r6e,work,output))]
        if not include_excel:cmd.append('--no-xlsx')
        subprocess.run(cmd,env=env,check=True)
        subprocess.run([sys.executable,str(work/'report7.py'),str(work),str(output)],env=env,check=True)
        differs=[]
        for line in (package/'replay-expected-sha256.txt').read_text(encoding='utf-8').splitlines():
            h,name=line.split('  ',1)
            p=work/'qa'/name
            if name=='input-sha256-verification.csv':
                # The attachment wrapper can prefix names. Compare their canonical names and require identical hashes.
                import csv
                a=list(csv.DictReader(p.open(encoding='utf-8-sig')))
                canonical={n for n in expectation}
                measured={next(n for n in canonical if row['ファイル']==n or row['ファイル'].endswith('-'+n)):row['SHA256'] for row in a}
                if measured!={n:v[0] for n,v in expectation.items()}:differs.append(name)
            elif not p.is_file() or sha(p)!=h:differs.append(name)
        if differs:raise RuntimeError('Different output files: '+', '.join(differs))
        for p in sorted((work/'qa').glob('*')):
            if p.is_file():shutil.copyfile(p,output/p.name)
        print('CSV・JSON再実行照合 一致')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--inputs',type=Path,required=True,help='正本と第4〜6回のZIP計8本のあるフォルダ')
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--excel',action='store_true')
    a=p.parse_args();replay(a.inputs,a.out.resolve(),a.excel)
