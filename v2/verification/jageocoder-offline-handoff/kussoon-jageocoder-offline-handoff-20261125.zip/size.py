import io, re, urllib.request, zipfile
URL='https://info-proto.com/static/jageocoder/latest/jukyo_all_v22.20260417.zip'
class Remote(io.RawIOBase):
    def __init__(self): self.pos=0; self.size=5599646978
    def tell(self): return self.pos
    def seek(self,n,w=0):
        self.pos=n+(self.pos if w==1 else self.size if w==2 else 0)
        return self.pos
    def read(self,n=-1):
        end=min(self.size,self.pos+(1048576 if n<0 else n))
        if end<=self.pos:return b''
        req=urllib.request.Request(URL,headers={'Range':f'bytes={self.pos}-{end-1}','Accept-Encoding':'identity'})
        with urllib.request.urlopen(req,timeout=20) as r:
            assert r.status==206 and r.headers['Content-Range']==f'bytes {self.pos}-{end-1}/{self.size}',(r.status,r.headers.get('Content-Range'))
            data=r.read(end-self.pos)
        self.pos+=len(data)
        return data
with zipfile.ZipFile(Remote()) as z:
    total=0
    for i in z.infolist():
        print(i.file_size,i.compress_size,i.filename);total+=i.file_size
    print('expanded',total,'combined',total+5599646978)
