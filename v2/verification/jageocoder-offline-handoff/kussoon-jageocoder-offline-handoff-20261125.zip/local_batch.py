"""Search a previously installed Jageocoder dictionary; no remote calls."""
import argparse
import csv
import json
from pathlib import Path
import jageocoder

p = argparse.ArgumentParser()
p.add_argument('dictionary', type=Path)
p.add_argument('input', type=Path)
p.add_argument('output', type=Path)
a = p.parse_args()
if not a.dictionary.is_dir():
    p.error('install the dictionary first')
jageocoder.init(db_dir=a.dictionary, mode='r')
with a.input.open(encoding='utf-8-sig', newline='') as source:
    rows = list(csv.DictReader(source))
with a.output.open('w', encoding='utf-8') as output:
    for required in (True, False):
        jageocoder.set_search_config(require_coordinates=required)
        for row in rows:
            result = jageocoder.search(row['address'])
            output.write(json.dumps({'id':row['id'], 'address':row['address'],
                         'require_coordinates':required,'result':result}, ensure_ascii=False)+'\n')
