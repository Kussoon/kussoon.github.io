"""Compile the adjudication from saved sources and the inherited operator evidence."""
from hashlib import sha256
import json
from pathlib import Path
import re
from urllib.parse import urlsplit
from scope import select,read_csv,TARGET,SOCOLA
from patch import CLOSE_URL,LIVING_URL,REOPEN_URL,FACILITY_URL

ROOT = Path(__file__).resolve().parents[1]
PREVIOUS = ROOT.parent/'v12-build'
EVIDENCE = ROOT/'evidence'
TOKUBAI = 'https://tokubai.co.jp/officialized_shops/'
KYUSHU = 'https://tenpo.aeon-kyushu.info/'
BIG = 'https://www.aeonbig.co.jp/newstore/index.html'
COCOSA = 'https://cocosa.jp/shop/detail.html?act=10740'

DIRECT = {
 'イオンショッパーズ福岡店': (TOKUBAI+'6054','イオン九州個店から同じ店舗のチラシに接続。青果・加工食品等の売出しを確認。'),
 'イオン戸畑ショッピングセンター': (TOKUBAI+'14829','同じイオン戸畑店の食品売場営業時間と食品チラシ。個店内の衣料テナントと別。'),
 'イオン若松ショッピングセンター': (TOKUBAI+'14832','会社公式個店が配信する同一店のチラシに食品売場と営業時間を確認。'),
 'イオン大野城ショッピングセンター': (TOKUBAI+'14838','会社公式個店が配信する同一店の食品チラシと食品売場営業時間。チラシ中の「閉店」は時刻の表記。'),
 'イオン乙金ショッピングセンター': (TOKUBAI+'115234','会社公式個店が同じイオン乙金店のチラシへ接続。食品商品と店舗営業時間を掲載。前版の公式LINEに直営食品売場の営業時間あり。'),
 'イオン小郡ショッピングセンター': (KYUSHU+'aeon/detail/ogori/shoplist-service/974002/','会社公式フロア案内のイオン直営1階食品売場に営業時間あり。'),
 'イオン糸島ショッピングセンター': (TOKUBAI+'14875','会社公式個店が配信する同一店の食品チラシに食品売場営業時間あり。'),
 'イオンパークプレイス大分店': (KYUSHU+'detail/parkplace-oita/shoplist-service/850505/','会社公式テナント案内のイオン1階食品売場と営業時間を確認。'),
 'イオン唐津ショッピングセンター': (KYUSHU+'detail/karatsu/','会社公式個店が1階食品と専門店の営業時間を区別。検索で得た閉店記事は菓子専門店の閉店。'),
 'イオン東長崎ショッピングセンター': (KYUSHU+'detail/higashinagasaki/shoplist-service/866989/','会社公式テナント案内で直営1階食品売場、同階その他売場、2階を区別。'),
 'イオン大塔ショッピングセンター': (TOKUBAI+'14851','会社公式個店のチラシ配信先に直営農産と食品売場の営業時間・通路案内。'),
 'イオン時津ショッピングセンター': (TOKUBAI+'14853','会社公式個店のチラシ配信先に食品売場の営業時間・食品商品。文具売場の移動案内とは別。'),
 'イオン天草ショッピングセンター': (KYUSHU+'aeon/detail/amakusa/shoplist-service/868103/','会社公式テナント案内でイオンの食品売場営業時間をその他売場と区別。'),
 'イオン八代ショッピングセンター': (KYUSHU+'detail/yatsushiro/','2026年10月1日からの1階直営売場案内に食品売場営業時間あり。専門店の券の返金案内と区別。'),
 'イオンプラザ大島店': (TOKUBAI+'6034','会社公式に接続先が掲載され、配信先で個店の食品売場営業時間を確認。地域サイトの取得は503。'),
 'イオン高城ショッピングセンター': (KYUSHU+'detail/takajo/','会社公式個店に食品売場と他部門それぞれの営業時間。'),
 'イオンスタイル市川コルトンプラザ': ('https://www.nikke-cp.gr.jp/shop/index.jsp?bf=1&shopid=457','施設公式案内がイオンスタイル2階食品売場の営業時間、生鮮・惣菜を明示。'),
 'カスミ イオンタウン上里店': ('https://www.aeontown.co.jp/kamisato/shop/detail/?id=001424','施設公式の1階食品スーパー「フードマーケット カスミ」。カスミの個店情報と一致。'),
 'イオンフードスタイルソコラ塚口店': ('https://www.daiei.co.jp/stores/d0890/','南塚口町2-1-3。ダイエー公式個店で地下1階の食料品売場営業時間を確認。'),
 'ダイエー田辺SC店・イオンフードスタイル': ('https://www.daiei.co.jp/stores/d0843/','ダイエー公式個店で1階食料品の営業時間を2階生活用品の営業時間と区別。'),
 'イオンスーパーセンター手稲山口店': ('https://www.aeon-hokkaido.jp/aeon/shop/teine/','イオン北海道公式個店は施設専門店と直営売場を区別し、個店のチラシと食品トレー回収を案内。スーパーセンター業態として継承。'),
 'イオンスーパーセンター三笠店': ('https://www.aeon-hokkaido.jp/aeon/shop/mikasa/','イオン北海道公式個店は施設専門店と直営売場を区別し、個店のチラシと食品トレー回収を案内。スーパーセンター業態として継承。'),
 'イオンスーパーセンター石狩緑苑台店': ('https://www.aeon-hokkaido.jp/aeon/shop/ishikari/','イオン北海道公式個店で1階食品売場の営業時間。'),
 'イオンスーパーセンター釜石店': ('https://www.aeontown.co.jp/kamaishi/shop/detail/?id=000432','施設公式が同店の直営売場と営業時間を案内し、イオン東北の個店から接続するチラシに食品商品を確認。'),
 'イオン名寄店': ('https://www.aeon-hokkaido.jp/aeon/shop/nayoro/','イオン北海道公式個店で1階食品売場の営業時間。'),
 'イオン旭川永山店': ('https://www.aeon-hokkaido.jp/aeon/shop/nagayama/','イオン北海道公式個店で1階食品売場の営業時間。'),
 'イオン旭川西店': ('https://www.aeon-hokkaido.jp/aeon/shop/asahikawanishi/','イオン北海道の直営個店で1階食品売場の営業時間。モール専門店街とは区別。'),
 'イオン旭川春光店': ('https://www.aeon-hokkaido.jp/aeon/shop/syunkou/floorguide.html','イオン北海道公式の現行店舗フロアガイドに食料品売場。旧店舗および施設行と区別。'),
 'COCOSAB1': (COCOSA,'施設公式が地下1階のイオン九州の食品スーパーを明示。イオン九州個店と住所が一致。'),
 'イオン二日市店': ('https://space.aeon-kyushu.info/spaces/126/lease','会社公式の同店1階食品レジ横区画と、個店に接続された同店のチラシ。別住所のマックスバリュエクスプレス二日市店と区別。'),
 'イオン穂波店': (KYUSHU+'aeon/detail/honami/shoplist-service/849027/','会社公式テナント案内でイオンの食品売場営業時間を確認。'),
 'イオン甘木店': ('https://space.aeon-kyushu.info/spaces/809/lease','会社公式の同施設フロア説明に1階食料品・美と健康・暮らし。個店とも対応。'),
}

def saved_text(url,log):
    return (ROOT/'work'/f"{log[url]['key']}.txt").read_text()

def as_review(row, groups, individual, log):
    uid, name = row['全国統合ID'],row['表示用店舗名']
    original, operator = row['掲載適格性根拠URL'],row['公式店舗URL']
    if uid==TARGET:
        return ('対象外へ変更','施設公式＋閉店・増床報道',CLOSE_URL,
                ' ／ '.join((FACILITY_URL,REOPEN_URL,LIVING_URL)),
                '2025-10-05にダイエー直営食品売場は営業終了。旧食品売場に衣料品店パレットが同年11-19増床。施設専門店は営業。')
    if name in DIRECT:
        url,note=DIRECT[name]
        assert log[url]['status']==200
        supply = ('会社個店連携の食品チラシ' if url.startswith(TOKUBAI) else
                  '施設公式の食品核店舗案内' if url==COCOSA or 'nikke-cp' in url or 'aeontown.co.jp' in url else
                  '直営売場と業態根拠' if name in ('イオンスーパーセンター手稲山口店','イオンスーパーセンター三笠店') else
                  '会社公式の食品売場・売場別案内')
        if name=='イオン乙金ショッピングセンター':
            operator += ' ／ ' + original
        return ('通常掲載維持',supply,url,operator if operator!=url else '',note)
    if individual and '/suc_' in operator:
        t=saved_text(operator,log)
        assert name in t and '直営店' in t and 'チラシ・特売情報' in t
        return ('通常掲載維持','直営売場と業態根拠',operator,'',
                '公式個店のスーパーセンター業態、直営店営業時間、店名付きチラシへの接続を確認。共通ニュースと個店情報を区別。')
    if individual and 'the-fuji.com' in operator:
        t=saved_text(operator,log)
        assert name in t and 'フジ直営食品売場' in t
        hours=next((l for l in t.splitlines() if re.search(r'食品(?:館|売場).{0,10}[0-9]:[0-9]{2}',l)),None)
        note=('食品館・食品売場の時間表示と直営食品売場の配送案内。' if hours else '同じ店舗の公式チラシ・営業時間と直営食品売場の配送案内。')
        return ('通常掲載維持','会社公式の食品売場・売場別案内',operator,'',note)
    if individual and '施設全体と明確に区分' in row['掲載適格性根拠説明']:
        assert re.search(r'食品|食料',saved_text(original,log))
        return ('通常掲載維持','会社公式の食品売場・売場別案内',original,operator if operator!=original else '',
                '公式テナント案内のイオン食品売場とその営業時間を施設専門店から区別。')
    if individual:
        assert name in ('イオン防府店','イオン光店') and '日配食品' in saved_text(operator,log)
        return ('通常掲載維持','会社公式の食品売場・売場別案内',operator,original,'会社公式個店の売場別営業時間にデイリー（日配食品）の記載あり。')
    assert row['掲載適格性']=='食品スーパー業態として確認' and original and operator
    if row['系列分類']=='イオンビッグ':
        assert name in saved_text('https://www.aeonbig.co.jp/stores/',log) and '食品ディスカウントスーパー' in saved_text(BIG,log)
        return ('通常掲載維持','運営会社の食品スーパー業態',original,BIG,
                'イオンビッグ公式一覧の店名と、会社公式の食品ディスカウントスーパー（ビッグ各業態）説明を照合。')
    method = '運営会社の食品スーパー業態' if '新規採用' in groups or '要確認から通常掲載' in groups else '運営会社の食品スーパー業態（既往証跡）'
    note = f"食品スーパー「{row['有効屋号'] or row['系列分類']}」の店舗として運営会社の証跡と対応。"
    if '施設型名称' in groups:
        note += '施設名は店舗の立地・名称の一部。対象は食品スーパーの個店。'
    if 'BLΛNDE' in name:
        note += 'カスミの開店資料で食品スーパーの業態と当該店を照合。'
    return ('通常掲載維持',method,original,operator if operator!=original else '',note)

if __name__=='__main__':
    import csv
    rows = read_csv(PREVIOUS/'evidence/national-master-4728.csv')
    issued = {r['全国統合ID'] for r in read_csv(PREVIOUS/'out/新規IDと候補キー対応表.csv')}
    log = {r['url']:r for r in json.loads((EVIDENCE/'source-log.json').read_text())}
    with (EVIDENCE/'review-decisions.csv').open('w',encoding='utf-8-sig',newline='') as file:
        writer=csv.writer(file)
        writer.writerow(['全国統合ID','限定監査判定','確認方法','主根拠URL','照合・補足URL','判定理由'])
        for uid,(row,groups,individual) in select(rows,issued).items():
            writer.writerow((uid,*as_review(row,groups,individual,log)))
