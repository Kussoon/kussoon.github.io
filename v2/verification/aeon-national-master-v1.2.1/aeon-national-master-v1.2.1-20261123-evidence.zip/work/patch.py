from collections import Counter
import argparse
import json
from pathlib import Path

from openpyxl import Workbook, load_workbook
from publish import aggregate, coordinate_queue, provenance, normal_proof
from util import PUB, bookpart, writebook, writecsv, sha256
from scope import read_csv, select, TARGET, SOCOLA

VERSION = 'Ver.1.2.1'
UID = '全国統合ID'
CATEGORY = '公開区分'
EXCLUDED = '対象外'
DATE = '2025-10-05'
CHECKED = '2026-11-24'
FACILITY_URL = 'https://www.daiei.co.jp/stores/d0318/'
SOCOLA_URL = 'https://www.daiei.co.jp/stores/d0890/'
CLOSE_URL = 'https://amagasaki.goguynet.jp/2025/11/05/palette-tsukaguchi-renewal-1119/'
REOPEN_URL = 'https://amagasaki.goguynet.jp/2025/11/21/palette-tsukaguchisc-renewal-open/'
LIVING_URL = 'https://mrs.living.jp/hyogo/newopen/article/6366315'
REASON = '塚口さんさんタウン1番館は専門店施設として営業。旧ダイエー塚口店の直営食品売場は2025年10月5日閉店。同じ2階に衣料品店パレットが2025年11月19日に増床開業。'
EXTRA = ('施設営業状況', '食品スーパー営業状況', '食品スーパー営業終了日', '食品スーパー営業終了根拠URL')
COMPARE = ('全国統合ID','都道府県','系列分類','表示用店舗名','有効屋号')
SOURCE_FIELDS = (*EXTRA,)

def sheet_values(sheet):
    lines = iter(sheet.values)
    header = tuple(next(lines))
    assert len(header) == len(set(header))
    rows = []
    for row in lines:
        assert len(row) <= len(header)
        rows.append(dict(zip(header, tuple('' if value is None else value for value in row) + ('',) * (len(header)-len(row)))))
    return header, rows

def columns(rows, fields):
    return [{key:row.get(key,'') for key in fields} for row in rows]

def update_row(row, logs):
    correction = {
        '公開区分': EXCLUDED,
        '掲載区分': EXCLUDED,
        '基準日営業状況': '施設営業中・食品スーパー営業終了',
        '営業状態': '施設営業中・食品スーパー営業終了',
        '施設営業状況': '営業中（ダイエー公式専門店案内）',
        '食品スーパー営業状況': '閉店（旧ダイエー塚口店・イオンフードスタイル）',
        '食品スーパー営業終了日':DATE,
        '食品スーパー営業終了根拠URL':CLOSE_URL,
        '公開区分理由': REASON,
        '掲載区分根拠': CLOSE_URL,
        '施設・核店舗区分': '商業施設（ダイエー直営食品核の営業終了）',
        '営業判定根拠URL': FACILITY_URL,
        '営業判定根拠説明': REASON,
        '掲載適格性': '対象外（食品スーパーの営業終了・商業施設）',
        '掲載適格性根拠URL': CLOSE_URL,
        '掲載適格性補足資料URL': ' ／ '.join((FACILITY_URL,REOPEN_URL,LIVING_URL)),
        '掲載適格性根拠説明': REASON + ' ソコラ塚口店（南塚口町2-1-3）は別店舗。',
        '座標再確認の要否': '対象外・履歴を別管理',
        '次工程': '座標調査対象外（施設行を継続管理）',
    }
    if FACILITY_URL in logs:
        correction['営業確認日時UTC'] = logs[FACILITY_URL]['time_utc']
        correction['営業応答SHA-256'] = logs[FACILITY_URL].get('response_sha256','')
    if CLOSE_URL in logs:
        correction['掲載適格性資料取得日時UTC'] = logs[CLOSE_URL]['time_utc']
    return row | correction

def history(old, current):
    differences = []
    for uid, previous in old.items():
        row = current[uid]
        assert row[UID] == uid
        for key in row.keys():
            before = previous.get(key,'')
            if before != row[key] and key != '台帳版':
                differences.append({
                    **{k:row[k] for k in COMPARE},
                    '修正項目':key, 'Ver.1.2':before, VERSION:row[key],
                    '営業終了日':DATE,'判定日':CHECKED,'変更理由':REASON,
                    '根拠URL':FACILITY_URL+' ／ '+CLOSE_URL+' ／ '+REOPEN_URL,
                })
    return differences

def collect_audit(old, issued, current, evidence):
    records = read_csv(evidence/'review-decisions.csv')
    review = {r[UID]:r for r in records}
    scope = select(old.values(),issued)
    assert len(scope)==len(records)==len(review) and review.keys()==scope.keys()
    return [
        {UID:uid, '店舗名':r['表示用店舗名'], '都道府県':r['都道府県'], '系列':r['系列分類'],
         '監査対象':groups, 'Ver.1.2公開区分':r[CATEGORY], 'Ver.1.2.1公開区分':current[uid][CATEGORY],
         'Ver.1.2掲載根拠URL':r['掲載適格性根拠URL'], **{k:v for k,v in review[uid].items() if k!=UID},
         '監査日':CHECKED}
        for uid,(r,groups,_) in scope.items()
    ]

def summary_sheets(summary):
    return [('全国・都道府県',group(summary,'全国','都道府県')),('系列',group(summary,'系列')),
            ('屋号',group(summary,'屋号')),('実運営法人',group(summary,'実運営法人')),
            ('系列と都道府県',group(summary,'系列×都道府県'))]

def group(summary, *axes):
    return [r for r in summary if r['集計軸'] in axes]

def same_coordinates(old, current):
    fields = ['緯度','経度','座標精度区分','座標取得方法','座標根拠URL','座標確認日','位置区分','座標備考','座標継承資料']
    assert columns(old.values(),fields)==columns(current.values(),fields)
    return sum(bool(r['緯度'] and r['経度']) for r in current.values())

def build(previous, audit_inputs, output):
    source = previous/'全国統合マスターVer1.2-20261123.xlsx'
    output.mkdir(parents=True,exist_ok=True)
    old_hash = sha256(source)
    old_book = load_workbook(source, read_only=True, data_only=False)
    header, original = sheet_values(old_book['全国統合マスター'])
    old = {r[UID]:r for r in original}
    assert len(original)==len(old)==4728 and all(old) and old[TARGET][CATEGORY]=='通常掲載'
    logs = {r['url']:r for r in json.loads((audit_inputs/'source-log.json').read_text())}
    current = {uid:(update_row(row,logs) if uid==TARGET else row.copy()) | {'台帳版':VERSION} for uid,row in old.items()}
    assert old.keys()==current.keys() and current[SOCOLA][CATEGORY]=='通常掲載'
    assert all(r['公式住所原文']==current[u]['公式住所原文'] and r['公式店舗URL']==current[u]['公式店舗URL'] for u,r in old.items())
    assert same_coordinates(old,current)==318
    fields = header+EXTRA
    classes = {k:[r for r in current.values() if r[CATEGORY]==k] for k in PUB}
    for r in classes['通常掲載']:
        normal_proof(r)
    transitions = [(uid,old[uid][CATEGORY],r[CATEGORY]) for uid,r in current.items() if old[uid][CATEGORY]!=r[CATEGORY]]
    assert transitions==[(TARGET,'通常掲載','対象外')]
    counts = dict(Counter(r[CATEGORY] for r in current.values()))
    assert counts=={'通常掲載':4613,'対象外':26,'参考・保留':75,'履歴・休業・予定':14}
    h_count = sum(r['都道府県']=='兵庫県' for r in classes['通常掲載'])
    assert h_count==176
    summary, previous_summary = aggregate(current), aggregate(old)
    assert len(summary)==len(previous_summary)
    summary_diff = []
    for before, after in zip(previous_summary, summary, strict=True):
        identifiers = ('集計軸','分類1','分類2')
        assert all(before[k]==after[k] for k in identifiers)
        if before!=after:
            summary_diff.append({k:after[k] for k in identifiers} |
                {k:after[k]-before[k] for k in ('通常掲載','参考・保留','対象外','履歴・休業・予定','全行')})
    coord = coordinate_queue(current)
    diff = history(old,current)
    assert {r[UID] for r in diff}=={TARGET}
    _, issued_rows = sheet_values(old_book['新規ID発行管理'])
    issued = {r[UID] for r in issued_rows}
    assert len(issued)==27
    audit = collect_audit(old, issued, current, audit_inputs)

    changes = {}
    changes['全国統合マスター'] = (fields, list(current.values()))
    categories = { '通常掲載店舗':'通常掲載', '参考・保留店舗':'参考・保留', '履歴・休業・予定':'履歴・休業・予定', '対象外':'対象外'}
    for title, category in categories.items():
        old_fields = tuple(next(old_book[title].values))
        changes[title] = (old_fields+EXTRA if category==EXCLUDED else old_fields, classes[category])
    changes['公式情報・証跡管理'] = (tuple(next(old_book['公式情報・証跡管理'].values))+SOURCE_FIELDS,
                                      [p | {k:current[p[UID]].get(k,'') for k in SOURCE_FIELDS} for p in provenance(current)])
    changes['全国・都道府県別集計'] = (None,group(summary,'全国','都道府県'))
    changes['運営会社・系列・屋号別集計'] = (None,group(summary,'系列','実運営法人','屋号'))
    changes['系列と都道府県別集計'] = (None,group(summary,'系列×都道府県'))
    changes['座標調査進捗管理'] = (None,coord)
    changes['新規ID発行管理'] = (None,[r | {'Ver1.2.1公開区分':current[r[UID]][CATEGORY]} for r in issued_rows])
    _, hyogo = sheet_values(old_book['兵庫県公開版との対応'])
    changes['兵庫県公開版との対応'] = (None,[r | {
        '全国Ver1.2.1公開区分':current[r[UID]][CATEGORY],
        'Ver1.2.1照合結果':'施設・旧直営食品閉店のため対象外' if r[UID]==TARGET else '通常掲載・公開版と対応'}
        for r in hyogo])
    _, candidates = sheet_values(old_book['候補159キーの採否とID'])
    changes['候補159キーの採否とID'] = (None,[r | {
        'Ver1.2.1採否':'対象外施設としてIDを保持' if r['Ver1.2発行ID']==TARGET else '',
        'Ver1.2.1根拠URL':CLOSE_URL if r['Ver1.2発行ID']==TARGET else ''}
        for r in candidates])
    _, definitions = sheet_values(old_book['調査基準・データ項目定義'])
    changes['調査基準・データ項目定義'] = (None,definitions+[
        {'項目':'施設営業状況・食品スーパー営業状況','定義':'施設の専門店営業と直営食品核店舗の営業を別々に管理。','扱い':'公式一覧への掲載は食品取扱いの根拠としない。'},
        {'項目':'食品スーパー営業終了日・根拠URL','定義':'閉店日とその資料を独立して収録。','扱い':'商業施設が存続する場合もIDを保持し、食品核の扱いを明記する。'},
        {'項目':'限定監査','定義':'新規採用27店、要確認からの採用6店、施設型名称を持つ通常掲載店の和集合。ソコラ塚口店を比較に追加。','扱い':'個店の食品売場等の証跡と食品スーパー業態の証跡を区別。'},
    ])
    book = Workbook(write_only=True)
    book.properties.title = '全国イオン系列スーパー 全国統合マスター Ver.1.2.1'
    for name in old_book.sheetnames:
        previous_sheet = old_book[name]
        if name in changes:
            row_fields, rows = changes[name]
        else:
            row_fields, rows = sheet_values(previous_sheet)
        bookpart(book,name,rows,row_fields,hidden=previous_sheet.sheet_state=='hidden')
    old_book.close()
    bookpart(book,'Ver1.2.1変更履歴',diff)
    bookpart(book,'Ver1.2.1限定監査',audit)
    bookpart(book,'Ver1.2.1集計増減',summary_diff)
    destination = output/'全国統合マスターVer1.2.1-20261123.xlsx'
    book.save(destination)

    normal_fields = changes['通常掲載店舗'][0]
    writecsv(output/'通常掲載店舗.csv',columns(classes['通常掲載'],normal_fields))
    writecsv(output/'全国・都道府県・系列・屋号別集計.csv',summary)
    writecsv(output/'座標調査への引継ぎ.csv',coord)
    writecsv(output/'限定監査結果.csv',audit)
    writebook(output/'限定監査結果.xlsx',[('全対象',audit),('新規27店舗',[r for r in audit if '新規採用' in r['監査対象']]),
        ('施設等の名称',[r for r in audit if '施設型名称' in r['監査対象']]),('要確認からの採用6店',[r for r in audit if '要確認から' in r['監査対象']])])
    writebook(output/'Ver1.2からの差分一覧.xlsx',[('項目別差分',diff),('集計増減',summary_diff)])
    writebook(output/'確定集計.xlsx',summary_sheets(summary))
    verify(old,current,destination,source,old_hash,changes)
    quality = {
        '台帳版':VERSION, '台帳基準日':'2026-11-23','監査日':CHECKED,
        '親Excelの作業前後SHA-256':old_hash,'修正版SHA-256':sha256(destination),
        '継承ID':len(current),'ID空欄・重複':0,'公式住所原文と個店URL継承':len(current),
        '公開区分':counts,'兵庫県通常掲載':h_count,'座標継承':318,
        '出版用抽出・集計との整合':True,'過去の判断・変更・既往座標履歴':True,'Excel全シート再読込':True,
        '変更ID':TARGET,'変更行数':len(transitions),'限定監査の実数':len(audit),
        '限定監査内訳（重複あり）':dict(Counter(group for r in audit for group in r['監査対象'].split(' / '))),
        '限定監査の確認方法':dict(Counter(r['確認方法'] for r in audit)),
    }
    (output/'品質検証.json').write_text(json.dumps(quality,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return quality

def verify(old, current, destination, source, old_hash, changes):
    assert sha256(source)==old_hash
    new = load_workbook(destination,read_only=True,data_only=False)
    before = load_workbook(source,read_only=True,data_only=False)
    assert set(before.sheetnames) <= set(new.sheetnames)
    for name in before.sheetnames:
        if name not in changes:
            assert all(a==b for a,b in zip(before[name].values,new[name].values,strict=True)), name
            assert before[name].sheet_state==new[name].sheet_state
            continue
        head, rows = sheet_values(new[name])
        _, expected = changes[name]
        assert rows == columns(expected,head),name
    views = [row[UID] for row in read_csv(destination.parent/'通常掲載店舗.csv')]
    assert views==[u for u,r in current.items() if r[CATEGORY]=='通常掲載']
    assert set(current)==set(old) and TARGET not in views and SOCOLA in views
    before.close()
    new.close()

if __name__=='__main__':
    parser = argparse.ArgumentParser()
    for key in ('previous','audit_inputs','output'):
        parser.add_argument(key, type=Path)
    args = parser.parse_args()
    print(json.dumps(build(args.previous,args.audit_inputs,args.output),ensure_ascii=False))
