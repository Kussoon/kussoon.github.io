from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from time import sleep
from urllib.parse import urlsplit
import httpx
from charset_normalizer import from_bytes
from lxml import html
from scope import select, read_csv

root = Path(__file__).resolve().parents[1]
old = root.parent / 'v12-build'
stores = read_csv(old/'evidence/national-master-4728.csv')
new = {r['全国統合ID'] for r in read_csv(old/'out/新規IDと候補キー対応表.csv')}
extra = [
'https://mrs.living.jp/hyogo/newopen/article/6366315',
'https://amagasaki.goguynet.jp/2025/11/05/palette-tsukaguchi-renewal-1119/',
'https://amagasaki.goguynet.jp/2025/11/21/palette-tsukaguchisc-renewal-open/',
'https://tenpo.aeon-kyushu.info/detail/higashinagasaki/',
'https://www.aeon.com/store/イオン/イオンスタイル市川コルトンプラザ/shop_info/hours/',
'https://plaza-ooshima.aeonkyushu.com/',
'https://www.aeonbig.co.jp/about/',
'https://aeonbig.co.jp/about/company/',
'https://www.nikke-cp.gr.jp/shop/index.jsp?bf=1&shopid=457',
'https://tenpo.aeon-kyushu.info/detail/parkplace-oita/shoplist-service/850505/',
'https://tenpo.aeon-kyushu.info/detail/higashinagasaki/shoplist-service/866989/',
'https://aeonasahikawashunko.com/shops/detail/25',
'https://tokubai.co.jp/officialized_shops/115234',
'https://tokubai.co.jp/officialized_shops/14840',
'https://tokubai.co.jp/officialized_shops/14851',
'https://tokubai.co.jp/officialized_shops/14853',
'https://tokubai.co.jp/officialized_shops/14860',
'https://tokubai.co.jp/officialized_shops/6034',
'https://tokubai.co.jp/officialized_shops/14833',
'https://tokubai.co.jp/officialized_shops/258501',
'https://amagasaki.goguynet.jp/2025/08/01/daiei-tsukaguchi-heiten-yotei/',
'https://www.palette-age.jp/',
'https://cocosa.jp/shop/detail.html?act=10740',
'https://www.aeontown.co.jp/kamaishi/shop/detail/?id=000432',
'https://tokubai.co.jp/officialized_shops/16386',
'https://www.aeonbig.co.jp/newstore/index.html',
'https://www.the-fuji.com/company/docs/20260407_tanshin_shiryou_jp.pdf',
'https://www.aeonsupercenter.co.jp/reference/release/news_suc20241015.pdf',


]
urls = set(extra)
for row,groups,individual in select(stores,new).values():
    if individual:
        urls |= {row['掲載適格性根拠URL'], row['公式店舗URL']}
    elif '新規採用' in groups or '要確認から通常掲載' in groups:
        urls.add(row['掲載適格性根拠URL'])
log = root/'evidence/source-log.json'
previous = json.loads(log.read_text()) if log.exists() else []
checked = {r['url'] for r in previous}
groups = defaultdict(list)
for url in sorted(urls):
    if url.startswith('https://') and url not in checked:
        groups[urlsplit(url).hostname].append(url)

def fetch_group(urls):
    results = []
    session = httpx.Client(follow_redirects=True)
    for url in urls:
        key = hashlib.sha256(url.encode()).hexdigest()[:16]
        row = {'url':url, 'time_utc':datetime.now(timezone.utc).isoformat(), 'key':key}
        try:
            response = session.get(url, timeout=12)
            row.update(status=response.status_code, final_url=str(response.url),
                       response_sha256=hashlib.sha256(response.content).hexdigest())
            if response.is_success and response.content.startswith(b'%PDF'):
                row['format'] = 'pdf'
                (root/'evidence/sources'/f'{key}.pdf').write_bytes(response.content)
            elif response.is_success:
                try:
                    decoded = response.content.decode('utf-8')
                except UnicodeDecodeError:
                    decoded = str(from_bytes(response.content).best())
                doc = html.fromstring(decoded)
                for tag in doc.xpath('//script|//style|//noscript|//svg'):
                    tag.drop_tree()
                lines = [line.strip() for line in doc.itertext() if line.strip()]
                loc = [line for line in lines if any(x in line for x in ('食品','食料','閉店','営業終了','増床','パレット','チラシ','フロア','専門店','生鮮','営業時間','本日'))]
                row['title']=doc.xpath('normalize-space(//title)')
                row['screen_lines']=len(loc)
                # Retain official documents and a limited index of signals. Local reporting is cited with summaries.
                if urlsplit(url).hostname not in ('amagasaki.goguynet.jp','mrs.living.jp'):
                    (root/'evidence/sources'/f'{key}.html').write_bytes(response.content)
                (root/'work'/f'{key}.txt').write_text('\n'.join(lines),encoding='utf-8')
            if response.status_code == 429:
                results.append(row)
                break
        except (httpx.HTTPError, ValueError) as err:
            row['error']=type(err).__name__
        results.append(row)
        sleep(.5)
    return results

with ThreadPoolExecutor(max_workers=8) as pool:
    found = previous + [row for batch in pool.map(fetch_group,groups.values()) for row in batch]
(root/'evidence/source-log.json').write_text(json.dumps(found,ensure_ascii=False,indent=2),encoding='utf-8')
print(len(found), len(urls), sorted((x.get('status',0),x.get('url')) for x in found if x.get('status')!=200))
