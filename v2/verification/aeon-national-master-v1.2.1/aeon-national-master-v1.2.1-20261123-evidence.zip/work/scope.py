import csv
import re
from pathlib import Path
from unicodedata import normalize

MARKER = re.compile(r'(?:SC(?=$|[店\s（(・/-])|ショッピング|スーパーセンタ|イオンタウン|イオンモール|サティ|スーパーモール|プラザ|パークプレイス|ゆめタウン|パワーシティ|フジグラン|ショッパーズ|ポスフール|スーパーバリュー|ショッピングパーク)', re.I)
STRONG = re.compile(r'SC(?=$|[店\s（(・/-])|ショッピングセンタ|ショッピングモール|ショッピングプラザ|スーパーモール', re.I)
GENERAL_BRANDS = {'イオン', 'イオン・イオンスタイル', 'イオンフードスタイル', 'ダイエー', 'イオンスーパーセンター', 'フジ', 'フジグラン', 'COCOSA B1'}
TARGET = 'AE-930DE18690445E1A'
SOCOLA = 'JP-28-000047'

def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as file:
        return list(csv.DictReader(file))

def select(rows, issued):
    selected = {}
    for row in rows:
        if row['公開区分'] != '通常掲載':
            continue
        uid = row['全国統合ID']
        names = normalize('NFKC', ' '.join(row[k] for k in ('店舗名','公式店舗名','現行公式名','表示用店舗名')))
        facility = bool(MARKER.search(names) or '施設全体と明確に区分' in row['掲載適格性根拠説明'])
        groups = []
        if uid in issued:
            groups.append('新規採用')
        if facility:
            groups.append('施設型名称・出店施設名')
        if row['旧掲載区分'] == '要確認':
            groups.append('要確認から通常掲載')
        if uid == SOCOLA:
            groups.append('塚口SC比較')
        if not groups:
            continue
        primary = normalize('NFKC', row['表示用店舗名'])
        check_food = (uid in (TARGET, SOCOLA) or
                      row['掲載適格性'] == '総合スーパーの食品売場確認' or
                      (facility and (bool(STRONG.search(primary)) or row['有効屋号'] in GENERAL_BRANDS))
                      or row['有効屋号'] == 'COCOSA B1' or primary.startswith('フジグラン'))
        selected[uid] = (row, ' / '.join(groups), check_food)
    return selected

if __name__=='__main__':
    previous = Path('/workspace/v12-build')
    rows = read_csv(previous/'evidence/national-master-4728.csv')
    issued = {r['全国統合ID'] for r in read_csv(previous/'out/新規IDと候補キー対応表.csv')}
    selected = select(rows, issued)
    for uid, (row, groups, detailed) in selected.items():
        print(uid,row['表示用店舗名'],groups,detailed,row['掲載適格性根拠URL'],row['掲載適格性根拠説明'],row['掲載適格性補足資料URL'],row['公式店舗URL'],sep='\t')
