import re
from collections import defaultdict
from pathlib import Path
from audit_core import *

HATSU='https://nagareyama-noda.goguynet.jp/2026/10/31/maruetsuhatuishiten/'
SIGN='https://nagareyama-noda.goguynet.jp/wp-content/uploads/sites/111/2026/10/2610301702417092.jpg'
ASAHI='https://www.aeon-hokkaido.jp/aeon/shop/asahikawanishi/'
FUJI='https://www.the-fuji.com/company/ir/monthly/'
FUKU='https://www.aeon-kyushu.info/files/optionallink/00000681_file.pdf'
CORE='https://tenpo.aeon-kyushu.info/detail/big-fukuokahigashi/'
DRUG='https://www2.jpx.co.jp/disc/26530/140120260408599933.pdf'
CHOICES={
 '候補-857f13924a92':('閉店・休業・予定の別管理','https://www.the-fuji.com/company/docs/20260407_tanshin_shiryou_jp.pdf','会社決算資料の閉店店舗。2026年1月閉店。','','2026-01'),
 '候補-5bd5601ee39c':('閉店・休業・予定の別管理',FUJI,'会社月次資料の2026年8月31日閉店・後継は2027年冬予定。施設の履歴を保持。','','2026-08-31'),
 '候補-4f6a673fc13a':('閉店・休業・予定の別管理',SIGN,'マルエツ名義の店頭掲示写真（第三者記事に掲載）で11/15 18時閉店を確認。2026年は記事日付と曜日で突合。旧公式個店は転送。','','2026-11-15'),
 '候補-ab100d068e2e':('閉店・休業・予定の別管理','https://www.aeon-kyushu.info/files/optionallink/00000787_file.pdf','会社の11月17日開店発表。基準日後のため開店予定に記録。','','2026-11-26'),
 '候補-f3bfc63c49f8':('閉店・休業・予定の別管理','https://www.aeon-kyushu.info/files/optionallink/00000789_file.pdf','会社の11月18日開店発表。福岡県の店は基準日後。兵庫県の同名店との別店舗。','','2026-12-03'),
 '候補-5d1edd6f717f':('対象外','https://store.welcia.co.jp/welcia/spot/detail?code=3773D','個店公式と厚生労働省医療情報にドラッグストア・調剤。食品スーパー基準の独立店舗として扱わない。','',''),
 '候補-805507640962':('既存IDで掲載済み',ASAHI,'英語カードはイオン旭川西店の英語表記。食品核の既存IDを採用審査。','AE-2D0C32DF03A4EFE2',''),
 '候補-a5326a2b1287':('既存IDで掲載済み','https://www.daiei.co.jp/stores/0003/','読み仮名カード。会社個店・既存行の住所と店番号が同じ。','JP-27-000010',''),
}
# These keys are alternate language names of the same pending physical branch.
ALIAS={'候補-8b2b7b5dc8de':'候補-d38ab284a6dc','候補-690b3d937e51':'候補-9454a5da67a0'}
EXTRA={
 '候補-d38ab284a6dc':('https://www.aeon-hokkaido.jp/mv/shop/shizunai/','マックスバリュ','運営会社個店の食品スーパー。イオン静内店は別住所・別屋号。'),
 '候補-9454a5da67a0':('https://www.aeon-hokkaido.jp/big/shop/iwamizawa/','ザ・ビッグ','運営会社個店の食品ディスカウント業態。イオン岩見沢店と別住所。'),
 '候補-c5ef523aa673':('https://tenpo.aeon-kyushu.info/detail/mvex-futsukaichi/','マックスバリュエクスプレス','食品スーパーの同一個店。イオン二日市店と別住所・屋号。'),
 '候補-ce722a345fe1':('https://tenpo.aeon-kyushu.info/detail/mvex-chikushiekimae/','マックスバリュエクスプレス','運営会社個店と筑紫野市一覧。同一店舗の食品スーパー業態。'),
 '候補-5c35f0cf0074':('https://tenpo.aeon-kyushu.info/big/detail/big-munakata/','ザ・ビッグ','運営会社個店。くりえいと宗像店と別住所・屋号。'),
 '候補-5d3a442d3e32':('https://tenpo.aeon-kyushu.info/aeon/detail/honami/shoplist-service/849027/','イオン','同一センター内の「イオン（食品）」を核店舗として1店に限定。'),
 '候補-c7b64f55b70c':('https://tenpo.aeon-kyushu.info/aeon/detail/amagi/shoplist-service/849484/','イオン','会社公式の直営イオンと食品レジ・売場。センター名のみの追加を避け核店舗として計上。'),
 '候補-18f1553194de':('https://tenpo.aeon-kyushu.info/detail/futsukaichi/','イオン','運営会社個店と会社の1F食品レジ区画案内。別住所の食品小型店と区別。'),
 '候補-819cf861e1d8':('https://www.daiei.co.jp/stores/d0318/','ダイエー','塚口SC店の当該住所。別住所のソコラ塚口店と区別。'),
}
EXTRA_PRODUCT={
 '候補-5d3a442d3e32':('イオン穂波店','https://tenpo.aeon-kyushu.info/detail/honami/','https://tenpo.aeon-kyushu.info/aeon/detail/honami/shoplist-service/849027/'),
 '候補-c7b64f55b70c':('イオン甘木店','https://tenpo.aeon-kyushu.info/detail/amagi/','https://space.aeon-kyushu.info/spaces/809/lease'),
 '候補-18f1553194de':('イオン二日市店','https://tenpo.aeon-kyushu.info/detail/futsukaichi/','https://space.aeon-kyushu.info/spaces/126/lease'),
}
COL_DUP=[
 ('AE-C21921EE6375BF6B','AE-803C5CB80A357E2D','株式会社ダイエー','https://www.daiei.co.jp/stores/4469/','KOHYO京都店','重複'),
 ('AE-DF71F8365C4FCD13','AE-97C669CA2D3E38F3','株式会社ダイエー','https://www.daiei.co.jp/stores/d0843/','ダイエー田辺SC店・イオンフードスタイル','重複'),
 ('AE-3A63FFDC285376FC','AE-4A5DB471A19B88BE','イオン九州株式会社',CORE,'ザ・ビッグ福岡東店','商業施設と食品核店舗'),
]
def corekey(s):
    return dense(s).casefold().replace('・','').replace('λ','a').removesuffix('店')
def street(s,pref):
    s=re.sub(r'^\s*〒?\d{3}[-－]\d{4}\s*','',nf(s or ''))
    s=re.split(r'[（(]|\s+イオン|\s+ビル',s,1)[0]
    while s.startswith(pref):s=s[len(pref):]
    s=s.replace('大字','').replace('の','')
    return normalize(s)
def near_rows(masters,n,adr,urls,pref,op):
    name=corekey(n); ordered=[]
    loc=street(adr,pref)
    url={cal(u) for u in urls if u and '/store/list/' not in unquote(u)}
    for m,a in masters:
        if m['都道府県']!=pref:continue
        names=[m['店舗名'],m.get('現行公式名'),a['公式店舗名']]
        name_match=any(name==corekey(x) or key(n,op)==key(x,op) for x in names if x)
        addresses=[street(m['住所'],pref),street(a['公式住所原文'],pref)]
        address_match=bool(loc and len(loc)>6 and any(loc==v or (v.startswith(loc) and not (v[len(loc):len(loc)+1].isnumeric() or v[len(loc):len(loc)+1]=='-')) or (v and len(v)>6 and loc.startswith(v) and not (loc[len(v):len(v)+1].isnumeric() or loc[len(v):len(v)+1]=='-')) for v in addresses if v))
        is_link=any(cal(u) in url for u in (a['台帳公式URL'],a['住所証跡URL']) if u and ('/detail/' in unquote(u) or '/stores/' in unquote(u) or '/tenpotop/' in unquote(u) or '/shop/' in unquote(u)))
        if address_match or name_match or is_link:
            ordered.append((m['全国統合ID'],m['掲載区分'],m['店舗名'],address_match,name_match,is_link))
    return ordered
def evidence(src,u,name='',addr=''):
    res=[]
    for r,p,k in src.get(page_key(u),[]):
        if p.suffix.lower()=='.pdf':continue
        title,body=contents(p)
        n=corekey(name)
        if n and n not in corekey(title+' '+body):continue
        if addr:
            norm=normalize(addr)
            if norm not in normalize(body):continue
        assert digest(p)==r['sha256']
        res.append(proof(r,k,name,'該当店舗名と公式掲載を確認。',u))
    return res[-1] if res else {}

def validate_extra(k,src,n,addr):
    u,brand,note=EXTRA[k]
    if k in EXTRA_PRODUCT:
        name,branch,food=EXTRA_PRODUCT[k]
        pe=evidence(src,branch,'',addr); fe=evidence(src,food)
        return name,branch,food,pe if pe and fe else {}
    pe=evidence(src,u,n,addr)
    if k=='候補-819cf861e1d8':
        n='塚口SC店'
        pe=evidence(src,u,n,addr)
    return n,u,u,pe

def candidate_tables(master,addr,src):
    base=ROOT/'r7/out/05-掲載漏れ重複と最終採否案.xlsx'
    ledger=sheet(base,'全159キーと採否案');history=sheet(base,'全290検出履歴');restored=sheet(base,'第5回修復の16判定')
    targets={r['候補キー']:r for r in sheet(base,'採用案3店舗')}
    reverse={r['既往候補キー']:r for r in sheet(base,'逆引き18店舗')}
    assert (len(ledger),len(history),len(restored),len(targets))==(159,290,16,3)
    targets18=[]; extra=[]; decision=[]; change=[]; duplicates=[]; comp=[]
    m_by={m['全国統合ID']:m for m in master}
    pairs=[(m,addr[m['全国統合ID']]) for m in master]
    prefixes={'ザ・ビッグエクストラ':'ザ・ビッグエクストラ','ザ・ビッグエクスプレス':'ザ・ビッグエクスプレス'}
    companies={'イオン北海道':'イオン北海道株式会社','イオン九州':'イオン九州株式会社','イオンリテール':'イオンリテール株式会社','イオンビッグ':'イオンビッグ株式会社','カスミ':'株式会社カスミ','ダイエー・イオンフードスタイル':'株式会社ダイエー'}
    for r in ledger:
        k=r['候補キー'];code=k; n=r['公式店舗候補'];pref=r['都道府県'];op=r['系列']; a=r['公式住所または確認候補住所']
        prev=r['第7回採否案']; judge=prev; reason=r['第7回理由']; url=r['第7回根拠URL']; official=n; pub=''; date=r['発効日・予定日']; uid=r['対応候補ID']; alt=''
        if prev=='判断保留':
            if k in CHOICES:judge,url,reason,uid,date=CHOICES[k]
            elif k in ALIAS:
                judge='別候補キーと重複';alt=ALIAS[k];reason='英語一覧のカードを日本語個店の候補キーへ統合。候補検出履歴を保持。';url=EXTRA[alt][0]
            elif k in EXTRA:
                n2,branch,food,pr=validate_extra(k,src,n,a)
                official=n2
                close=near_rows(pairs,n2,a,(branch,),pref,op)
                for x in close:comp.append({'候補キー':k,'全国統合ID':x[0],'既存区分':x[1],'既存名':x[2],'住所一致':x[3],'名称一致':x[4],'公式URL一致':x[5]})
                if pr and not close:
                    judge='新規掲載';url=branch
                    reason=EXTRA[k][2]+' 全系列・履歴を同県で照合し重複なし。'
                    extra.append(make_candidate(k,n2,pref,op,companies[op],EXTRA[k][1],a,branch,food,reason,pr,'追加審査',''))
                elif close:
                    reason='同県の既存ID候補あり。名称・住所・URLの比較を別表に記録。'
                    strong=[x for x in close if x[5] or x[3] and x[4]]
                    if strong:judge='既存IDで掲載済み';uid=' ／ '.join(x[0] for x in strong);url=branch
                else:
                    reason='運営会社公式情報に店舗を確認したが、住所・核店舗または基準日営業の採用資料を揃えられず。';url=branch
            elif 'エフ・マルシェ' in n:
                url='https://www.the-fuji.com/fmarche/'
                reason='運営会社公式に農畜水産品の直売・地産地消を明記。通常の食品スーパーと区別し、産直市場は参考・保留。'
            elif '食品・ドラッグ複合' in r['継承後判定']:
                reason='親会社の2026年度経営方針は生鮮食品のSMと調剤併設型ドラッグの融合業態。一般の食品スーパーとしての採用は保留し、業態基準承認後に再判断。'
                url=DRUG
        if prev=='新規掲載':
            b=targets.get(k,{}); rr=reverse.get(k,{})
            branch=b.get('根拠URL') or rr.get('個店導線') or url
            if op=='イオン北海道':branch='https://www.aeon-hokkaido.jp/big/shop/chitosebudokanmae/'
            if op=='イオンビッグ':branch='https://www.aeonbig.co.jp/stores/'
            if op=='カスミ':branch=rr.get('個店導線',branch)
            if op=='イオンリテール':branch=rr['食品売場・住所の補足公式URL']
            name_ask=official
            if op=='カスミ' and 'オリナス' in official:
                name_ask=official.split('（')[0]
            pr=evidence(src,branch,name_ask,a) or (evidence(src,branch,name_ask) if op=='カスミ' else {})
            if op=='イオンリテール':
                pr=evidence(src,'https://www.nishinihon.aeonretail.jp/pages/information',official)
            brand=b.get('屋号') or next((v for n,v in prefixes.items() if official.startswith(n)),('ザ・ビッグ' if op=='イオンビッグ' else 'イオン' if op=='イオンリテール' else 'フードスクエア' if 'フードスクエア' in official else 'カスミ'))
            close=near_rows(pairs,official,a,(branch if op!='イオンビッグ' else '',),pref,op)
            for x in close:comp.append({'候補キー':k,'全国統合ID':x[0],'既存区分':x[1],'既存名':x[2],'住所一致':x[3],'名称一致':x[4],'公式URL一致':x[5]})
            strong=[x for x in close if x[5] or x[3] and x[4]]
            if strong:
                judge='判断保留';uid=' ／ '.join(x[0] for x in strong);reason='旧屋号・履歴含む既存IDの対応候補を再審査。'
            else:
                judge='新規掲載'
                reason='全系列の通常・履歴・除外行を県内で名称・旧表示・公式URL・住所により突合。新規の反証なし。'+(' 会社地域一覧と店舗別の食品営業時間（公開索引）を採用。' if op=='イオンリテール' else '')
            url=branch
            if b:date=b.get('開店日','')
            targets18.append(make_candidate(k,official,pref,op,companies[op],brand,a,branch,b.get('営業根拠URL') or rr.get('一覧URL') or url,reason,
                            pr,'第7回指定18店',date,judge,close))
        if prev!=judge or prev=='判断保留' and reason!=r['第7回理由']:
            change.append({'候補キー':k,'前回採否案':prev,'今回採否案':judge,'根拠URL':url,'変更理由':reason,'確認日JST':CHECK})
        decision.append(r|{'重点監査採否案':judge,'今回根拠URL':url,'今回理由':reason,'関連既存ID':uid,'統合する候補キー':alt,
             '発効・予定日':date,'正式全国統合ID':''})
    for remove,keep,company,url,name,typ in COL_DUP:
        left,right=addr[remove],addr[keep]
        pref=left['都道府県']; assert pref==right['都道府県']
        assert street(left['公式住所原文'],pref)==street(right['公式住所原文'],pref) or street(left['公式住所原文'],pref) in street(right['公式住所原文'],pref),(left,right)
        pr=evidence(src,url,name)
        duplicates.append({'整理種別':typ,'通常掲載から外すID':remove,'残すID':keep,'除外側名称':left['店舗名'],'残す側名称':right['店舗名'],
          '運営会社':company,'公式店舗名':name,'公式住所':right['公式住所原文'],'除外側公式住所':left['公式住所原文'],'公式URL':url,
          '補足根拠URL':FUKU if typ!='重複' else '', '取得日時UTC':pr.get('取得日時UTC',''),'根拠SHA256':pr.get('根拠SHA256',''),
          '承認候補':'通常掲載から外し既存ID・旧屋号・関係を保存。統合先IDを記録。'})
    assert len(targets18)==18
    assert len({r['候補キー'] for r in targets18+extra})==len(targets18+extra)
    return targets18,extra,decision,history,restored,change,duplicates,comp

def make_candidate(k,n,pref,op,company,brand,addr,url,food,reason,proof_,origin,date,decision='新規掲載',near=()):
    return {'候補キー':k,'正式全国統合ID':'','発番準備キー':k,'基準日':BASIS,'公式店舗名':n,'都道府県':pref,'系列':op,'屋号':brand,'運営会社':company,
     '公式住所':addr,'採否案':'採用推奨' if decision=='新規掲載' else '要確認','基準日時点営業':OPEN if decision=='新規掲載' else '要確認',
     '食品適格性':GMS if brand=='イオン' else FOOD,'公式URL':url,'営業・食品補足URL':food,'開店日既知':date,
     '取得日時UTC':proof_.get('取得日時UTC',''),'根拠SHA256':proof_.get('根拠SHA256',''),'確認日JST':CHECK,
     '根拠・既存照合メモ':reason,'近似する既存ID':' ／ '.join(x[0] for x in near),'出典区分':origin}
