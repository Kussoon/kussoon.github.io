"""Make review tables for an approval-driven integration, preserving the original ledger."""
import re
from collections import Counter,defaultdict
from audit_core import *
from candidate_review import HATSU,SIGN,FUKU,CORE,ASAHI

FOOD_OK={'食品スーパー業態として確認','総合スーパーの食品売場確認'}
BAD_OP=OP_UNKNOWN|{'閉店','休業','一時閉店','開店予定','開店予定（11月27日）'}
RELATED={
 'AE-D16E7BD241CA2DB5':('対象外','会社が健康志向の専門セレクトショップと明示。食品の有無に関わらず食品スーパー集計の対象外。','https://www.aeon-kyushu.com/biolala/'),
 'AE-79777419C80B179E':('参考・保留','カスミつくばセンター内の実証店。一般客の入館・購入条件を確定できない。','https://www.kasumi.co.jp/tenpotop/ibaraki-south/tsukuba/293/'),
}
REVIEW_PROMOTE={'AE-8FED9941148BF551','AE-091D6D75BBA786CC','AE-5F7C7ED0BCD61313','AE-2D0C32DF03A4EFE2','AE-9472D50870140D81','AE-7FDAE0B87CE2603A'}
FOOD_RENAME={'AE-4A5DB471A19B88BE':'ザ・ビッグ','AE-7FDAE0B87CE2603A':'COCOSA B1'}
L1=ROOT/'r7/out/06-累計修正候補と反映審査.xlsx'
L2=ROOT/'r7/out/07-最終未解決事項と基準日後.xlsx'

def joined_results(master,addr,items,duplicate):
    o={r['全国統合ID']:r for r in csvrows(R7QA/'operation-4701.csv')}
    f={r['全国統合ID']:r for r in csvrows(R7QA/'eligibility-4701.csv')}
    fresh={(axis,r['全国統合ID']):r for axis,r in items}
    dup={r['通常掲載から外すID']:r for r in duplicate}
    rows=[];flags=[]
    for m in master:
        uid=m['全国統合ID']; a=addr[uid]; pdf=f[uid]; po=o[uid]; baseline=m['掲載区分']
        op_result=fresh.get(('営業',uid),{}); fd_result=fresh.get(('食品',uid),{})
        oldop=po['営業判定']; oldfood=pdf['第7回累計判定']
        op_v=op_result.get('重点監査判定',oldop); food=fd_result.get('重点監査判定',oldfood)
        op_url=op_result.get('根拠URL') or po['営業根拠URL']
        f_url=fd_result.get('根拠URL') or pdf['根拠URL']
        public={'通常候補':'通常掲載','履歴・休業・予定':'履歴','除外':'対象外'}.get(baseline,'参考・保留')
        reason='台帳掲載区分を継承。'; url=''
        integrated=''
        if uid in dup:
            row=dup[uid];public='対象外';reason=row['整理種別']+'のため通常掲載を統合先の1件に限定。';url=row['公式URL'];integrated=row['残すID']
        elif uid in RELATED:
            public,reason,url=RELATED[uid]
        elif baseline=='通常候補' and op_v in BAD_OP-OP_UNKNOWN:
            public='履歴'; reason='基準日時点の営業例外を確認。';url=op_url
        elif baseline=='通常候補' and food in ('食品スーパー対象外','食品を取り扱わないため対象外'):
            public='対象外';reason='掲載適格性の個別審査で対象外。';url=f_url
        elif baseline=='通常候補' and (op_v in OP_UNKNOWN or food in FOOD_UNKNOWN):
            public='参考・保留';reason='今回も営業または掲載適格性に未確定が残る。承認まで通常掲載試算から保留。';url=op_url or f_url
        elif baseline=='要確認' and uid in REVIEW_PROMOTE and op_v==OPEN and food in FOOD_OK:
            public='通常掲載';reason='食品核店舗の営業・食品スーパー業態または売場を公式確認。関連施設の除外を維持。';url=f_url or op_url
        both=uid in dup or (op_v not in OP_UNKNOWN and food not in FOOD_UNKNOWN)
        rows.append({'全国統合ID':uid,'店舗名':m['店舗名'],'都道府県':m['都道府県'],'市区町村':m['市区町村'],
          '系列':m['系列分類'],'屋号':m['屋号'] or a['公式屋号'] or '', '運営会社':m['運営会社'],
          '第7回営業判定':oldop,'重点監査営業判定':op_v,'営業根拠URL':op_url,
          '第7回掲載適格性':oldfood,'重点監査掲載適格性':food,'掲載適格性根拠URL':f_url,
          '公式住所原文':a['公式住所原文'],'公式住所根拠URL':a['住所証跡URL'],'基準日':BASIS,
          '現行掲載区分':baseline,'Ver1.2承認候補区分':public,'公開区分の理由':reason,'公開区分根拠URL':url,'統合先ID':integrated,
          '両軸の未確定解消':both})
        if (baseline=='通常候補')!=(public=='通常掲載'):
            flags.append(rows[-1])
    return rows,flags

def cot(s):
    return re.sub(r'株式会社|合同会社|有限会社|[()（）・\s]','',nf(s or ''))
def DATE(s):
    m=re.search(r'(20[12]\d)[-/年](\d{1,2})[-/月](\d{1,2})',nf(str(s or '')))
    return f'{m[1]}-{int(m[2]):02}-{int(m[3]):02}' if m else ''
def text_proof(s):
    return bool(s and re.search(r'https?://',s))
def corrections_review(master,addr,rows,results,duplicates):
    original=sheet(L1,'全管理キーの最終判断')
    history=sheet(L1,'候補判断の累計履歴')
    assert len(original)==2629 and len(history)==2899 and sum(r['反映審査結果']=='判断保留' for r in original)==324
    registry={r['全国統合ID']:r for r in rows}
    lookup={r['全国統合ID']:r for r in master}
    new=defaultdict(dict)
    for axis,r in results:
        if r['証跡再利用区分']!='保留' and r['重点監査判定']!=r['前回判定']:
            field='営業状況' if axis=='営業' else '掲載適格性'
            new[(r['全国統合ID'],field)]={'value':r['重点監査判定'],'url':r['根拠URL'],'reason':r['監査理由'],'stamp':r['取得日時UTC'],'old':r['前回判定']}
    for r in rows:
        uid=r['全国統合ID']; cat=r['Ver1.2承認候補区分']
        if cat not in ('通常掲載','参考・保留','対象外','履歴'):continue
        baseline={'通常候補':'通常掲載','履歴・休業・予定':'履歴','除外':'対象外'}.get(r['現行掲載区分'],'参考・保留')
        if baseline!=cat and r['公開区分根拠URL']:
            new[(uid,'掲載区分')]={'value':cat,'url':r['公開区分根拠URL'],'reason':r['公開区分の理由'],'stamp':'','old':r['現行掲載区分']}
    for row in duplicates:
        uid=row['通常掲載から外すID']
        new[(uid,'重複整理')]={'value':row['残すID'],'url':row['公式URL'],'reason':row['承認候補'],'stamp':row['取得日時UTC'],'old':''}
    outcome=[];logs=[]
    for r in original:
        uid,field=r['全国統合ID'],r['修正項目']; o=registry[uid]; a=addr[uid]; m=lookup[uid]
        before=r['反映審査結果']; value=r['反映推奨値']; evidence=r['根拠URL']; stage=before; note=r['反映審査理由']; stamp=r['取得日時UTC']
        src_kind='過去の判定・証跡'; event=''
        if before=='判断保留':
            candidate=r['候補値']; p=r['判定']
            if field=='住所' and a['住所証跡URL'] and a['公式住所原文']:
                stage='公式住所原文の採録';value=a['公式住所原文'];evidence=a['住所証跡URL'];stamp=a['取得日時UTC']
                note='運営会社等の店舗所在地原文を独立欄に採録。基準日住所・表示用住所・旧地番対応は別審査。'
            elif field=='運営会社' and candidate and cot(candidate)==cot(m['運営会社']):
                stage='法人格等の表記差・現行値維持';value=m['運営会社']
                note='法人名の核が一致。履歴と公式法人原文を保持し、系列・屋号は別審査。'
            elif field=='運営会社' and candidate and cot(candidate)==cot(a['公式運営会社']) and a['住所証跡URL'] and '運営会社個店' in a['住所確認資料種別'] and ('公式個店' in p or '統合発効日' in p or cot(candidate)==cot(m['グループ系列'])):
                stage='運営会社・系列・屋号の変更';value=candidate;evidence=a['住所証跡URL'];stamp=a['取得日時UTC']
                note='同一店舗の運営会社個店と候補法人表示を確認。発効日が判明する場合は別欄で記録。'
            elif field=='試験時の対応':
                need='営業' in candidate or '時点' in candidate or '発効' in candidate
                if (not need and a['公式住所原文']) or (need and o['重点監査営業判定'] not in OP_UNKNOWN):
                    stage='調査手順の記録・反映なし';value='';note='初期試験の手順メモ。構造化された住所・営業等の判定欄へ対応済み。'
            elif field=='店舗名' and candidate and key(candidate,m['系列分類'])==key(m['店舗名'],m['系列分類']):
                stage='名称表記差・現行値維持';value=m['店舗名'];note='店舗識別に使う名称の核が同じ。会社カードの屋号省略・文字幅を含む表記差。'
            elif field=='照合保留・営業時点' and o['重点監査営業判定'] not in OP_UNKNOWN and o['営業根拠URL']:
                stage='調査手順の記録・反映なし';value='';evidence=o['営業根拠URL'];note='営業状況・基準日の独立判定へ対応。旧試験手順は履歴として保持。'
        proposed=new.pop((uid,field),None)
        if proposed:
            value,evidence,note,stamp=(proposed[k] for k in ('value','url','reason','stamp'))
            stage='重複整理' if field=='重複整理' else '営業状況・掲載区分の変更' if field in ('掲載区分','営業状況') else '公式根拠により反映推奨'
            src_kind='重点監査の追加・再審査'
        if uid=='JP-27-000010' and field=='営業状況':event='2026-04-25'
        if uid=='AE-3A63FFDC285376FC' and field in ('営業状況','掲載区分','重複整理'):event='2026-07-28'
        if stage=='公式根拠により反映推奨' and field=='掲載適格性':
            if o['重点監査掲載適格性'] in FOOD_UNKNOWN or not text_proof(evidence):
                stage='判断保留';value='';note='独立した掲載適格性の最新根拠を確定できない。'
        if stage=='判断保留':
            note=(note or '候補の根拠未確定。')+' 基準日・候補値の裏付けおよび履歴間の矛盾を承認前に再確認。'
        if event and event>BASIS:stage='基準日後の事象・別管理'
        d=r|{'重点監査審査結果':stage,'承認候補値':value,'重点監査根拠URL':evidence,'根拠取得日時UTC':stamp,
             '発効日（確認済み）':event,'発効日扱い':'確認済み' if event else '明示なし。取得日と区別。',
             '店舗同一性の照合':'既存IDと根拠・住所・掲載を照合','今回承認理由':note,'審査資料':src_kind}
        outcome.append(d)
        if stage!=before or proposed:
            logs.append(new_history(uid,field,r['候補値'],value,stage,note,evidence,stamp))
    for (uid,f),p in sorted(new.items()):
        o=registry[uid]
        stage='重複整理' if f=='重複整理' else '営業状況・掲載区分の変更' if f in ('掲載区分','営業状況') else '公式根拠により反映推奨'
        outcome.append({'全国統合ID':uid,'店舗名':o['店舗名'],'都道府県':o['都道府県'],'修正項目':f,'台帳現行値':p['old'],
            '重点監査審査結果':stage,'承認候補値':p['value'],'重点監査根拠URL':p['url'],'根拠取得日時UTC':p['stamp'],
            '発効日（確認済み）':'2026-07-28' if uid=='AE-3A63FFDC285376FC' else '',
            '発効日扱い':'基準日営業等と取得日を区別','今回承認理由':p['reason'],'審査資料':'重点監査の追加'})
        logs.append(new_history(uid,f,p['old'],p['value'],stage,p['reason'],p['url'],p['stamp']))
    assert len(outcome)==len({(r['全国統合ID'],r['修正項目']) for r in outcome})
    assert all(r['根拠URL'] or r['判定'] in ('調査手順の記録・反映なし','名称表記差・現行値維持','法人格等の表記差・現行値維持','判断保留') for r in logs)
    unique=[r for r in outcome if r['修正項目']=='住所' and r['重点監査審査結果']=='公式住所原文の採録']
    orig_form=[{'全国統合ID':r['全国統合ID'],'店舗名':r['店舗名'],'公式住所原文':addr[r['全国統合ID']]['公式住所原文'],
          '基準日時点の住所（承認対象）':'','表示用住所（現行値保持）':addr[r['全国統合ID']]['台帳住所'],
          '旧住所との関係':'表記差や換地・枝番の関係は同一性根拠を個別確認。',
          '根拠URL':addr[r['全国統合ID']]['住所証跡URL'],'根拠取得日時UTC':addr[r['全国統合ID']]['取得日時UTC']} for r in unique]
    return outcome,history,logs,orig_form

def new_history(uid,f,old,v,p,n,url,stamp):
    return {'回次':'第2段階C重点監査','全国統合ID':uid,'修正項目':f,'旧値':old,'候補値':v,'判定':p,'理由':n,'根拠URL':url,'取得日時UTC':stamp,'確認日JST':CHECK}

def cases_latest(src,candidate):
    prior=sheet(L2,'個別案件の追加調査')
    follow={}
    for r in prior:
        n=r['対象']; v=r['第7回判定']; u=r['根拠URL']; handling=r['最終統合の扱い']; note=r['第7回根拠または保留理由']
        if n=='マルエツ初石店':
            v='基準日前に閉店';u=SIGN+' ／ '+HATSU+' ／ https://www.maruetsu.co.jp/store/9094/'
            handling='基準日の通常掲載対象外。候補キーに閉店履歴を保存。'
            note='マルエツ名義の店頭閉店告知を撮影した第三者記事の写真を判読。2026年11月15日18時。旧公式店舗URLは転送。'
        elif n=='イオン高知旭町店':
            u='https://www.pref.kochi.lg.jp/doc/2016051700019/ ／ '+u
            v='旧店舗の廃止届を確認・新施設の再開未確定'
            note='高知県の大規模小売店舗廃止届出表で旧店の2025年3月31日廃止。会社一覧は一時閉店表示。基準日の通常営業に含めない。'
            handling='旧店を履歴管理。後継プロジェクトの開店日・営業形態は公式発表待ち。'
        elif n=='イオンスタイル伊達':
            u='https://aeontohoku.co.jp/stores/date ／ https://file-cdn.aeonmall.jp/uploads/14e19511-eb9b-4f89-83f3-f85a92aa9fdb.pdf'
            v='11月27日のグランド開店を確認・基準日の一般営業は未確認'
            note='会社と施設運営会社の公表資料はグランド開店を11月27日と記載。住所は堂ノ内地区土地区画整理事業地内。ソフトオープンの一般客対象と番地は未確認。'
            handling='基準日集計は予定のまま。グランド開店を基準日後の事象として記録。'
        elif n=='イオン福岡東ショッピングセンター':
            v='食品核店舗が既存の別IDに掲載済み';u=CORE+' ／ '+FUKU
            note='2026年7月28日開店のザ・ビッグ福岡東店がAE-4A5DB471A19B88BEに掲載済み。施設AE-3A63FFDC285376FCと同一敷地。'
            handling='施設行は参考履歴と統合先IDを保存。公開通常掲載はザ・ビッグ福岡東店の1店。'
        elif n=='KASUMI LABO':
            note='会社個店に本社内の店舗情報。会社採用資料は実験店としての運用を扱う。県産品の販売店ポータルにも掲載されるが、一般客の入館・購入条件の明示は確認できず。'
            handling='通常掲載から参考・保留へ移す候補。一般客の利用条件が明示された場合に再審査。'
            u+=' ／ https://www.ibaraki-shokusai.net/shop/detail/17308'
        follow[n]=r|{'今回判定':v,'今回根拠URL':u,'今回の確認と残る理由':note,'公開時の取扱い案':handling}
    future=sheet(L2,'基準日後の事象')
    for r in candidate:
        v=r['発効・予定日'];n=r['公式店舗候補']
        if r['候補キー'] in ('候補-ab100d068e2e','候補-f3bfc63c49f8'):
            assert v>BASIS
            future.append({'対象':n,'日付':v,'区分':'運営会社の開店発表（基準日後）','根拠URL':r['今回根拠URL']})
    scope=csvrows(R7QA/'national-752.csv');seen=0
    out=[]
    for r in scope:
        current=r['第7回判定'];u=r['第7回根拠URL'];note=r['第7回判定理由']
        if r['系列']=='マルエツ' and r['都道府県']=='千葉県':
            assert current=='一部保留'
            current='全件突合完了';u=follow['マルエツ初石店']['今回根拠URL'];note='最後の保留カードは、マルエツ名義の店頭掲示写真で基準日前閉店を確認。掲示を収録した第三者記事と旧URLを併記。';seen+=1
        out.append(r|{'重点監査判定':current,'重点監査根拠URL':u,'重点監査理由':note})
    assert seen==1 and len(out)==752
    return list(follow.values()),future,out

def counts(rows,targets,extra):
    totals=defaultdict(Counter)
    def keys(pref,seq,brand):
        return [('全国','','',''),('都道府県',pref,'',''),('系列','',seq,''),('屋号','','',brand or '屋号未記録'),('系列×都道府県',pref,seq,'')]
    for r in rows:
        pref,seq,brand=r['都道府県'],r['系列'],r['屋号']
        for k in keys(pref,seq,brand):
            totals[k]['台帳行']+=1
            totals[k]['現行通常候補']+=r['現行掲載区分']=='通常候補'
        actual=FOOD_RENAME.get(r['全国統合ID'],brand)
        for k in keys(pref,seq,actual):
            v=totals[k];v['Ver1.2既存の'+r['Ver1.2承認候補区分']]+=1
    for r in targets+extra:
        if r['採否案']!='採用推奨':continue
        for k in keys(r['都道府県'],r['系列'],r['屋号']):
            totals[k]['新規指定18候補' if r['出典区分']=='第7回指定18店' else '追加採用候補']+=1
    res=[]
    for (axis,pref,seq,brand),cnt in sorted(totals.items()):
        a=cnt['Ver1.2既存の通常掲載']+cnt['新規指定18候補']
        res.append({'集計単位':axis,'都道府県':pref,'系列':seq,'屋号':brand,
          **{k:cnt[k] for k in ('台帳行','現行通常候補','Ver1.2既存の通常掲載','Ver1.2既存の参考・保留','Ver1.2既存の対象外','Ver1.2既存の履歴','新規指定18候補','追加採用候補')},
          '指定18店までの試算':a,'追加採用候補を含む試算':a+cnt['追加採用候補']})
    n=res[0];assert n['台帳行']==4701 and n['現行通常候補']==4658
    for ax in ('都道府県','系列','屋号','系列×都道府県'):
        for key_,v in n.items():
            if isinstance(v,int):assert v==sum(o[key_] for o in res if o['集計単位']==ax),(ax,key_)
    return res
