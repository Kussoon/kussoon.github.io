from pathlib import Path
from audit_core import *
from urllib.parse import urljoin

work=Path('.')
base=capture(work)
if not (work/'food-cards-log.json').exists():
    pending=[r for r in csvrows(work/'exports/eligibility-audit.csv') if r['証跡再利用区分']=='保留' and r['掲載区分']=='通常候補' and r['系列分類']=='イオン九州']
    pending.extend(r for r in csvrows(work/'exports/operation-audit.csv') if r['全国統合ID']=='AE-4CB0ACD09A631351')
    listing={}
    for r in pending:
        for u in r['照合したURL'].split(' ／ '):
            m=re.search(r'/detail/([a-zA-Z0-9_-]+)/$',u)
            if m:
                listing['https://tenpo.aeon-kyushu.info/aeon/detail/'+m[1]+'/shoplist-service/']=[r['全国統合ID'],r['店舗名']]
                break
    write(work/'food-cards-requests.json',listing)
else:
    follow={}
    for u,(uid,n) in js(work/'food-cards-requests.json').items():
        for rec,p,k in base.get(page_key(u),[])[-1:]:
            node=document(p.read_bytes())
            for a in node.xpath('//a[contains(@href,"/shoplist-service/")]'):
                link=urljoin(u,a.get('href'))
                if not re.search(r'/detail/'+re.escape(u.split('/detail/')[1].split('/')[0])+r'/shoplist-service/',link) or not re.search(r'/\d+/?$',link):continue
                label=dense(re.sub(r'^20\d{2}[./]\d{1,2}[./]\d{1,2}\s*','',text(a)))
                if re.match(r'(?:AEON|イオン)(?:1F|2F|1階|食品|$)',label,re.I) or label.casefold() in ('aeon','イオン','イオン直営'):
                    follow[link]=[uid,n]
    write(work/'food-core-requests.json',follow)
