"""Produce the final approval-candidate workbooks, aggregate tables and evidence logs."""
import argparse,hashlib
from collections import Counter
from datetime import datetime
from pathlib import Path
from zipfile import ZipFile
from build_results import csv_write
from finish700 import make_book
from tables6 import array
from audit_core import *
from candidate_review import candidate_tables,SIGN,HATSU
from integration import *

def verify_inputs(work):
    paths=[]
    for line in (R7/'inputs.sha256').read_text().splitlines():
        h,p=line.split('  ',1)
        p=Path(p)
        if not p.exists() and p.name==masterzip.name:p=masterzip
        assert digest(p)==h,p
        paths.append({'ファイル':p.name,'SHA256':h,'確認':'前回値一致'})
    expected={
        'aeon-round7-1-results.zip':'9de39aa280d953e7ee0aaf3e7ace74f305f27525065fc6c0ab57f686013346bc',
        'aeon-round7-2-evidence-part1.zip':'0f69b796ea77b3f9a5a25a4c342dbd418c61ccb2b70ee16a589372f8ba4c0aa7',
        'aeon-round7-2-evidence-part2.zip':'723617300aa9d9960dca0a72d274e5b42b0f0ad88f9de458216b14ea98a64c4a',
        'aeon-round7-2-evidence-part3.zip':'a60ff7ebf1dd14fe8ac17f5038ad6c4db241bfc490f2ab56f5c2d7b173c434b0',
    }
    for name,want in expected.items():
        p=ROOT/'r7/release'/name
        assert digest(p)==want,p
        paths.append({'ファイル':name,'SHA256':want,'確認':'第7回提出値一致'})
    return paths

def source_logs(work,src,ops,food,targets,case_review):
    answer=[]
    for p in sorted(work.glob('*-log.json')):
        for r in js(p):
            leaf=r.get('file')
            if leaf:
                loc=work/p.name.removesuffix('-log.json')/leaf
                assert digest(loc)==r['sha256'],loc
            tag=r.get('用途','')
            answer.append({'ログ区分':'今回取得（公式優先・補助資料を含む）','取得ログ':p.name}|r|{'用途':' ／ '.join(tag) if isinstance(tag,list) else tag})
    for module,values in [('営業',ops),('掲載適格性',food)]:
        for r in values:
            if not r['根拠URL']:continue
            answer.append({'ログ区分':r['資料種別'],'用途':module,'全国統合ID':r['全国統合ID'],'url':r['根拠URL'],
                           'fetched_at':r['取得日時UTC'],'sha256':r['根拠SHA256'],'確認日JST':CHECK})
    for r in targets:
        for u in (r['公式URL'],r['営業・食品補足URL']):
            answer.append({'ログ区分':'新規候補の根拠','用途':r['公式店舗名'],'候補キー':r['候補キー'],'url':u,
                           '確認日JST':CHECK})
    sign=work/'photo/2610301702417092.jpg'
    assert sign.is_file()
    answer.append({'ログ区分':'マルエツ名義の店頭告知を撮影した第三者資料','用途':'初石店閉店',
                   'url':SIGN,'掲載記事':HATSU,'file':'photo/'+sign.name,'sha256':digest(sign),'確認日JST':CHECK})
    return answer

def build(work,out,csv_only):
    out.mkdir(parents=True,exist_ok=True)
    qa=work/'exports';qa.mkdir(exist_ok=True)
    before=verify_inputs(work)
    master,addr,ix,src,items=operation_and_food(work)
    targets,extras,ledger,origins,restore,changes,duplicates,match=candidate_tables(master,addr,src)
    approved=[r for r in targets+extras if r['採否案']=='採用推奨']
    assert all(r['公式URL'] and r['公式住所'] and r['根拠SHA256'] and not r['正式全国統合ID'] and (not r['開店日既知'] or r['開店日既知']<=BASIS) for r in approved)
    assert len({ (r['都道府県'],r['公式店舗名'],r['公式住所']) for r in approved })==len(approved)
    assert len({r['通常掲載から外すID'] for r in duplicates})==3 and all(r['根拠SHA256'] for r in duplicates)
    assert all(not r['正式全国統合ID'] for r in ledger)
    assert len({r['候補キー'] for r in ledger})==159 and len(origins)==290 and len(restore)==16
    assert sum(r['第7回採否案']=='判断保留' for r in ledger)==42
    assert all(r['今回根拠URL'] for r in ledger if r['第7回採否案']!=r['重点監査採否案'])
    cases,future,scope=cases_latest(src,ledger)
    full,flags=joined_results(master,addr,items,duplicates)
    approvals,hist,corr_log,address_forms=corrections_review(master,addr,full,items,duplicates)
    summary=counts(full,targets,extras)
    op=[r for axis,r in items if axis=='営業']; food=[r for axis,r in items if axis=='食品']
    op_ids={r['全国統合ID'] for r in op}; fd_ids={r['全国統合ID'] for r in food}
    assert len(op)==len(op_ids)==197 and len(food)==len(fd_ids)==194
    assert len(op_ids|fd_ids)==345 and len(op_ids&fd_ids)==46
    assert sum(x['掲載区分']=='通常候補' for x in food)==159
    assert sum(r['現行掲載区分']=='通常候補' and r['全国統合ID'] in op_ids|fd_ids for r in full)==308
    assert all(a['公式住所原文'] for a in addr.values()) and len(addr)==len(full)==4701
    diff=Counter(r['Ver1.2承認候補区分'] for r in flags if r['現行掲載区分']=='通常候補')
    promotions=sum(r['Ver1.2承認候補区分']=='通常掲載' and r['現行掲載区分']!='通常候補' for r in flags)
    assert summary[0]['Ver1.2既存の通常掲載']==4658-sum(diff.values())+promotions
    uf=[r for r in food if r['重点監査判定'] in FOOD_UNKNOWN]
    uop=[r for r in op if r['重点監査判定'] in OP_UNKNOWN]
    overlap={r['全国統合ID'] for r in uop}&{r['全国統合ID'] for r in uf}
    priority=[r for r in op if '過去回の営業判定' in r['第7回理由'] or '根拠付きの過去判定' in r['第7回理由']]
    assert len(priority)==175
    r7held=[r for r in approvals if r.get('反映審査結果')=='判断保留']
    stat={'台帳基準日':BASIS,'確認日JST':CHECK,'基準行数':4701,'住所確認の継承':4701,
          '営業対象':len(op),'掲載適格性対象':len(food),'和集合':345,'共通対象':46,'通常候補の対象':308,
          '営業解消':len(op)-len(uop),'営業残件':len(uop),'営業未確定・常設元候補':sum(r['掲載区分']=='通常候補' for r in uop),
          '営業175対象の解消':sum(r['重点監査判定'] not in OP_UNKNOWN for r in priority),
          '営業175が保存証跡で解消':sum(r['重点監査判定'] not in OP_UNKNOWN and r['資料種別'].startswith('保存') for r in priority),
          '掲載適格性解消':len(food)-len(uf),'掲載適格性残件':len(uf),'掲載適格性通常候補残件':sum(r['掲載区分']=='通常候補' for r in uf),
          '今回の対象の残り和集合':len(uop)+len(uf)-len(overlap),
          '営業根拠の種別':Counter(r['証跡再利用区分'] for r in op),'食品根拠の種別':Counter(r['証跡再利用区分'] for r in food),
          '公式一覧':Counter(r['重点監査判定'] for r in scope),
          '候補の累計':len(ledger),'候補の新規採用推奨':len(approved),'指定18採用':len([r for r in targets if r['採否案']=='採用推奨']),
          '追加採用推奨':len(extras),'保留候補の残り':sum(r['重点監査採否案']=='判断保留' for r in ledger),
          '重複整理指定':sum(r['整理種別']=='重複' for r in duplicates),'別途施設統合':sum(r['整理種別']!='重複' for r in duplicates),
          '前回修正管理キー':2629,'重点監査管理キー':len(approvals),'前回修正履歴':len(hist),'追加判断履歴':len(corr_log),
          '旧324キーの審査':Counter(r['重点監査審査結果'] for r in r7held),
          '修正候補最終内訳':Counter(r['重点監査審査結果'] for r in approvals),
          '現行から通常掲載外':diff,'保留等から通常掲載へ':promotions,'全国最終試算':summary[0],
          '保護入力SHA256一致':len(before),'判定履歴継承':len(hist),'候補検出履歴継承':len(origins),'復元16判定継承':len(restore)}
    op_by_reason=[]
    for reason in dict.fromkeys(r['第7回理由'] for r in op):
        a=[r for r in op if r['第7回理由']==reason]
        ok=[r for r in a if r['重点監査判定'] not in OP_UNKNOWN]
        op_by_reason.append({'持越し理由':reason,'対象':len(a),'解消':len(ok),'残':len(a)-len(ok),
                             '保存済み根拠を採用':sum(x['資料種別'].startswith('保存') for x in ok),
                             '別途資料を採用':sum(not x['資料種別'].startswith('保存') for x in ok)})
    logs=source_logs(work,src,op,food,approved,cases)
    arows=[
        ('01-営業状況197行',[('営業監査197行',op),('持越し理由別',op_by_reason),('営業保留',uop)]),
        ('02-掲載適格性194行',[('掲載適格性194行',food),('通常候補159行',[r for r in food if r['掲載区分']=='通常候補']),('掲載適格性保留',uf),
          ('両方対象46行',[{'全国統合ID':r['全国統合ID'],'店舗名':r['店舗名'],'確定営業':r['重点監査営業判定'],'確定掲載適格性':r['重点監査掲載適格性']} for r in full if r['全国統合ID'] in op_ids&fd_ids])]),
        ('03-新規掲載と重複整理',[('指定18店舗の採否',targets),('旧保留からの追加採用案',extras),('重複整理・施設核対応',duplicates),('既存候補の比較証跡',match)]),
        ('04-掲載漏れ等159キー',[('159キーの最終採否案',ledger),('旧保留42キー',[r for r in ledger if r['第7回採否案']=='判断保留']),
          ('過去290検出履歴',origins),('第5回16判定の復元継承',restore),('今回変更履歴',changes)]),
        ('05-修正候補の承認審査',[('全管理キーの承認候補',approvals),('旧324保留の重点審査',r7held),
          ('公式住所原文の採録欄',address_forms),('前回まで2899履歴',hist),('今回判断履歴',corr_log)]),
        ('06-最終未解決と公式一覧',[('継承案件と公開時取扱い',cases),('第7回の引継ぎ案件原文',sheet(L2,'過去の根拠と判断')),('営業未確定',uop),('掲載適格性未確定',uf),
          ('候補未確定',[r for r in ledger if r['重点監査採否案']=='判断保留']),
          ('修正未確定',[r for r in approvals if r['重点監査審査結果']=='判断保留']),('基準日後の事象',future),
          ('全国公式一覧監査752組',scope)]),
        ('07-Ver1.2最終試算',[('全国',[summary[0]]),('都道府県',[r for r in summary if r['集計単位']=='都道府県']),
          ('系列',[r for r in summary if r['集計単位']=='系列']),('屋号',[r for r in summary if r['集計単位']=='屋号']),
          ('系列×都道府県',[r for r in summary if r['集計単位']=='系列×都道府県']),('増減の既存ID',flags),('既存4701行の公開区分案',full)]),
    ]
    for f,parts in arows:
        if not csv_only:make_book(out/(f+'.xlsx'),[(s,array(t)) for s,t in parts])
    entries={'operation-audit':op,'eligibility-audit':food,'candidate-18':targets,'candidate-extra':extras,'candidate-159':ledger,
        'duplicate':duplicates,'candidate-change':changes,'correction-approval':approvals,'correction-change':corr_log,
        'cases':cases,'post-baseline':future,'scope-752':scope,'store-counts':summary,'listing-proposal':full,'count-deltas':flags,
        'source-log':logs,'protected-inputs':before}
    for name,rr in entries.items():csv_write(qa/(name+'.csv'),array(rr))
    write(out/'全体集計・品質検証.json',stat);write(qa/'quality.json',stat)
    assert before==verify_inputs(work)
    print(js(qa/'quality.json'))
if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('work',type=Path);p.add_argument('out',type=Path);p.add_argument('--csv-only',action='store_true')
    a=p.parse_args();build(a.work,a.out,a.csv_only)
