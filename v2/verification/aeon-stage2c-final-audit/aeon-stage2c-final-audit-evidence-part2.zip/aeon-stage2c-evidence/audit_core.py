"""Combine archived and targeted official evidence at national ID level."""
import csv,hashlib,re,json,os
from collections import defaultdict
from functools import lru_cache
from pathlib import Path
from urllib.parse import unquote,urlsplit,parse_qsl
from openpyxl import load_workbook
from analyse import document
from compare import nf,normalize
from fetch import host,in_domains,cleanurl,text
from index700 import Index,store_key
from address_cases import address_check
from evaluate700 import take_detail,compare_name
from eligibility6 import food_brand
from address7 import region_cards
from assess6 import url_id
from run5 import js,write,read_master

ROOT=Path(os.environ.get('AEON_AUDIT_ROOT','/workspace'))
R4=ROOT/'r5/input'
R7=ROOT/'r7/work'
R7QA=R7/'qa'
BASIS='2026-11-23'
CHECK='2026-11-24'
OPEN='営業中（公式一覧基準）'
GMS='総合スーパーの食品売場確認'
FOOD='食品スーパー業態として確認'
DENIED='食品スーパー対象外'
HOLD='専門業態・一般利用条件等による判断保留'
UN='根拠不足による未確認'
OP_UNKNOWN={'未確認','要確認'}
FOOD_UNKNOWN={HOLD,UN}
FACILITY=re.compile(r'ショッピング(?:センター|プラザ)|イオンモール|専門店街|イオンタウン|ツカグチSC',re.I)
SPECIAL=re.compile(r'LABO|ウエルシア|ファミリーマート|衣料館|b!olala|COCOSAB|ホームワイド',re.I)
EVENT=re.compile(r'一時閉店|休業中|閉店済|営業終了|開店予定|営業休止|(?:\d{1,2}月\d{1,2}日).{0,13}(?:閉店いたし|をもって閉店|をもちまして閉店|グランドオープン)')
FOOD_MARK=re.compile(r'(?:食品|食料品)(?:売[場り]|フロア)[^。\n]{0,35}(?:\d{1,2}[:：]|時間|案内|は営業|商品)|(?:日配食品|農産|鮮魚|精肉)[^。\n]{0,15}(?:\d{1,2}[:：]|売場)|[（(]食品[）)]\s*(?:午前|\d)|(?:^|\s)(?:直営食品館|(?:[1１]階|[1１][FＦ])\s*(?:食品|食料品)(?:[&＆]くらしの品)?)[/／\s]*?(?:午前|24時間営業|\d{1,2}[:：])')
masterzip=Path(os.environ['AEON_MASTER_ZIP']) if 'AEON_MASTER_ZIP' in os.environ else next(Path('/tmp/codex-remote-attachments').glob('*/*/*master*.zip'))
def csvrows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def sheet(path,s):
    book=load_workbook(path,read_only=True,data_only=True)
    at=iter(book[s].values);h=next(at);result=[{k:v if v is not None else '' for k,v in zip(h,r)} for r in at]
    book.close();return result
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def eql(m,a):
    if not a:return False
    return address_check(m,a) in ('一致','表記のみ相違')
def key(n,op):
    k=store_key(n or '',op)
    return k.removesuffix('店')
def dense(s):
    return re.sub(r'\s+','',nf(str(s or '')))
def cal(u):
    return url_id(u) if u else ''
def page_key(u):
    if not u:return ()
    bits=urlsplit(cleanurl(u))
    params=tuple((k,v) for k,v in parse_qsl(bits.query) if k not in ('is_browser','openExternalBrowser') and not k.startswith('utm_'))
    return host(u),unquote(bits.path).rstrip('/'),params
def statuslist(p):
    return js(p) if p.exists() else []
def capture(work):
    """A response can be retrieved by requested URL or by an observed redirect target."""
    result=defaultdict(list)
    for folder in (R4,ROOT/'r5/work',ROOT/'r7/input6e',R7,work):
        logs=list(folder.glob('*-log.json'))+list(folder.glob('*/http-log.json'))
        for log in sorted(logs):
            directory=log.parent if log.parent!=folder else folder/('web' if log.name=='http-log.json' else log.name.removesuffix('-log.json'))
            for r in statuslist(log):
                if r.get('status')!=200 or not r.get('file'):continue
                p=directory/r['file']
                if not p.is_file():continue
                for u in {r.get('url'),r.get('final')}:
                    if u:result[page_key(u)].append((r,p,'今回の公式取得' if folder==work else '保存応答'))
    return result
def narrow(p):
    node=document(p.read_bytes())
    if node is None:return '', ''
    titles=' ／ '.join(text(n) for n in node.xpath('//title|//h1'))
    for n in node.xpath('//script|//style|//noscript|//footer|//nav|//header'):n.drop_tree()
    chosen=node.xpath('//main') or [node]
    return titles,' '.join(text(n) for n in chosen)
@lru_cache(maxsize=950)
def contents(p):
    return narrow(p)
def proof(r,kind,name,reason,u=None):
    return {'根拠URL':u or r.get('url',''),'取得日時UTC':r.get('fetched_at',''),'根拠SHA256':r.get('sha256',''),
            '資料種別':kind,'根拠上の店舗名':name,'監査理由':reason}
def lookup_roster(work,pages):
    org=js(R4/'enriched-roster.json')
    direct={cleanurl(r['url']):(r,p) for entries in pages.values() for r,p,k in entries if r.get('url')}
    fresh=region_cards(direct)
    return Index(org+fresh),{(p['final'],p['sha256']) for p in js(R4/'roster-pages.json') if p.get('sha256')}
def exact_cards(m,a,ix,known):
    op=m['系列分類']; given={key(v,op) for v in (m['店舗名'],a['公式店舗名']) if v}
    out=[]
    for c in ix.lookup(m):
        if c['kind']!='company' or c['pref']!=m['都道府県']:continue
        ck=key(c['name_compare'],op)
        link=any(cal(u) in known for u in c['detail_links'])
        addr=c['address'] and (eql(m,c['address']) or normalize(c['address'])==normalize(a['公式住所原文']))
        if not ck or ck not in given and not link:continue
        if not (addr or link or not c['address'] and op=='イオンリテール' and ck in given):continue
        if c['address'] and not (addr or link):continue
        out.append(c)
    return out
def site_urls(m,a,o,ix,domains):
    op=m['系列分類']; routes=[]
    for u in (a['住所証跡URL'],a['台帳公式URL'],o.get('営業根拠URL','')):
        for item in u.split(' ／ '):
            if item and in_domains(item,domains[op]):routes.append(item)
    for c in ix.lookup(m):
        if c['kind']=='company' and c['pref']==m['都道府県'] and key(c['name_compare'],op) in {key(m['店舗名'],op),key(a['公式店舗名'],op)}:
            routes.extend(u for u in c['detail_links'] if in_domains(u,domains[op]))
    return list(dict.fromkeys(cleanurl(u) for u in routes if u))
def brand_known(op,name,cn):
    if SPECIAL.search(name) or FACILITY.search(name):return False
    trim=dense(name)
    if op=='カスミ':return True # after a same-store official company card or detail, excluding specialty formats
    if op in ('マックスバリュ東海','マックスバリュ北陸','イオン琉球','イオン北海道','イオン九州','イオン東北','イオンリテール'):
        if re.match(r'マックスバリュ|ザ[・･]?ビッグ|フードセンター|イオンエクスプレス|フードスタイル|ジョイフルサン|レッドキャベツ|フードプラザにしだ',trim):return True
    if op=='トキハインダストリー':return False
    if op=='ダイエー・イオンフードスタイル' and re.match(r'KOHYO|MaxValu',trim,re.I):return True
    return food_brand(op,trim) or food_brand(op,dense(cn))
def group_url(u):
    return host(u)=='aeon.com' and ('/store/list/' in unquote(u) or '/store/' in unquote(u))
def operation_and_food(work,make_routes=False):
    master,*_=read_master(masterzip,R4)
    address={r['全国統合ID']:r for r in csvrows(R7QA/'national-4701.csv')}
    operations={r['全国統合ID']:r for r in csvrows(R7QA/'operation-4701.csv')}
    food={r['全国統合ID']:r for r in csvrows(R7QA/'eligibility-4701.csv')}
    op_ids={u for u,r in operations.items() if r['営業判定'] in OP_UNKNOWN}
    fd_ids={u for u,r in food.items() if r['第7回累計判定'] in FOOD_UNKNOWN}
    assert (len(op_ids),len(fd_ids),len(op_ids|fd_ids),len(op_ids&fd_ids))==(197,194,345,46)
    current=capture(work); ix,verified=lookup_roster(work,current)
    domains={o:ds for o,ds,urls in js(R4/'config.json')['operators']}
    domains['ダイエー・イオンフードスタイル']=['daiei.co.jp','aeonfoodstyle.com']
    supplemental=js(work/'manual-id.json') if (work/'manual-id.json').exists() else {}
    pending=[]; updated=[]; requesting=defaultdict(list); routes={}
    for m in master:
        uid=m['全国統合ID']
        if uid not in op_ids|fd_ids:continue
        o,f,a=operations[uid],food[uid],address[uid]
        op=m['系列分類']; name=m['店舗名']; ordinary=m['掲載区分']=='通常候補'
        sources=site_urls(m,a,o if uid in op_ids else {},ix,domains)
        if uid in supplemental:
            sources.extend(v['url'] for v in supplemental[uid].values() if v['url'] not in sources)
        known={cal(u) for u in (a['住所証跡URL'],a['台帳公式URL']) if u and in_domains(u,domains[op]) and '/store/list/' not in unquote(u)}
        oc=[];fc=[];notes=[];sources_seen=[]
        for c in exact_cards(m,a,ix,known):
            entry=proof(c,'保存済み運営会社公式一覧（カード）',c['name_compare'],'同一店の会社一覧カード。県・店舗名と住所または個店導線を突合。')
            org=(c['url'],c['sha256']) in verified
            if not org and not current.get(page_key(c['url'])):continue
            sources_seen.append(entry)
            cn=c['name_compare']
            if uid in op_ids and ordinary and not FACILITY.search(name) and not SPECIAL.search(name) and not c['status'] and not EVENT.search(cn):
                oc.append((OPEN,entry))
            if uid in fd_ids and ordinary:
                if c.get('explicit_food') and not FACILITY.search(name):
                    fc.append((GMS,entry|{'監査理由':'店舗カードに直営食品売場または食品売場の記載。'}))
                if brand_known(op,name,cn) and not c['status']:
                    fc.append((FOOD,entry|{'監査理由':'会社公式の同一店と食品スーパー屋号・業態を確認。'}))
        for url in sources:
            for r,p,k in current.get(page_key(url),[]):
                final=r.get('final') or url
                if not in_domains(final,domains[op]):continue
                title,body=contents(p)
                if not body:continue
                cn=a['公式店舗名'] or name
                nk={key(n,op) for n in (name,cn) if n}
                exact_title=any(len(n)>=3 and n in key(title,op) for n in nk)
                direct=None
                if exact_title:
                    direct=take_detail(m,r,p.read_bytes(),ix.lookup(m))
                commercial=FACILITY.search(name) or FACILITY.search(cn)
                adr=normalize(a['公式住所原文'])
                near_identity=exact_title and cal(url) in known and (len(adr)>6 and adr in normalize(body) or bool(re.search(r'/stores/[^/]+/?$|/detail/[^/]+/?$|/[^/]+/shop_info/hours/?$',unquote(urlsplit(final).path))))
                accepted=direct and (eql(m,direct['address']) or normalize(direct['address'])==normalize(a['公式住所原文'])) or near_identity
                if not accepted:continue
                assert digest(p)==r['sha256'],p
                evidence=proof(r,k+'・運営会社個店',direct['name'] if direct else cn,'個店見出し・保存公式住所・店コードを確認。',final)
                sources_seen.append(evidence)
                core=bool(FOOD_MARK.search(body)) and not SPECIAL.search(name)
                hours=bool(re.search(r'営業時間|\d{1,2}[:：]\d{2}\s*(?:～|~|〜|–|-)\s*\d|24時間営業',body))
                event=EVENT.search(title) or (direct and direct.get('store_status') in ('閉店','休業','開店予定'))
                if event:
                    notes.append('個店の営業例外表示。基準日との関係を個別審査。')
                    continue
                if uid in op_ids and ordinary and not SPECIAL.search(name) and hours and (not commercial or core and 'イオン九州'==op):
                    oc.insert(0,(OPEN,evidence|{'監査理由':'運営会社の同一店舗の個店に通常営業時間。基準日後の開店や休閉業等の明示なし。'}))
                if uid in fd_ids and ordinary and (not commercial or core and 'イオン九州'==op):
                    if brand_known(op,name,evidence['根拠上の店舗名']):
                        fc.insert(0,(FOOD,evidence|{'監査理由':'運営会社個店で同一店舗と食品スーパー業態を確認。'}))
                    elif core:
                        fc.insert(0,(GMS,evidence|{'監査理由':'店舗固有の食品売場・日配食品等の営業時間を確認。'}))
                if commercial and core:notes.append('施設に食品表示あり。運営会社の直営核店舗との対応を個別審査。')
        if uid in supplemental:
            for mode,v in supplemental[uid].items():
                d=proof(v,v.get('資料種別','公式資料（公開索引）'),v.get('店舗名',name),v['所見'])
                if current.get(page_key(v['url'])) and v.get('正文採用'):
                    rr,pp,category=current[page_key(v['url'])][-1]
                    assert digest(pp)==rr['sha256']
                    d=proof(rr,category,v.get('店舗名',name),v['所見'],v['url'])
                (oc if mode=='営業' else fc).insert(0,(v['判定'],d))
                sources_seen.append(d)
        if notes and uid not in supplemental:
            if any('営業例外' in n for n in notes):oc=[]
        def make(which,prior,data):
            if data:
                v,pr=data[0]
                return {'前回判定':prior,'重点監査判定':v,'証跡再利用区分':pr['資料種別']}|pr
            note=' ／ '.join(dict.fromkeys(notes))
            if SPECIAL.search(name):note='専門業態や一般利用・採否を個別保留。 '+note
            elif FACILITY.search(name):note='施設の掲載と直営食品核店舗の営業・食品売場の対応が確定できない。 '+note
            elif not ordinary:note='履歴・条件付き・除外行の扱いを維持。 '+note
            return {'前回判定':prior,'重点監査判定':prior,'証跡再利用区分':'保留',
                 '監査理由':note or ('運営会社の同一店・基準日営業を裏付ける証跡不足。' if which=='営業' else '運営会社業態または個店食品売場を同定できる証跡不足。'),
                 '根拠URL':'','取得日時UTC':'','根拠SHA256':'','資料種別':'','根拠上の店舗名':''}
        oo=make('営業',o['営業判定'],oc)
        ff=make('食品',f['第7回累計判定'],fc)
        wanted=(uid in op_ids and not oc) or (uid in fd_ids and not fc)
        if wanted:
            routes[uid]=sources
            if make_routes and ordinary:
                for u in sources:
                    if host(u)=='aeon.com' or current.get(page_key(u)):continue
                    if any(re.search(p,unquote(urlsplit(u).path)) for p in (r'/detail/',r'/stores/[^/]+',r'/store/[^/]+',r'/shop/[^/]+',r'/tenpotop/.+/\d+',r'/mv/store/shop/')):
                        requesting[u].append(uid)
                        break
        core={'全国統合ID':uid,'店舗名':name,'都道府県':m['都道府県'],'系列分類':op,'掲載区分':m['掲載区分'],'台帳基準日':BASIS,
              '両項目対象':uid in op_ids&fd_ids,'公式住所原文（既往）':a['公式住所原文'],
              '照合したURL':' ／ '.join(dict.fromkeys([p['根拠URL'] for p in sources_seen]+sources))}
        if uid in op_ids:updated.append(('営業',core|oo|{'第7回理由':o['判定根拠・未確認理由'],'第7回URL':o['営業根拠URL']}))
        if uid in fd_ids:updated.append(('食品',core|ff|{'第7回理由':f['根拠または未確認理由'],'第7回URL':f['根拠URL']}))
    if make_routes:
        write(work/'focus-requests.json',dict(requesting))
        write(work/'unresolved-routes.json',routes)
    return master,address,ix,current,updated
