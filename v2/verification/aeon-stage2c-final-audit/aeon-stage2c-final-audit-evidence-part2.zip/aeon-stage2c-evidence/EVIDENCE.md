# 第2段階C 最終重点監査 証跡と再実行

証跡編が複数のZIPの場合は、各ZIPを同じ場所に展開します。取得資料のファイル名は応答のハッシュで、取得ログに取得URL、転送先、UTC、HTTP結果、SHA-256を収録しています。公開索引で内容を照合した行はURLと照合日を記録しています。マルエツ初石店は第三者記事の閉店告知写真でマルエツ名義と日時を目視確認しました。

- exports/ に監査結果・追加判定履歴・全体集計・公式情報取得ログのCSVとJSONを収録しています。
- focus/、additional/、cases/、late/、food-cards/、food-core/ 以下は今回取得した応答です。ログでHTTPや転送先を確認できます。
- 既存の証跡は第4〜7回の保存結果を参照します。基本照合と新規調査の結果は日本時間2026年11月24日に確認し、台帳基準日2026年11月23日と区別しています。
- photo/ には写真から判読した店頭告知を収録しています。画像の掲載記事とハッシュは source-log.csv にあります。

## 保存証跡による再計算

Python 3.11以降、openpyxl、lxml、poppler-utilsを使います。第4回の結果・証跡を同じ場所（r5/input）に展開し、第5回証跡をr5/workに展開します。第6回証跡2本はr7/input6eへ、第7回結果はr7/outへ、第7回証跡3本を展開した work/ はr7/workへ配置します。これらの親ディレクトリを AEON_AUDIT_ROOT に設定します。正本ZIPを AEON_MASTER_ZIP に指定します。入力ZIPはハッシュ照合用として第7回 inputs.sha256 に記載したパスに置きます。第7回のZIP4本は r7/release に置きます。第7回証跡に inputs.sha256 が含まれない場合は、今回同梱の previous-inputs.sha256 を参照して同名ファイルを配置してください。

```sh
export AEON_AUDIT_ROOT=/path/to/audit-inputs
export AEON_MASTER_ZIP=/path/to/aeon-national-master-phase2c-20261123.zip
export PYTHONPATH="$AEON_AUDIT_ROOT/r7/work:$AEON_AUDIT_ROOT/r7/input6e:$AEON_AUDIT_ROOT/r5/work:$AEON_AUDIT_ROOT/r5/input"
python manual_review.py
python export_audit.py . ./rebuilt
python report.py ./rebuilt
```

エクスポート後の exports/ には再計算したCSV・JSONが出力されます。元ファイルと新しい出力を別の作業フォルダで比較してください。取得コードやオンライン調査を再実行せず、収録した応答で計算します。
