from pathlib import Path
from audit_core import *

BASE=Path('.')
manual=js(BASE/'indexed-base.json')
if (BASE/'indexed-more.json').exists():
    for uid,group in js(BASE/'indexed-more.json').items():manual.setdefault(uid,{}).update(group)
def set_(uid,axis,url,status,note,body=False):
    manual.setdefault(uid,{})[axis]={'url':url,'判定':status,'所見':note,'正文採用':body}
def case(uid,url,note,food=GMS,body=True,op=True):
    if op:set_(uid,'営業',url,OPEN,note,body)
    if food:set_(uid,'食品',url,food,note,body)
for uid,name in {
 'AE-80A62766E7120DEF':'膳所','AE-AFF684E99B50F4D7':'大津月輪','AE-4436B6CD3D600E5F':'大津京',
 'AE-B728234B7E37B226':'駒井沢','AE-D869F396C7372F0F':'東近江','AE-ADA9F0BE51CF7F8E':'八日市'}.items():
    case(uid,'https://www.mv-tokai.co.jp/store/p08/','運営会社の滋賀県一覧で'+name+'の個別カード、所在地・営業時間と食品スーパー業態を突合。',FOOD)
for uid,url,note in [
 ('AE-C7B9985E65E683A0','https://www.maruetsu.co.jp/store/9678/','東浦和の運営会社個店で9時～翌1時の通常営業。'),
 ('AE-DE8928A0BDB1C62E','https://www.kasumi.co.jp/tenpotop/ibaraki-south/moriya/296/','フードスクエアの個店に守谷の住所と通常営業時間。商業施設の時間と区別。'),
 ('JP-28-000116','https://www.the-fuji.com/mv/store/shop/hyogo/mv_aeontownhimeji.php','フジの食品スーパー個店、延末435-3と営業時間8:00～24:00。'),
 ('AE-C26573524C177F1A','https://www.mv-tokai.co.jp/store/110160/','運営会社個店の本郷駅北店の営業時間。公式開店資料は2026年3月20日。')]:
    case(uid,url,note,None)
case('AE-F624E417505917D2','https://www.aeon.com/store/lp/586632/','運営会社店舗固有の公開案内に同名支店の現行営業と生鮮食品。',None,False)
case('AE-470E2EBABBF10DB3','https://tenpo.aeon-kyushu.info/aeon/detail/ogori/shoplist-service/974002/',
     '運営会社が施設公式案内内で個別に表示した直営イオン1階食品9:00～22:00。施設営業時間から分離。',None)
case('AE-2D0C32DF03A4EFE2','https://www.aeon-hokkaido.jp/aeon/shop/asahikawanishi/','緑町23丁目の会社直営個店に1階食品売場の営業時間。施設のモール行と別扱い。')
set_('AE-3A63FFDC285376FC','営業','https://www.aeon-kyushu.info/files/optionallink/00000681_file.pdf','食品核店舗は別IDで営業',
     '7/28に食品核のザ・ビッグ福岡東店が開店。施設営業時間と区別し、AE-4A5DB471A19B88BEへ対応。',True)
set_('AE-6B10953DFB22BAEA','営業','https://aeontohoku.co.jp/stores/tsuchizakiminato','休業','運営会社個店の見出しに【休業】を明示。再開・別ブランドを確認できるまで履歴維持。',True)
set_('AE-D16E7BD241CA2DB5','食品','https://www.aeon-kyushu.com/biolala/',DENIED,'会社公式は健康志向のセレクトショップと明示。食品は扱うが通常の食品スーパー業態として集計対象外を提案。',True)
set_('AE-7FDAE0B87CE2603A','食品','https://www.aeon.com/store/list/スーパーマーケット/マックスバリュ/九州地方/熊本県/ＣＯＣＯＳＡ Ｂ1/',FOOD,
     'グループ公式の業態区分はスーパーマーケット・マックスバリュ、実運営はイオン九州。会社個店で同一店舗に対応。')
set_('AE-CB4D5FA949B1D2EB','食品','https://www.aeon-hokkaido.jp/aeon/shop/mombetsu/',GMS,'店舗公式の1階食品・くらしの品の営業時間を採用。',True)
set_('AE-55B6BDBEEA27B7E9','食品','https://aeontohoku.co.jp/stores/saiwaicho',GMS,'店舗個店の1F食料品24時間を保存応答で確認。',True)
set_('AE-0FDCA6DAD2CA130A','食品','https://aeontohoku.co.jp/stores/tsugarukashiwa',GMS,'店舗個店に直営食品館の営業時間。',True)
case('AE-0714F60CE31CA94F','https://tenpo.aeon-kyushu.info/aeon/detail/tobata/shoplist-service/850433/','直営イオン戸畑の1階食品8～22時。施設時間から分離。',None)
case('AE-38FA0070F4719B61','https://www.aeon-kyushu.info/files/management_news/2282/pdf.pdf','運営会社発表でイオン若松店の食品9～22時。保存済みの運営会社個店にも同じ営業時刻と所在地。',None)
case('AE-6548D9F572FD9A6C','https://page.line.me/eqg3548h','店舗のLINE公式アカウントに、乙金の直営食料品9～22時と専門店街の別時間。イオン九州個店の店舗表示・営業時間と突合。')
set_('AE-9472D50870140D81','食品','https://www.aeon-hokkaido.jp/aeon/shop/syunkou/floorguide.html',GMS,'会社フロアガイドの食料品売場。2024年9月13日開業の現行食品核店舗で、旧店と施設名の行から分離。',True)
for uid,name in [('AE-AE257779A5F097CB','イオンスタイル君津'),('AE-B7075D4690D4206E','イオン亀田店'),('AE-3C4EE0F0975BA473','イオンスタイル西陣小町')]:
    set_(uid,'食品','https://www.aeon.com/store/イオン/'+name+'/shop_info/hours/',GMS,'同名の会社個店営業時間に加工食品・日配食品・食品デリ等の区分。')
set_('AE-E45ED497B442EAD8','食品','https://www.aeonretail.jp/pdf/260217R_1.pdf',FOOD,'イオンリテール公式開店発表で食品スーパー、2026年3月3日開店。')
case('AE-CF30131B643925DB','https://tenpo.aeon-kyushu.info/detail/onojo/shoplist-service/868936/','運営会社公式案内の直営イオン1階食品9時～22時。施設全体の営業時間から分離。',None)
set_('AE-2D3502A90D4E54F1','営業','https://aeontohoku.co.jp/stores/koriyamafesta','休業','運営会社公式個店に【休業】を明示。',True)
set_('AE-D6DAC7EF79D66CD8','営業','https://aeontohoku.co.jp/stores/kobata','閉店','会社公式個店と青森県一覧に【閉店】。2026年9月の閉店確認以前から休業。',True)
set_('AE-8C58D0F23C9677FA','食品','https://www.tokiwa-industry.co.jp/shops/pdf/1.pdf',GMS,'運営会社公式のあけのアクロスタウン本館フロアガイド。生鮮・惣菜・日配食品を確認。')
set_('AE-D82F8E01A1418B31','食品','https://www.aeon-ryukyu.jp/cms/wp-content/uploads/2020/06/88edfeb0d7df25480b26366ef63a4553-2.pdf',FOOD,'運営会社の開店発表でフードマーケットを明記。施設公式の同一店にも生鮮食品表示がある。')
case('AE-D1BB1DC4B9E63297','https://www.the-fuji.com/mv/store/shop/hiroshima/mv_kaita.php','フジの同名個店を公開索引で確認。海田町の店舗・電話番号と店舗別の食品案内を突合。',None,False)
case('AE-F1A2BE7A2CE571C6','https://www.kasumi.co.jp/tenpotop/saitama-ken/yashio/407/','カスミ公式個店・公式県一覧に八潮大原店の24時間営業。複合業態の適格性は別判定。',None)
case('AE-4CB0ACD09A631351','https://tenpo.aeon-kyushu.info/detail/itoshima/','運営会社個店の食物販イオン糸島店のチラシ導線・9～22時。福岡県の同住所・同電話のイオン糸島店表示でも店舗を突合。',None)
set_('AE-B523274846D8785F','営業','https://www.biga.co.jp/open-renewal/7月26日（土）アコレ北与野駅北店がビッグ・エー/','改称済み（履歴）','運営会社公式に2025年7月26日の改装・屋号変更。新屋号の既存行AE-5DB6BEEB3BA31122へ対応。')
for uid,url,n in [('AE-80B96CB0D9095A4C','https://www.aeon-hokkaido.jp/aeon/shop/tomakomai/','イオン苫小牧店'),
                  ('AE-4E426E90B109666A','https://www.aeon-hokkaido.jp/aeon/shop/nayoro/','イオン名寄店'),
                  ('AE-D67CA2CDDE2B0229','https://www.aeon-hokkaido.jp/aeon/shop/asahikawanishi/','イオン旭川西店')]:
    set_(uid,'営業',url,'施設行・食品核店舗は別判定','台帳で除外の施設行。食品核は会社公式の'+n+'で独立判定。施設の営業を食品核の営業に転用しない。',True)
src=capture(BASE)
for uid,url,name in [
 ('AE-E099AF70F88BFC98','https://www.aeon-hokkaido.jp/aeon/shop/sapporosoen/','イオン札幌桑園店'),
 ('AE-C2476C811B1F52FB','https://www.aeon-hokkaido.jp/aeon/shop/sapporomotomachi/','イオン札幌元町店'),
 ('AE-7476C3EE2AD95C8C','https://www.aeon-hokkaido.jp/aeon/shop/sapporonaebo/','イオン札幌苗穂店'),
 ('AE-5D68FFB13C14BDD1','https://www.aeon-hokkaido.jp/aeon/shop/sapporonishioka/','イオン札幌西岡店'),
 ('AE-90939BF7C8DD4934','https://www.aeon-hokkaido.jp/aeon/shop/sapporokiyota/','イオン札幌清田店'),
 ('AE-1533968435987199','https://www.aeon-hokkaido.jp/aeon/shop/sapporohiraoka/','イオン札幌平岡店'),
 ('AE-EDE235DB341DD707','https://www.aeon-hokkaido.jp/aeon/shop/sapporoatsubetsu/','イオン札幌厚別店'),
 ('AE-B9391C7A7D6ED22D','https://www.aeon-hokkaido.jp/aeon/shop/sapporohassamu/','イオン札幌発寒店'),
 ('AE-CA2C221D4955C92B','https://www.aeon-hokkaido.jp/aeon/shop/syunkou/','イオン旭川春光店'),
 ('AE-46E45D7A51F11110','https://www.aeon-hokkaido.jp/aeon/shop/kushiroshowa/','イオン釧路昭和店'),
 ('AE-18AD0A258C2B6269','https://www.aeon-hokkaido.jp/aeon/shop/kushiro/','イオン釧路店'),
 ('AE-E9324BB9C15A7615','https://www.aeon-hokkaido.jp/aeon/shop/obihiro/','イオン帯広店'),
 ('AE-80B96CB0D9095A4C','https://www.aeon-hokkaido.jp/aeon/shop/tomakomai/','イオン苫小牧店'),
 ('AE-4E426E90B109666A','https://www.aeon-hokkaido.jp/aeon/shop/nayoro/','イオン名寄店'),
 ('AE-D67CA2CDDE2B0229','https://www.aeon-hokkaido.jp/aeon/shop/asahikawanishi/','イオン旭川西店')]:
    # Separate the host facility from the actual food-store ID. Only apply when the archived body identifies the referenced store.
    links=src.get(page_key(url),[])
    if any(dense(name) in dense(contents(p)[0]) for rec,p,k in links):
        set_(uid,'食品',url,'施設と食品核店舗・既存店舗の重複','施設行の除外を維持。運営会社個店の'+name+'は食品核として別ID判定。',True)
if (BASE/'food-core-requests.json').exists():
    for u,(uid,name) in js(BASE/'food-core-requests.json').items():
        for rr,pp,k in src.get(page_key(u),[])[-1:]:
            title,body=contents(pp)
            localized=re.search(r'(?:イオン[（(](?:1[階ＦF]\s*)?(?:食品|食料品)[）)]|イオン直営(?:食品|食料品)|(?:^|\s)[1１][階ＦF]\s*(?:イオン)?[（(]?食品(?:売場)?[）)]?)\s*(?:午前|[0-9０-９]{1,2}[:：])',body)
            expected=name.replace('店','').replace('ショッピングセンター','').replace('ショッピングプラザ','')
            if localized and dense(expected) in dense(title) and not EVENT.search(title):
                case(uid,u,'会社公式の同一店舗の直営食品売場。施設全体と明確に区分した営業時間。',GMS,True,uid=='AE-4CB0ACD09A631351')
write(BASE/'manual-id.json',manual)
