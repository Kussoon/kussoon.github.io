import csv,glob,re,unicodedata,json
from openpyxl import load_workbook
def read(p):return list(csv.DictReader(open(glob.glob(p)[0],encoding='utf-8-sig')))
def norm(s):return re.sub(r'\s+','',unicodedata.normalize('NFKC',s or '')).translate(str.maketrans('－−‐―','----'))
uid='全国統合ID'
a=read('aeon-admin*/01-*.csv')
w=load_workbook(glob.glob('*.xlsx')[0],read_only=True,data_only=True); t=iter(w['全国統合マスター'].values);h=next(t)
M={r[uid]:r for x in t if (r:=dict(zip(h,x)))[uid]}
sel=[]
for r in a:
 if r['公式原文との住所照合評価'].startswith('番地・号まで一致') and r['CSIS_区域判定']=='市区町村内':continue
 m=M[r[uid]]; p=r['都道府県']; city=r['市区町村']; raw=norm(r['運営会社公式住所'])
 variants=[]
 for k in ['基準日時点の住所','ジオコーディング用住所','正規化住所']:
  x=norm(m[k])
  if x.startswith(p+p):x=x[len(p):]
  if x.startswith(city):x=p+x
  if x.startswith(p+city) and len(x)>len(p+city) and x!=raw:variants.append((x,k))
 if variants:
  for x,k in list(dict(variants).items())[:2]:sel.append([r[uid],x,k])
print(len(sel),len({r[0] for r in sel}))
with open('request.csv','w',encoding='cp932',newline='') as f:csv.writer(f).writerows(sel)
