from inputs import norm,uid,a,read,M
import csv,re,io,math,json,glob,collections,hashlib
from pathlib import Path
from zipfile import ZipFile
import shapefile
from shapely.geometry import shape,Point
K=['番地・号に対応する座標','店舗・施設の所在地に対応する座標','親番・街区の代表点','町字・町丁目の代表点','その他・位置未解決']
def rank(r):
 l=r['現行の座標対応レベル']
 return 0 if l in ('地番','住居番号','地番（住居表示の旧地番）') else 1 if '登録座標' in l or '届出代表' in l or 'ユーザー確認' in l else 2 if '親番' in l or l=='街区' else 3 if l=='町字・町丁目' else 4
def key(s):
 s=norm(s).replace('/','').replace('大字','').replace('小字','').replace('ヶ','ケ').replace('が丘','ケ丘')
 def n(m):
  ss=m[1]; d='〇一二三四五六七八九'
  if '十' in ss:
   x,y=ss.split('十'); return str((d.index(x) if x else 1)*10+(d.index(y) if y else 0))
  return ''.join(str(d.index(c)) for c in ss)
 s=re.sub(r'([〇一二三四五六七八九十]+)(?=丁(?:目)?)',n,s)
 s=re.sub(r'(?<=\d)(丁目|丁|番地の?|番|号)','-',s);return re.sub(r'-+','-',s).rstrip('-')
def point(r,prefix):return (float(r[prefix+'緯度']),float(r[prefix+'経度']))
def meters(p,q):
 y,x=map(math.radians,p);t,z=map(math.radians,q)
 return 12742017.6*math.asin(min(1,math.sqrt(math.sin((y-t)/2)**2+math.cos(y)*math.cos(t)*math.sin((x-z)/2)**2)))
def write(n,rows):
 rows=list(rows);f=list(dict.fromkeys(k for r in rows for k in r)) or [uid]
 with (out/n).open('w',encoding='utf-8-sig',newline='') as w:
  c=csv.DictWriter(w,fieldnames=f);c.writeheader();c.writerows(rows)
out=Path('out');out.mkdir(exist_ok=True)
by={r[uid]:r for r in a};priority={r[uid] for r in read('aeon-admin*/04-*.csv')}; cand={r[uid] for r in read('aeon-admin*/03-*.csv')}
assert len(by)==4613 and len(cand)==1136 and len(priority)==246
assert all(by[u]['CSIS_区域判定']=='市区町村内' and by[u]['iConf']=='5' for u in cand)
stored=read('aeon-csis*/01-*.csv');assert {r[uid] for r in stored}==set(by)
assert all(by[r[uid]]['運営会社公式住所']==r['運営会社公式住所']==M[r[uid]]['公式住所原文'] for r in stored)
response=list(csv.DictReader(open('response',encoding='cp932')))
assert len(response)==len(list(csv.reader(open('request.csv',encoding='cp932'))))
new=collections.defaultdict(list); checks=[]; geo=collections.defaultdict(list)
with ZipFile(glob.glob('N03*zip')[0]) as z:
 n=next(n for n in z.namelist() if n.endswith('.shp')); b=n[:-4]
 files={k:io.BytesIO(z.read(b+'.'+k)) for k in ('shp','shx','dbf')}
 rr=shapefile.Reader(**files,encoding='utf-8')
 needed={by[r['col0']]['N03期待自治体コード'][:5] for r in response}
 for index, rec in enumerate(rr.iterRecords()):
  c=rec.as_dict()['N03_007']
  if c in needed:geo[c].append(shape(rr.shape(index).__geo_interface__))
assert needed<=geo.keys(),(len(geo),needed-geo.keys())
shared=collections.defaultdict(set)
for r in a:
 for t in ('現行','CSIS'):shared[point(r,t)].add(key(r['基準日時点の住所'] or r['運営会社公式住所']))
req=list(csv.reader(open('request.csv',encoding='cp932')))
requeryids={r[0] for r in req}
for j,(x,inp) in enumerate(zip(response,req,strict=True)):
 u=x['col0'];r=by[u]; assert u==inp[0] and inp[2]==x['col2']
 addr=key(inp[1]); loc=key(x['LocName'])
 if '郡' in r['市区町村']:
  county=key(r['都道府県']+r['市区町村'].split('郡')[0]+'郡')
  if addr.startswith(county):addr=key(r['都道府県'])+addr[len(county):]
  if loc.startswith(county):loc=key(r['都道府県'])+loc[len(county):]
 full=bool(loc and (addr==loc or (addr.startswith(loc) and re.match(r'^[^\d-].*(?:店|ビル|棟|館|内|階|モール|プラザ|センター)',addr[len(loc):]))))
 parent=bool(loc and addr.startswith(loc+'-') and re.match(r'\d',addr[len(loc)+1:]))
 try:p=float(x['fY']),float(x['fX'])
 except ValueError:p=None
 if p:shared[p].add(key(r['基準日時点の住所'] or r['運営会社公式住所']))
 inside=bool(p and 20<=p[0]<=46 and 122<=p[1]<=154 and any(s.covers(Point(p[1],p[0])) for s in geo[r['N03期待自治体コード'][:5]]))
 opts=0 if full and x['iLvl'] in ('7','8') else 2 if parent and x['iLvl']=='7' else 4
 c=dict(x,入力住所=inp[1],区域内=inside,照合段階=opts)
 checks.append(c)
 if inside and x['iConf']=='5' and opts<rank(r):new[u].append((opts,p,x,inp[1]))
checked=collections.defaultdict(list)
for row in checks:checked[row['col0']].append(row)
proposed=[];decisions=[];remaining=[];shared_review=[]; pri=[]
for r in a:
 u=r[uid];old=point(r,'現行');kind=rank(r);pick=None;why='現行座標を継承';opts=[]
 if u in cand:
  level=0 if r['公式原文との住所照合評価'].startswith('番地・号まで一致') else 2
  opts.append((level,point(r,'CSIS'),r['CSIS照合住所'],'第760号の公式原文照合'))
 for lev,p,x,inp in new[u]:opts.append((lev,p,x['LocName'],'再照会 '+inp))
 opts.sort(key=lambda x:(x[0],meters(old,x[1])))
 viable=[e for e in opts if not(len(shared[e[1]])>1) and e[0]<kind]
 if viable:
  best=viable[0]
  if any(q[0]==best[0] and meters(q[1],best[1])>100 for q in viable):
   why='同じ粒度の候補が100m超離れて競合'
  elif (u in priority and meters(old,best[1])>=1000 and best[0]!=0):
   why='大幅乖離かつ枝番未照合。独立した同一地点の根拠待ち'
  else:pick=best;why='詳細化・期待行政区内・異住所の共用なし'
 elif opts:why='異住所による座標共有または詳細化不足'
 elif u in priority:why='前回監査の区域・表記・番号の疑義、または同精度。修正根拠待ち'
 dst=pick[1] if pick else old;dest=pick[0] if pick else kind
 row={**r,'採用案':'CSIS候補採用' if pick else '現行維持','判定根拠':why,'提案緯度':dst[0],'提案経度':dst[1],
 '対応レベル':K[dest],'提案照合住所':pick[2] if pick else r['現行座標の対応住所'],
 '判定に用いた入力':pick[3] if pick else '',
 '再照会実績':' ／ '.join(f"{v['入力住所']} → {v['LocName']} (iLvl {v['iLvl']}・区域{'内' if v['区域内'] else '外または座標なし'})" for v in checked[u]),
 '優先資料':r['公式住所根拠URL'] if u in priority else '',
 '優先審査メモ':(f"{r['監査後の個別調査']}。現行は{r['現行の座標対応レベル']}・{r['現行_区域判定']}。前回CSISは{r['公式原文との住所照合評価']}・{r['CSIS_区域判定']}。{r['番地等の不一致・照合注意']}" if u in priority else ''), '変位m':round(meters(old,dst),1),
 '提案出典URL':r['CSIS出典URL'] if pick else r['現行座標出典URL'],
 '提案取得日時UTC':('2026-11-25T08:23:20Z' if pick[3].startswith('再照会') else r['CSIS取得日時UTC']) if pick else '',
 '前回改善候補の判定':('CSIS採用' if pick and pick[3].startswith('第760号') else '再照会候補が優先' if pick else '現行維持・要確認') if u in cand else '',
 '提案利用条件URL':r['CSIS利用条件URL'] if pick else r['現行座標利用条件URL']}
 proposed.append(row)
 if u in cand or u in requeryids:decisions.append(row)
 if u in priority:pri.append(row)
 if r['現行の別住所共有地点ID'] or r['CSISの別住所共有地点ID']:
  shared_review.append({**row,'共有の扱い':'提案点は異なる住所の共用なし' if pick else '共用状況を継承。別店舗・重複登録の判定には用いない'})
 if dest>=2 or (not pick and r['追加調査の要否']=='要') or (u in priority and not pick) or (r['現行の別住所共有地点ID'] and not pick):
  remaining.append(row)
write('01-全国採用案.csv',proposed)
write('02-変更候補.csv',(r for r in proposed if r['採用案']=='CSIS候補採用'))
write('03-改善候補採否.csv',decisions)
write('04-優先246店.csv',pri)
write('05-異住所の座標共有.csv',shared_review)
write('06-残る未解決.csv',remaining)
write('07-再照会検証.csv',checks)
count=collections.Counter(r['対応レベル'] for r in proposed)
write('08-対応レベル集計.csv',({'対応レベル':l,'現行':sum(rank(r)==i for r in a),'採用案':count[l]} for i,l in enumerate(K)))
stat={'通常掲載':len(proposed),'変更':sum(r['採用案']=='CSIS候補採用' for r in proposed),'前回候補':len(cand),'優先':len(pri),'優先変更':sum(r['採用案']=='CSIS候補採用' for r in pri),'共有':len(shared_review),'残る確認事項':len(remaining),'照会':len(checks),'照会店舗':len({c['col0'] for c in checks}), '再照会結果採用':sum(r['判定に用いた入力'].startswith('再照会') for r in proposed),'分類':count}
(out/'集計.json').write_text(json.dumps(stat,ensure_ascii=False,indent=2))
print(stat)
