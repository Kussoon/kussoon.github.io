import csv,glob,re,unicodedata,json
from openpyxl import load_workbook
def read(p):return list(csv.DictReader(open(glob.glob(p)[0],encoding='utf-8-sig')))
def norm(s):return re.sub(r'\s+','',unicodedata.normalize('NFKC',s or '')).translate(str.maketrans('－−‐―','----'))
uid='全国統合ID'
a=read('aeon-admin*/01-*.csv')
w=load_workbook(glob.glob('*.xlsx')[0],read_only=True,data_only=True); t=iter(w['全国統合マスター'].values);h=next(t)
M={r[uid]:r for x in t if (r:=dict(zip(h,x)))[uid]}
