import csv
import hashlib
import json
import subprocess
import sys
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from select_targets import PREF_CODE

KINDS = ('mt_town_fullset', 'mt_town_pos', 'mt_rsdtdsp_blk', 'mt_rsdtdsp_blk_pos')
CATALOG = 'https://dataset.address-br.digital.go.jp/api/feed/dcat-us/1.1.json'

def utc():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

def download(url, dest):
    result = subprocess.run(['curl', '-fLsS', '--max-time', '25', url, '-o', str(dest)],
                            capture_output=True, text=True)
    return result.returncode == 0, result.stderr.strip()

def main(target_path, output):
    output = Path(output)
    output.mkdir(exist_ok=True)
    catalog = output / 'dcat.json'
    if not catalog.exists():
        ok, error = download(CATALOG, catalog)
        if not ok:
            raise RuntimeError(error)
    data = json.loads(catalog.read_bytes())
    links = {}
    for dataset in data['dataset']:
        for item in dataset.get('distribution', []):
            url = item.get('accessURL', '')
            if url.startswith('https://data.address-br.digital.go.jp/') and url.endswith('.csv.zip'):
                links[url.rsplit('/', 1)[-1]] = (url, dataset.get('modified', ''))
    with open(target_path, encoding='utf-8-sig', newline='') as f:
        prefectures = list(dict.fromkeys(r['都道府県'] for r in csv.DictReader(f)))
    log = output / 'fetch.jsonl'
    prior = {}
    if log.exists():
        for line in log.read_text().splitlines():
            row = json.loads(line)
            if row['status'] == 'ok':
                prior[row['file']] = row
    with log.open('a', encoding='utf-8') as stream:
        for pref in prefectures:
            for kind in KINDS:
                filename = f'{kind}_pref{PREF_CODE[pref]}.csv.zip'
                path = output / filename
                if filename in prior and path.exists():
                    if hashlib.sha256(path.read_bytes()).hexdigest() == prior[filename]['sha256']:
                        continue
                url, modified = links.get(filename, ('', ''))
                success, error = download(url, path) if url else (False, 'not listed')
                stamp = utc()
                success = success and zipfile.is_zipfile(path)
                row = dict(file=filename, url=url, modified=modified, at=stamp,
                           status='ok' if success else 'failed', detail=error,
                           sha256=hashlib.sha256(path.read_bytes()).hexdigest() if success else '')
                stream.write(json.dumps(row, ensure_ascii=False) + '\n')
                stream.flush()
                time.sleep(0.8)

if __name__ == '__main__':
    main(*sys.argv[1:])
