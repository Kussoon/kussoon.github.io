import json
import re
from pathlib import Path

from geocode_abr import normalize
from select_targets import ID

LICENSES = {'CDLA-Permissive-2.0', '公共データ利用規約（第1.0版, PDL1.0）'}
ATTRIBUTION = 'https://openpoiapi.com/attribution.html'

def read_poi(path):
    if not Path(path).exists():
        return {}
    return {row[ID]: row for line in Path(path).read_text().splitlines()
            if (row := json.loads(line))['http'] == '200'}

def store_name(value):
    return re.sub(r'(・イオンフードスタイル)?店?$', '', normalize(value)).casefold()

def address_numbers(value):
    value = normalize(value)
    value = re.sub(r'(\d+)丁目',r'\1-',value)
    value = re.sub(r'(\d+)番(?:地)?(?:の)?',r'\1-',value)
    value = re.sub(r'(\d+)号(?!館)',r'\1-',value)
    match = re.match(r'^([^\d]*\d+(?:-\d+)*)', value)
    return match[1] if match else ''

def candidate(store, attempt):
    result = []
    for r in attempt.get('response', {}).get('results', []):
        license_set = set(r.get('licenses', []))
        if not license_set or not license_set <= LICENSES or not r.get('attributions'):
            continue
        if r.get('prefecture') != store['都道府県'] or r.get('category') not in {'grocery','retail_other'}:
            continue
        names = {store_name(store[k]) for k in ('表示用店舗名','公式店舗名') if store[k]}
        if store_name(r.get('name','')) not in names:
            continue
        if not normalize(r.get('address','')).startswith(normalize(store['都道府県'])):
            continue
        address = address_numbers(store['表示用住所'])
        if not address or address_numbers(r['address']) != address:
            continue
        if not (isinstance(r.get('lat'),(float,int)) and isinstance(r.get('lng'),(float,int)) and
                24 < r['lat'] < 46 and 122 < r['lng'] < 147):
            continue
        result.append(r)
    if len(result) != 1:
        return None
    return result[0]
