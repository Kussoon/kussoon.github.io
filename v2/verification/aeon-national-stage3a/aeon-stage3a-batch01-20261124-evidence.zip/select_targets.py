import csv
import hashlib
import io
import sys
import zipfile
from collections import Counter, defaultdict, deque
from pathlib import Path
from urllib.parse import urlsplit

HASH = 'f32cc6fc1b1d24279912c531adbdd280e061541a8dada8903fbb36c51f970bcb'
ID = '全国統合ID'
PRIORITY = {'京都府': 25, '滋賀県': 16, '奈良県': 12, '和歌山県': 8}
BASKET = 'まいばすけっと'
PREFS = '北海道 青森県 岩手県 宮城県 秋田県 山形県 福島県 茨城県 栃木県 群馬県 埼玉県 千葉県 東京都 神奈川県 新潟県 富山県 石川県 福井県 山梨県 長野県 岐阜県 静岡県 愛知県 三重県 滋賀県 京都府 大阪府 兵庫県 奈良県 和歌山県 鳥取県 島根県 岡山県 広島県 山口県 徳島県 香川県 愛媛県 高知県 福岡県 佐賀県 長崎県 熊本県 大分県 宮崎県 鹿児島県 沖縄県'.split()
PREF_CODE = {p: f'{i:02}' for i, p in enumerate(PREFS, 1)}

def load_master(path):
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == HASH
    with zipfile.ZipFile(path) as archive:
        def read(name):
            with archive.open(name) as stream:
                rows = list(csv.DictReader(io.TextIOWrapper(stream, encoding='utf-8-sig')))
            assert len({r[ID] for r in rows}) == len(rows)
            return rows
        master = read('通常掲載店舗.csv')
        ledger = read('座標調査への引継ぎ.csv')
    handoff = {r[ID]: r for r in ledger if r['公開区分'] == '通常掲載'}
    assert set(handoff) == {r[ID] for r in master}
    for r in master:
        h = handoff[r[ID]]
        for key in r.keys() & h.keys():
            assert r[key] == h[key], (r[ID], key)
        r.update(h)
    assert Counter(r['座標精度区分'] for r in master) == {'未確認': 4298, 'P3': 163, 'P4': 152}
    assert len(ledger) == 4728
    assert {r[ID] for r in ledger if r['公開区分'] != '通常掲載' and r['緯度']} == {
        'JP-27-000108', 'JP-27-000135', 'JP-27-000136'}
    return master, ledger

def draw_groups(rows, key, count):
    groups = defaultdict(deque)
    for r in rows:
        groups[key(r)].append(r)
    chosen = []
    while len(chosen) < count and any(groups.values()):
        for group in sorted(groups):
            if groups[group]:
                chosen.append(groups[group].popleft())
                if len(chosen) == count:
                    break
    return chosen

def select(master):
    candidates = sorted((r for r in master if r['座標精度区分'] == '未確認'),
                        key=lambda r: (r['公式URL種別'] != '公式個店', r['都道府県'], r['市区町村'], r[ID]))
    priority = [r for p in PRIORITY for r in candidates if r['都道府県'] == p]
    assert Counter(r['都道府県'] for r in priority) == PRIORITY
    outside = [r for r in candidates if r['都道府県'] not in PRIORITY]
    basket = draw_groups([r for r in outside if r['系列分類'] == BASKET],
                         lambda r: r['都道府県'], 90)
    other = draw_groups([r for r in outside if r['系列分類'] != BASKET],
                        lambda r: (r['系列分類'], r['実運営法人'],
                                   urlsplit(r['公式店舗URL']).hostname or ''), 149)
    selected = priority + other[:25] + basket[:14]
    for index in range(4):
        selected.extend(other[25 + 31*index:25 + 31*(index+1)])
        selected.extend(basket[14 + 19*index:14 + 19*(index+1)])
    assert len(selected) == len({r[ID] for r in selected}) == 300
    assert len({r['系列分類'] for r in selected}) == 16
    return [dict(r, バッチ=i//50+1, 調査順=i+1, 優先対象='優先' if i < 61 else '') for i, r in enumerate(selected)]

def write_csv(path, rows, fields=None):
    with open(path, 'w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fields if fields is not None else list(rows[0]))
        writer.writeheader()
        writer.writerows({key: row.get(key, "") for key in writer.fieldnames} for row in rows)

if __name__ == '__main__':
    master, _ = load_master(sys.argv[1])
    write_csv(sys.argv[2], select(master))
