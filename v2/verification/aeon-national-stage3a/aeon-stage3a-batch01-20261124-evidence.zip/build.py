import csv
import hashlib
import json
import math
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from geocode_abr import AddressIndex, manifest
from select_targets import HASH, ID, PRIORITY, load_master, select, write_csv
from poi import ATTRIBUTION, candidate, read_poi

FIELDS = '''全国統合ID 都道府県 市区町村 系列分類 実運営法人 有効屋号 表示用店舗名 表示用住所 公開区分 緯度 経度 座標系 座標精度区分 座標取得方法 座標根拠URL 根拠資料中の店舗名 根拠資料中の住所 根拠資料取得日時 座標確認日 位置区分 比較緯度 比較経度 比較座標根拠URL 比較距離m 比較の性質 店舗同一性の確認結果 座標再確認の要否 保留理由・備考 変換前緯度 変換前経度 変換前座標系 変換方法 根拠元更新日時 根拠データSHA256 参照ID 店舗同一性根拠URL 目視照合URL 公式店舗URL 分布図採用判定 座標ライセンス 座標出典 調査区分 バッチ 調査順 優先対象'''.split()
GRADES = ('P4', 'P3', 'P2', 'P1', '未確認')
TERMS = 'https://www.digital.go.jp/policies/base_registry_address_tos'
MASTER = 'https://github.com/Kussoon/kussoon.github.io/pull/758'

def rate(n, total):
    return round(100 * n / total, 2) if total else None

def distance(row):
    if not row['比較緯度'] or not row['比較経度']:
        return ''
    a, b = (math.radians(float(row[k])) for k in ('緯度', '比較緯度'))
    delta = math.radians(float(row['比較経度']) - float(row['経度']))
    h = math.sin((b-a)/2)**2 + math.cos(a)*math.cos(b)*math.sin(delta/2)**2
    return round(6371008.8 * 2 * math.asin(math.sqrt(min(h, 1))), 1)

def project(row):
    return {k: row.get(k, '') for k in FIELDS}

def baseline(row):
    return project({**row, '調査区分': '継承' if row['緯度'] else '対象外（今回）',
                    '座標系': '継承原値・この工程では未再判定' if row['緯度'] else '',
                    '保留理由・備考': row.get('座標備考', ''),
                    '分布図採用判定': '既存判定を維持' if row['緯度'] else '未確認'})

def totals(rows):
    counts = Counter(r['座標精度区分'] for r in rows)
    n = len(rows)
    got = n - counts['未確認']
    return {'対象数': n, **{g: counts[g] for g in GRADES}, '座標あり': got,
            '座標取得率_%': rate(got,n), 'P4確定率_%': rate(counts['P4'],n),
            'P3以上率_%': rate(counts['P3']+counts['P4'],n)}

def summary(rows, field):
    groups = defaultdict(list)
    for r in rows:
        groups[r[field]].append(r)
    return [{field: k, **totals(group)} for k, group in sorted(groups.items())]

def excel(path, sheets):
    book = Workbook()
    book.remove(book.active)
    numbers = {'緯度','経度','比較緯度','比較経度','比較距離m','変換前緯度','変換前経度'}
    for name, rows, fields in sheets:
        ws = book.create_sheet(name)
        ws.append(fields)
        widths = [len(k) * 2 for k in fields]
        for r in rows:
            values = [float(r[k]) if k in numbers and r.get(k, '') != '' else r.get(k, '') for k in fields]
            ws.append(values)
            for i, value in enumerate(values):
                if isinstance(value, str) and value.startswith(('=', '+', '-', '@')):
                    ws.cell(ws.max_row, i+1).data_type = 's'
                widths[i] = max(widths[i], len(str(value)))
        ws.freeze_panes = 'D2' if ID in fields else 'B2'
        ws.auto_filter.ref = ws.dimensions
        for cell in ws[1]:
            cell.fill = PatternFill('solid', fgColor='225C4E')
            cell.font = Font(color='FFFFFF', bold=True)
            cell.alignment = Alignment(wrap_text=True, vertical='center')
        ws.row_dimensions[1].height = 30
        for i, width in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = max(14, min(53, width + 3))
    book.save(path)

def run(master_path, data, out, date, poi_log, facility_log):
    master, ledger = load_master(master_path)
    selection = select(master)
    data = Path(data)
    sources = manifest(data)
    indexes = {}
    results = []
    evidence = []
    poi_data = read_poi(poi_log)
    poi_evidence = []
    poi_review = []
    here = Path(__file__).resolve().parent
    with (here/'reviewed_poi.tsv').open(encoding='utf-8', newline='') as stream:
        reviewed = {r[ID]:r for r in csv.DictReader(stream, delimiter='\t')}
    with (here/'reviewed_facilities.tsv').open(encoding='utf-8', newline='') as stream:
        facility_reviews = {r[ID]:r for r in csv.DictReader(stream, delimiter='\t')}
    facilities = {r['id']:r for line in Path(facility_log).read_text().splitlines()
                  if (r := json.loads(line))}
    for r in selection:
        p = r['都道府県']
        if p not in indexes:
            indexes[p] = AddressIndex(data, p, sources)
        found, reason = indexes[p].match(r)
        attempt = {**r, '調査区分': '第1回', '座標再確認の要否': '要',
                   '分布図採用判定': '保留',
                   '店舗同一性の確認結果': '正本の店舗IDに紐付け。位置と個店の同一性は未確認'}
        if found:
            source_record = found.pop('根拠元レコード')
            attempt.update(found, 座標確認日=date, 座標ライセンス='CC BY 4.0（データカタログ）・ABR利用規約参照',
                           座標出典='デジタル庁 アドレス・ベース・レジストリをCodexが加工',
                           **{'保留理由・備考':'住所推定。現店舗・入居施設と位置を個別に確認する'})
            attempt['比較距離m'] = distance(attempt)
            if isinstance(attempt['比較距離m'], float) and attempt['比較距離m'] > 5000:
                reason = '街区代表点と町字代表点の距離が5 km超。要個別確認'
                evidence.append({ID:r[ID], 'status':'withheld', 'source':found, 'record':source_record})
            else:
                evidence.append({ID:r[ID], 'status':'provisional', 'source':found, 'record':source_record})
        if reason:
            attempt = {**r, '調査区分': '第1回', '分布図採用判定': '未確認',
                       '座標再確認の要否': '要', '保留理由・備考': reason + '。店舗・施設の座標は保留',
                       '店舗同一性の確認結果': '正本IDのみ確認'}
        query = poi_data.get(r[ID], {})
        match = candidate(r, query)
        if query:
            snapshot = {k:query[k] for k in (ID,'batch','url','at','http')}
            snapshot['response'] = {'count':query['response']['count'], 'results':[match] if match else []}
            poi_evidence.append(snapshot)
        review = reviewed.get(r[ID])
        facility = facility_reviews.get(r[ID])
        if facility:
            data_row = facilities[facility['Wikidata ID']]
            values = [v['mainsnak']['datavalue']['value'] for v in data_row['coordinates']
                      if v['rank'] != 'deprecated' and 'datavalue' in v['mainsnak']]
            assert len(values) == 1 and values[0]['globe'].endswith('/Q2')
            lat,lon = values[0]['latitude'],values[0]['longitude']
            compare_lat,compare_lon = attempt['緯度'],attempt['経度']
            compare_url = attempt['座標根拠URL']
            attempt = {**r, '調査区分':'第1回', '座標精度区分':'P4', '座標系':'WGS84 (EPSG:4326)',
                       '緯度':str(lat), '経度':str(lon), '座標取得方法':'施設公式・Wikidata P625・地理院地図照合',
                       '座標根拠URL':data_row['url'], '根拠資料取得日時':data_row['at'],
                       '座標確認日':facility['確認日'], '根拠資料中の店舗名':facility['根拠資料中の店舗名'],
                       '根拠資料中の住所':facility['根拠資料中の住所'], '根拠元更新日時':data_row['modified'],
                       '位置区分':'商業施設代表点', '参照ID':data_row['id'],
                       '店舗同一性根拠URL':facility['公式照合URL'], '目視照合URL':facility['目視照合URL'],
                       '比較緯度':compare_lat, '比較経度':compare_lon, '比較座標根拠URL':compare_url,
                       '比較の性質':'ABR住所代表点との距離' if compare_lat else '',
                       '店舗同一性の確認結果':'施設公式で現行テナントと住所を照合。施設位置を地理院地図で確認',
                       '座標再確認の要否':'定期確認', '保留理由・備考':facility['目視結果'],
                       '座標ライセンス':'CC0 1.0', '座標出典':'Wikidata 構造化データ（P625）',
                       '分布図採用判定':'目的に適合（施設代表点）'}
            attempt['比較距離m'] = distance(attempt)
        elif review:
            assert match and match['source'] == 'overture'
            assert (float(review['緯度']),float(review['経度'])) == (match['lat'],match['lng'])
            compare_lat,compare_lon = attempt['緯度'],attempt['経度']
            compare_url = attempt['座標根拠URL']
            attempt = {**r, '調査区分':'第1回', '座標精度区分':'P3', '座標系':'WGS84 (EPSG:4326)',
                       '緯度':str(match['lat']), '経度':str(match['lng']), '座標取得方法':'OpenPOI / Overture Places',
                       '座標根拠URL':query['url'], '根拠資料取得日時':query['at'], '座標確認日':review['確認日'],
                       '根拠資料中の店舗名':match['name'], '根拠資料中の住所':match['address'],
                       '根拠元更新日時':match.get('source_updated_at',''), '位置区分':review['位置区分'],
                       '店舗同一性根拠URL':review['公式照合URL'], '目視照合URL':review['目視照合URL'],
                       '比較緯度':compare_lat, '比較経度':compare_lon, '比較座標根拠URL':compare_url,
                       '比較の性質':'ABR住所代表点。距離は建物位置誤差の指標ではない' if compare_lat else '',
                       '店舗同一性の確認結果':'公式店名・住所と地点データの名称・住所一致',
                       '座標再確認の要否':'定期確認', '保留理由・備考':review['目視結果'],
                       '座標ライセンス':json.dumps(match['licenses'],ensure_ascii=False),
                       '座標出典':json.dumps(match['attributions'],ensure_ascii=False)+f' / OpenPOI API {ATTRIBUTION}',
                       '分布図採用判定':'目的に適合（P3、暫定）'}
            attempt['比較距離m'] = distance(attempt)
        elif match:
            poi_review.append({ID:r[ID], 'バッチ':r['バッチ'], '表示用店舗名':r['表示用店舗名'],
                               '地点名':match['name'], '地点住所':match['address'],
                               '候補緯度':match['lat'], '候補経度':match['lng'],
                               '出所':match['source'], '推定レベル':match.get('level',''),
                               'ライセンス':json.dumps(match['licenses'],ensure_ascii=False),
                               '出典':json.dumps(match['attributions'],ensure_ascii=False),
                               '根拠URL':query['url'], '取得日時':query['at'],
                               '備考':'建物・施設との照合待ち' if match['source']=='overture'
                               else '座標が住所推定か店舗地点かを確認する'})
        results.append(project(attempt))
    updates = {r[ID]: r for r in results}
    cumulative = [updates.get(r[ID], baseline(r)) for r in master]
    assert len(cumulative) == 4613 and len(updates) == 300
    accumulated = {r[ID]:r for r in cumulative}
    for r in master:
        if r['緯度']:
            assert all(accumulated[r[ID]][k] == r[k] for k in FIELDS if k in r and k != '座標系')
    mapped = {(r['緯度'],r['経度']) for r in results if r['緯度']}
    duplicates = defaultdict(list)
    for r in cumulative:
        pair = (r['緯度'],r['経度'])
        if pair in mapped:
            duplicates[pair].append(r)
    collision = []
    for group in duplicates.values():
        if len(group) < 2:
            continue
        shared_town = (all(r['座標精度区分'] == 'P1' for r in group)
                       and len({r['参照ID'] for r in group}) == 1
                       and len({r['表示用住所'] for r in group}) == len(group))
        note = ('異なる住所が同一の町字IDを参照。座標集中は町字代表点の共有による'
                if shared_town else '座標が一致。施設・出所を要個別確認')
        collision.extend({**r, '同一座標件数':len(group), '評価':note} for r in group)
    reports = []
    for b in range(1, 7):
        batch = [r for r in results if r['バッチ'] == b]
        got = [r for r in batch if r['緯度']]
        assert len(batch) == len({r[ID] for r in batch}) == 50
        assert all(r['公開区分'] == '通常掲載' for r in batch)
        assert all(r['座標系'] == 'WGS84 (EPSG:4326)' and
                   24 < float(r['緯度']) < 46 and 122 < float(r['経度']) < 147 and
                   all(r[k] for k in ('座標根拠URL','根拠資料取得日時')) and
                   (r['座標精度区分'] in ('P3','P4') or all(r[k] for k in ('参照ID','変換前座標系','変換方法')))
                   for r in got)
        assert all(r['座標精度区分'] in GRADES[:-1] for r in got)
        assert all(r[ID] in facility_reviews for r in got if r['座標精度区分']=='P4')
        assert all(r[ID] in reviewed for r in got if r['座標精度区分']=='P3')
        assert all(bool(r['緯度']) == bool(r['経度']) == (r['座標精度区分'] != '未確認') for r in batch)
        reports.append({'バッチ': b, '優先店舗': sum(bool(r['優先対象']) for r in batch),
                        **totals(batch), 'ID重複・誤割当': 0, '通常掲載外': 0, '経緯度逆転・範囲外': 0,
                        '根拠URL・日時欠落': 0, '既存座標変更': 0,
                        '同一座標該当行': sum(len(duplicates[(r['緯度'],r['経度'])]) > 1 for r in got),
                        '住所推定採用行':sum(r['座標精度区分'] in ('P1','P2') for r in got),
                        '地点の公式同定と建物輪郭目視':sum(r[ID] in reviewed or r[ID] in facility_reviews for r in got),
                        'OpenPOI検索済み':sum(r[ID] in poi_data for r in batch),
                        '旧店舗・同一施設の確認':'要再確認', 'P4根拠不足':0})
    rest = [r for r in cumulative if r['座標精度区分'] in ('P1','P2','未確認')]
    exclusion = [r for r in ledger if r['公開区分'] != '通常掲載' and r['緯度']]
    ledger_summary = summary(ledger,'公開区分')
    national = [{'段階':'開始時', **totals(master)}, {'段階':'第1回後（P1/P2含む）', **totals(cumulative)}]
    series = summary(cumulative,'系列分類')
    prefs = summary(cumulative,'都道府県')
    new_series = summary(results,'系列分類')
    new_prefs = summary(results,'都道府県')
    pref_series = defaultdict(list)
    for r in cumulative:
        pref_series[(r['都道府県'],r['系列分類'])].append(r)
    cross = [{'都道府県':pref,'系列分類':series_name,**totals(group)}
             for (pref,series_name),group in sorted(pref_series.items())]

    with (here/'methods.tsv').open(encoding='utf-8', newline='') as stream:
        methods = list(csv.DictReader(stream, delimiter='\t'))
    for method in methods:
        method.update(公式座標採用=0, 率の扱い='代表ページ観察。公式方式の母集団に対する率は未測定')
    for grade, method_name, method_url in (
            ('P4','施設公式 / Wikidata P625','https://www.wikidata.org/wiki/Wikidata:Licensing'),
            ('P3','OpenPOI / Overture Places','https://docs.openpoiapi.com/'),
            ('P2','ABR街区代表点','https://www.digital.go.jp/policies/base_registry_address'),
            ('P1','ABR町字代表点','https://www.digital.go.jp/policies/base_registry_address')):
        count = sum(r['座標精度区分'] == grade for r in results)
        total = {'P4':len(facilities),'P3':len(poi_evidence)}.get(grade,len(results))
        methods.append({'系列分類':'系列横断', '実運営法人・サイト':method_name, '代表URL':method_url,
                        '識別子・URL構造':'店舗名・住所照合' if grade == 'P3' else '自治体コード・町字ID・街区ID',
                        '公式地図・座標候補':'手法の判定実績 '+grade,
                        '利用条件URL':{'P4':'https://www.wikidata.org/wiki/Wikidata:Licensing','P3':ATTRIBUTION}.get(grade,TERMS),
                        '率の扱い':f'{count}/{total}件（{rate(count,total)}%）。P3は目視確認済みのみ。街区・町字は最終採録数',
                        '公式座標採用':0})
    corrections = [{
        ID:'JP-28-000001','表示用店舗名':'KOHYO住吉店','現精度':'P4',
        '現緯度':next(r['緯度'] for r in master if r[ID]=='JP-28-000001'),
        '現経度':next(r['経度'] for r in master if r[ID]=='JP-28-000001'),
        '比較結果':'現座標と公式iframeの表示中心の数値が一致。店舗マーカー座標と同値かは未確認',
        '根拠URL':'https://www.daiei.co.jp/stores/6434/',
        '処理':'変更なし。別工程で許諾済み資料または現地・公式の店舗／施設地点を照合',
    }]
    ledger_issues = [{ID:r[ID], '表示用店舗名':r['表示用店舗名'],'種別':'運営会社欄が空欄',
                      '根拠':'正本の通常掲載CSV。実運営法人を公式資料で再確認する',
                      'URL':r['公式店舗URL']} for r in master if not r['実運営法人']]
    # Export only sources and classifications used by this investigation.
    out = Path(out)
    a, e = out/'results', out/'evidence'
    a.mkdir(parents=True, exist_ok=True)
    e.mkdir(parents=True, exist_ok=True)
    exports = [
        ('第1回調査300店舗',results,FIELDS), ('全国累計4613店舗',cumulative,FIELDS),
        ('全国進捗',national,list(national[0])), ('全国都道府県別',prefs,list(prefs[0])),
        ('全国系列別',series,list(series[0])), ('全国府県系列別',cross,list(cross[0])), ('第1回都道府県別',new_prefs,list(new_prefs[0])),
        ('第1回系列別',new_series,list(new_series[0])), ('系列別取得方式',methods,list(methods[0])),
        ('未確認・要再調査',rest,FIELDS), ('地点照合待ち',poi_review,[ID,'バッチ','表示用店舗名','地点名','地点住所','候補緯度','候補経度','出所','推定レベル','ライセンス','出典','根拠URL','取得日時','備考']), ('座標修正候補',corrections,list(corrections[0])),
        ('台帳修正候補',ledger_issues,list(ledger_issues[0])),
        ('管理台帳開始時集計',ledger_summary,list(ledger_summary[0])),
        ('通常掲載外の継承3件',exclusion,list(exclusion[0])),
        ('バッチ検証',reports,list(reports[0])),
    ]
    for name, rows, fields in exports:
        write_csv(a/(name+'.csv'), rows, fields)
    excel(a/'第1回座標調査.xlsx', exports)
    write_csv(e/'採用地点の独立照合.csv',[
        {ID:r[ID], '名称':r['表示用店舗名'], '精度':r['座標精度区分'],
         '地理院地図URL':(facility_reviews.get(r[ID]) or reviewed[r[ID]])['目視照合URL'],
         '公式照合URL':(facility_reviews.get(r[ID]) or reviewed[r[ID]])['公式照合URL'],
         '見立て':r['保留理由・備考']} for r in results if r['座標精度区分'] in ('P3','P4')])
    write_csv(e/'バッチ検証.csv',reports)
    write_csv(e/'比較座標・距離.csv',[r for r in results if r['比較緯度']],
              [ID,'バッチ','緯度','経度','比較緯度','比較経度','比較距離m','比較座標根拠URL','比較の性質'])
    write_csv(e/'同一座標検査.csv',collision,FIELDS+['同一座標件数','評価'])
    with (e/'ABR照合証跡.jsonl').open('w',encoding='utf-8') as stream:
        for row in evidence:
            print(json.dumps(row,ensure_ascii=False),file=stream)
    write_csv(e/'店舗別取得ログ.csv',[{k:r[k] for k in (
        ID,'バッチ','調査順','公式店舗URL','座標精度区分','根拠資料取得日時','座標根拠URL',
        '参照ID','保留理由・備考')} for r in results])
    with (e/'OpenPOI照合証跡.jsonl').open('w',encoding='utf-8') as stream:
        for row in poi_evidence:
            print(json.dumps(row,ensure_ascii=False),file=stream)
    metrics = {'poi_searches':len(poi_evidence), 'unreviewed_poi':len(poi_review), 'national':national,'new':totals(results),'priority':totals([r for r in results if r['優先対象']]),
               'basket':totals([r for r in results if r['系列分類']=='まいばすけっと']),
               'collisions':len(collision),'distance_checks':sum(bool(r['比較緯度']) for r in results),
               'sources':len(sources)}
    (e/'集計検証.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
    return metrics

if __name__ == '__main__':
    print(json.dumps(run(*sys.argv[1:]),ensure_ascii=False,indent=2))
