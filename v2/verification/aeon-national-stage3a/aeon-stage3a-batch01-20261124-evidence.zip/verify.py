import csv
import sys
from collections import Counter
from pathlib import Path

from openpyxl import load_workbook
from select_targets import ID, PRIORITY, load_master

def read(path):
    with path.open(encoding='utf-8-sig',newline='') as stream:
        return list(csv.DictReader(stream))

def verify(master, root):
    original, ledger = load_master(master)
    root = Path(root)
    current = read(root/'全国累計4613店舗.csv')
    assert len(current) == len({r[ID] for r in current}) == 4613
    started = {r[ID]:r for r in original}
    for r in current:
        old = started[r[ID]]
        for k in ('都道府県','市区町村','系列分類','実運営法人','有効屋号','表示用店舗名','表示用住所','公開区分'):
            assert r[k] == old[k], (r[ID],k)
        if old['緯度']:
            for k in ('緯度','経度','座標精度区分','座標確認日','座標根拠URL','位置区分'):
                assert r[k] == old[k], (r[ID],k)
    investigation = read(root/'第1回調査300店舗.csv')
    assert Counter(r['バッチ'] for r in investigation) == {str(k):50 for k in range(1,7)}
    assert Counter(r['都道府県'] for r in investigation if r['優先対象']) == PRIORITY
    assert len({r['系列分類'] for r in investigation}) == 16
    assert len({r[ID] for r in investigation}) == 300
    current_by_id = {r[ID]:r for r in current}
    assert all(current_by_id[r[ID]] == r and not started[r[ID]]['緯度'] for r in investigation)
    assert all(bool(r['緯度']) == bool(r['経度']) == (r['座標精度区分'] != '未確認') for r in current)
    assert all(r['分布図採用判定'] == '保留' for r in investigation if r['座標精度区分'] in ('P1','P2'))
    excluded = read(root/'通常掲載外の継承3件.csv')
    assert excluded == [r for r in ledger if r['緯度'] and r['公開区分'] != '通常掲載']
    sheet = load_workbook(root/'第1回座標調査.xlsx',read_only=True)
    assert sheet['第1回調査300店舗'].max_row == 301
    assert sheet['全国累計4613店舗'].max_row == 4614
    print('PASS 正本ハッシュ・IDと掲載区分・既存座標・6バッチ・優先4府県・全国16系列・ExcelとCSVの行数')

if __name__ == '__main__':
    verify(*sys.argv[1:])
