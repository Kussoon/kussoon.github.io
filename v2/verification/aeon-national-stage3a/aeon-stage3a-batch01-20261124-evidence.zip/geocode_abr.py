import csv
import hashlib
import io
import json
import re
import unicodedata
import zipfile
from collections import defaultdict
from functools import lru_cache
from pathlib import Path

from pyproj import Transformer

from select_targets import PREF_CODE

DASHES = str.maketrans({c: '-' for c in '‐‑‒–—―−'})
DIGITS = '〇一二三四五六七八九'

def kanji_number(text):
    value = total = 0
    for char in text:
        if char in DIGITS or char == '零':
            value = value * 10 + (DIGITS.index(char) if char != '零' else 0)
        else:
            total += (value or 1) * {'十': 10, '百': 100, '千': 1000}[char]
            value = 0
    return str(total + value)

def normalize(value):
    value = unicodedata.normalize('NFKC', value).translate(DASHES)
    value = re.sub(r'[\s\u3000]+', '', value)
    value = re.sub(r'[〇零一二三四五六七八九十百千]+(?=丁目|番地|番|号)',
                   lambda m: kanji_number(m[0]), value)
    return value

def read_verified(directory, manifest, filename):
    meta = manifest.get(filename)
    if meta is None:
        return [], {}
    path = directory / filename
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != meta['sha256']:
        raise ValueError(f'ABR hash mismatch: {filename}')
    with zipfile.ZipFile(path) as archive:
        entries = [n for n in archive.namelist() if n.lower().endswith('.csv')]
        if len(entries) != 1:
            raise ValueError(filename)
        with archive.open(entries[0]) as stream:
            rows = list(csv.DictReader(io.TextIOWrapper(stream, encoding='utf-8-sig')))
    return rows, meta

def key(row):
    return row['lg_code'], row['machiaza_id']

def positions(rows, key_fn):
    groups = defaultdict(list)
    for r in rows:
        if r['rep_lat'] and r['rep_lon'] and r['rep_srid']:
            groups[key_fn(r)].append(r)
    return {k: group[0] for k, group in groups.items()
            if len({(r['rep_lat'],r['rep_lon'],r['rep_srid']) for r in group}) == 1}

@lru_cache
def transformer(crs):
    return Transformer.from_crs(crs, 'EPSG:4326', always_xy=True)

def point(row, prefecture):
    srid = row['rep_srid']
    if srid not in {'EPSG:4612','EPSG:6668','EPSG:4326','4612','6668','4326'}:
        return None
    lon, lat = transformer(srid).transform(float(row['rep_lon']), float(row['rep_lat']))
    if not (24 < lat < 46 and 122 < lon < 147):
        return None
    if row.get('pos_pref') and prefecture != row['pos_pref']:
        return None
    return {'緯度': f'{lat:.8f}', '経度': f'{lon:.8f}', '変換前緯度': row['rep_lat'],
            '変換前経度': row['rep_lon'], '変換前座標系': srid,
            '変換方法': f'PROJ {srid} → EPSG:4326 (always_xy)'}
   
class AddressIndex:
    def __init__(self, directory, prefecture, manifest):
        code = PREF_CODE[prefecture]
        self.prefecture = prefecture
        self.meta = {}
        def get(kind):
            rows, self.meta[kind] = read_verified(directory, manifest, f'{kind}_pref{code}.csv.zip')
            return rows

        self.prefixes = defaultdict(dict)
        for r in get('mt_town_fullset'):
            if r.get('status_flg') not in ('0', '1') or r.get('ablt_date') or not r['city']:
                continue
            town = r['oaza_cho'] + r['chome'] + r['koaza']
            if not town:
                continue
            muni = r['city'] + r['ward']
            prefixes = self.prefixes[muni]
            for county in {r['county'], ''}:
                pre = normalize(prefecture + county + muni + town)
                prefixes.setdefault(pre, {})[key(r)] = r
                chome = normalize(r['chome'])
                if chome.endswith('丁目'):
                    pre = normalize(prefecture + county + muni + r['oaza_cho'])
                    dash = pre + chome[:-2] + '-' + normalize(r['koaza'])
                    prefixes.setdefault(dash, {})[key(r)] = r
        self.town_points = positions(get('mt_town_pos'), key)
        self.blocks = defaultdict(set)
        for r in get('mt_rsdtdsp_blk'):
            if r['rsdt_addr_flg'] == '1' and not r.get('ablt_date'):
                block_number = normalize(r['blk_num'])
                if block_number:
                    self.blocks[key(r) + (block_number,)].add(r['blk_id'])
        self.block_points = positions(get('mt_rsdtdsp_blk_pos'), lambda r: key(r) + (r['blk_id'],))

    def match(self, store):
        address = normalize(store['表示用住所'])
        group = self.prefixes.get(store['市区町村'], {})
        matches = []
        for prefix, options in group.items():
            if address.startswith(prefix):
                suffix = address[len(prefix):]
                if not suffix or re.match(r'^-?\d', suffix):
                    matches.append((len(prefix), options, suffix))
        if not matches:
            return None, '都道府県・市区町村・町字の前方一致なし'
        _, options, suffix = max(matches, key=lambda m: m[0])
        if len(options) != 1:
            return None, '町字IDが一意でない'
        town_key, town = next(iter(options.items()))
        matched_address = ''.join(town[k] for k in ('pref','county','city','ward','oaza_cho','chome','koaza'))
        town_record = self.town_points.get(town_key)
        town_point = point(town_record, self.prefecture) if town_record else None
        match = re.match(r'^-?(\d+)(?=番|地番|[-―]|$)', suffix)
        if match:
            block_number = match[1]
            block_ids = self.blocks.get(town_key + (block_number,), set())
            if len(block_ids) == 1:
                block_id = next(iter(block_ids))
                block_record = self.block_points.get(town_key + (block_id,))
                if block_record and block_record['rsdt_addr_flg'] == '1':
                    block_point = point(block_record, self.prefecture)
                    if block_point:
                        return self.result(block_point, 'P2', matched_address + block_number + '番',
                                           'mt_rsdtdsp_blk_pos', town_key + (block_id,),
                                           block_record, town_point), ''
        if town_point:
            return self.result(town_point, 'P1', matched_address, 'mt_town_pos', town_key,
                               town_record, None), ''
        return None, '一意の街区・町字代表点を取得できず'

    def result(self, coordinates, grade, address, kind, codes, record, comparison):
        meta = self.meta[kind]
        return {**coordinates, '座標精度区分': grade, '座標系': 'WGS84 (EPSG:4326)',
                '座標取得方法': 'ABR街区代表点' if grade == 'P2' else 'ABR町字代表点',
                '位置区分': '街区代表点（住所推定）' if grade == 'P2' else '町字代表点（概略）',
                '根拠資料中の住所': address, '座標根拠URL': meta['url'],
                '根拠資料取得日時': meta['at'], '根拠元更新日時': meta['modified'],
                '根拠データSHA256': meta['sha256'], '参照ID': '/'.join(codes),
                '比較緯度': comparison['緯度'] if comparison else '',
                '比較経度': comparison['経度'] if comparison else '',
                '比較座標根拠URL': self.meta['mt_town_pos']['url'] if comparison else '',
                '比較の性質': '同じABRの町字代表点。店舗地点の独立検証ではない' if comparison else '',
                '根拠元レコード': record}
def manifest(directory):
    path = Path(directory) / 'fetch.jsonl'
    if not path.exists():
        return {}
    rows = (json.loads(line) for line in path.read_text().splitlines())
    return {r['file']: r for r in rows if r['status'] == 'ok'}
