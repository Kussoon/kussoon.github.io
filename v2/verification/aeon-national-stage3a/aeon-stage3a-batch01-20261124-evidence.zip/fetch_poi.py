import csv
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode

ID = '全国統合ID'
BASE = 'https://api.openpoiapi.com/v1/search'

def main(targets, output):
    path = Path(output)
    complete = set()
    if path.exists():
        complete = {r[ID] for line in path.read_text().splitlines()
                    if (r := json.loads(line))['http'] == '200'}
    with open(targets, encoding='utf-8-sig', newline='') as f, path.open('a',encoding='utf-8') as log:
        errors = 0
        for store in csv.DictReader(f):
            if store[ID] in complete:
                continue
            name = store['表示用店舗名'].split('・イオンフードスタイル')[0]
            url = BASE + '?' + urlencode({'q': name, 'limit': 10})
            p = subprocess.run(['curl','-LsS','--max-time','12','-w','\n%{http_code}',url],
                               capture_output=True, text=True)
            body, _, status = p.stdout.rpartition('\n')
            row = {ID:store[ID], 'batch':store['バッチ'], 'url':url,
                   'at':datetime.now(timezone.utc).isoformat(timespec='seconds'),
                   'http':status,'error':p.stderr.strip()}
            if status == '200':
                try:
                    row['response'] = json.loads(body)
                except json.JSONDecodeError:
                    row['http'] = 'invalid'
            errors = 0 if row['http'] == '200' else errors + 1
            print(json.dumps(row,ensure_ascii=False), file=log, flush=True)
            if status in ('401','403','429','503') or errors >= 3:
                break
            time.sleep(1.0)

if __name__ == '__main__':
    main(*sys.argv[1:])
