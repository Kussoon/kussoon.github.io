import json
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

def main():
    dest = Path('facilities.jsonl')
    ids = ['Q11286084','Q11286067','Q11286151','Q11286290','Q17213031','Q11286081','Q11286191','Q11286182','Q11286107','Q17216508','Q11274530']
    with dest.open('w',encoding='utf-8') as f:
        for q in ids:
            url = f'https://www.wikidata.org/wiki/Special:EntityData/{q}.json'
            p = subprocess.run(['curl','-fLsS','--max-time','16',url],
                               capture_output=True, text=True)
            if p.returncode:
                print(q,p.stderr)
                continue
            record = json.loads(p.stdout)['entities'][q]
            subset = {'id':q,'url':url,'at':datetime.now(timezone.utc).isoformat(timespec='seconds'),
                      'revision':record.get('lastrevid'),'modified':record.get('modified'),
                      'coordinates':record['claims'].get('P625',[]),
                      'labels':{k:v for k,v in record['labels'].items() if k in ('ja','en')}}
            print(json.dumps(subset,ensure_ascii=False), file=f, flush=True)
            print(q,subset['labels'],[c['mainsnak'].get('datavalue',{}).get('value') for c in subset['coordinates']])
            time.sleep(1.0)
if __name__ == '__main__':
    main()
