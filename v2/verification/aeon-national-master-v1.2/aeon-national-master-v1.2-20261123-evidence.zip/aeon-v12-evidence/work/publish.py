"""Export and validate a single authoritative register and its ID-based derived tables."""
import argparse,json,re
from collections import Counter,defaultdict
from pathlib import Path
from openpyxl import Workbook,load_workbook
from assembly import *
from coord import attach,history,HYOGO

NAME='全国統合マスターVer1.2-20261123.xlsx'
TRACK_FIELDS=('店舗名','屋号','運営会社','住所','掲載区分','営業状態','公式店舗URL','現行公式名','公式住所（掲載表記）','関連全国統合ID')
FOCUS_FIELDS=('実運営法人','有効屋号','表示用住所','基準日時点の住所','掲載適格性','掲載適格性根拠URL','営業判定根拠URL',
              '住所根拠URL','統合先ID','緯度','経度','座標精度区分')
PUBLISHED_FIELDS=('全国統合ID','都道府県','市区町村','表示用店舗名','公式店舗名','有効屋号','系列分類','実運営法人','表示用住所',
    '郵便番号','全国調査基準日','公開区分','公式店舗URL','公式URL種別','基準日営業状況','営業判定根拠URL','掲載適格性',
    '掲載適格性根拠URL','住所根拠URL','緯度','経度','座標精度区分','座標確認日','位置区分','座標根拠URL','座標再確認の要否')
HIDDEN_LEGACY=('版間照合','ID継承・新規','元資料の訂正記録','公式件数比較','採用資料','原資料補足','入手資料',
               '台帳変更履歴','反映判定267項目','新規追加店舗','条件付き掲載提案','今回の判断保留','営業例外・改称履歴',
               '公式照合履歴650件','一覧の差分・掲載漏れ','前回掲載漏れ候補','追加根拠と調査日時')
COORD_FIELDS=('緯度','経度','座標精度区分','座標取得方法','座標根拠URL','座標確認日','位置区分','座標再確認の要否','座標備考','座標継承資料')

def review_actions(rows,approvals,dupes,archive):
    maps={'店舗名':'表示用店舗名','屋号':'屋号','運営会社':'実運営法人','系列':'系列分類','住所':'公式住所原文',
          '掲載区分':'公開区分','営業状況':'基準日営業状況','掲載適格性':'掲載適格性','重複整理':'統合先ID'}
    actions=[]
    for a in approvals:
        uid,f=a['全国統合ID'],a['修正項目'];r=rows[uid]
        stage=a['重点監査審査結果']; val=a['承認候補値']; url=a['重点監査根拠URL']
        before=archive[uid]; status='維持'; why='表記差、見送り、または調査手順を保持。'
        if stage=='判断保留':
            status='保留';why=a['今回承認理由'] or '第2段階Cの保留を維持。'
        if stage in APPROVED:
            assert val and url.startswith('http'),(uid,f,val,url)
            date=a['発効日（確認済み）']
            assert not date or date<=BASIS,(uid,date)
            checked=r[maps[f]]
            expect=food_equiv(val) if f=='掲載適格性' else ('履歴・休業・予定' if f=='掲載区分' and val=='履歴' else val)
            if f=='屋号' and expect==r['屋号'] and expect!=r['有効屋号']:
                raise ValueError((uid,'屋号承認値と集計値が不一致',expect,r['有効屋号']))
            assert checked==expect,(uid,f,expect,checked)
            status='反映済み';why='既存ID・根拠・確定値を突合。'
            if f=='住所':why='公式原文欄に採録。旧台帳住所と基準日住所は独立管理。'
            if f=='掲載適格性' and val!=expect:why='同じ内容をVer.1.2の掲載適格性区分に統一。'
            if f=='重複整理':assert dupes[uid]['残すID']==expect
        if f in ('屋号','運営会社','店舗名','住所') and status in ('維持','保留'):
            current=r['旧台帳住所'] if f=='住所' else r[f]
            assert current==before[f],(uid,f,status,current,before[f])
        actions.append(a|{'Ver1.2処理':status,'Ver1.2反映先':maps.get(f,''),'Ver1.2採録値':r.get(maps.get(f,''),''),
                          'Ver1.2統合理由':why})
    assert len(actions)==2992 and sum(r['Ver1.2処理']=='保留' for r in actions)==46
    return actions

def differences(old,rows,current):
    visual=[]
    for u,r in rows.items():
        o=old.get(u,{})
        legacy=o.get('掲載区分','')
        visual.append({'全国統合ID':u,'都道府県':r['都道府県'],'旧店舗名':o.get('店舗名',''),'新表示名':r['表示用店舗名'],
           '旧公開区分':legacy,'重点監査試算区分':current.get(u,{}).get('Ver1.2承認候補区分','通常掲載'),
           '新公開区分':r['公開区分'],'旧営業状態':o.get('営業状態',''),'基準日営業状況':r['基準日営業状況'],
           '掲載適格性':r['掲載適格性'],'旧住所':o.get('住所',''),'新表示住所':r['表示用住所'],
           '統合先ID':r['統合先ID'],'新規候補キー':r['候補キー'],'位置精度':r['座標精度区分'],'理由':r['公開区分理由']})
    details=[]; categories=Counter()
    for uid,r in rows.items():
        o=old.get(uid,{})
        for k in TRACK_FIELDS+FOCUS_FIELDS:
            l=o.get(k,'');a=r.get(k,'')
            if l==a:continue
            if k in ('緯度','経度','座標精度区分') and r['座標精度区分']=='未確認':continue
            if k in ('緯度','経度','座標精度区分'):u=r['座標根拠URL'];reason='既存の座標監査結果の継承'
            elif k in ('掲載適格性','掲載適格性根拠URL'):u=r['掲載適格性根拠URL'];reason=r.get('掲載適格性根拠説明','')
            elif k in ('予定','営業状態','営業判定根拠URL'):u=r['営業判定根拠URL'];reason=r.get('営業判定根拠説明','')
            elif k=='掲載区分':u=r['掲載区分根拠'];reason=r['公開区分理由']
            elif k in ('運営会社','実運営法人'):u=r['運営法人根拠URL'];reason=r['運営法人確認状態']
            elif k in ('関連全国統合ID','統合先ID'):u=r['掲載区分根拠'];reason='関連ID・重複統合先の継承'
            else:u=r['住所根拠URL'];reason=r.get('住所に関する保留事項','') if k in ('住所','基準日時点の住所','表示用住所') else '公式照合の確定値・由来を登録'
            if not o:reason='新規採用。'+reason
            details.append({'全国統合ID':uid,'都道府県':r['都道府県'],'店舗名':r['表示用店舗名'],
              '修正項目':k,'旧値':l,'新値':a,'理由':reason,'根拠URL':u})
            categories[k]+=1
    return visual,details,categories

def aggregate(rows):
    box=defaultdict(Counter)
    for r in rows.values():
        pref=r['都道府県'];op=r['系列分類'];legal=r['実運営法人'] or '法人未確定';brand=r['有効屋号'] or '屋号未記録'
        for key in (('全国',),('都道府県',pref),('系列',op),('実運営法人',legal),('屋号',brand),('系列×都道府県',op,pref)):
            q=box[key];q['全行']+=1;q[r['公開区分']]+=1;q['住所確認']+=bool(r['公式住所原文'])
            q['座標継承']+=r['座標精度区分']!='未確認'
            q['通常掲載の座標継承']+=r['座標精度区分']!='未確認' and r['公開区分']=='通常掲載'
            q['座標_'+r['座標精度区分']]+=1
    df=[]
    for k,q in box.items():
        axis,*f=k
        df.append({'集計軸':axis,'分類1':f[0] if f else '全国','分類2':f[1] if len(f)==2 else '',
                   **{s:q[s] for s in ('全行',*PUB,'住所確認','座標継承','通常掲載の座標継承','座標_P1','座標_P2','座標_P3','座標_P4','座標_未確認')}})
    top=df[0]
    for axis in ('都道府県','系列','実運営法人','屋号','系列×都道府県'):
        for k,v in top.items():
            if isinstance(v,int):assert v==sum(r[k] for r in df if r['集計軸']==axis),(axis,k)
    return df
def trial_review(rows,current,issued,data):
    truth=readcsv(data/'c/store-counts.csv')
    d=defaultdict(Counter);change=[]
    for u,r in rows.items():
        c=current.get(u,{})
        pre=c.get('Ver1.2承認候補区分','通常掲載')
        normalized='履歴・休業・予定' if pre=='履歴' else pre
        if normalized!=r['公開区分']:
            change.append({'全国統合ID':u,'項目':'公開区分','第2段階C':normalized,'Ver.1.2':r['公開区分'],'理由':r['公開区分理由']})
        src_brand=c.get('屋号') or (r['有効屋号'] if u not in current else '')
        if u in ALT_BRANDS:src_brand=ALT_BRANDS[u]
        if src_brand!=r['有効屋号']:
            change.append({'全国統合ID':u,'項目':'集計用屋号','第2段階C':src_brand,'Ver.1.2':r['有効屋号'],
                '理由':r['屋号の根拠・由来']})
        if r['公開区分']=='通常掲載':
            for k in (('全国','',''),('都道府県',r['都道府県'],''),('系列','',r['系列分類']),('系列×都道府県',r['都道府県'],r['系列分類'])):d[k]['通常掲載']+=1
    group=[]
    for s in truth:
        axis=s['集計単位']
        if axis=='屋号':continue
        k=(axis,s['都道府県'],s['系列']);expected=int(s['追加採用候補を含む試算']);act=d[k]['通常掲載']
        group.append({'集計軸':axis,'都道府県':k[1],'系列':k[2],'第2段階C通常掲載試算':expected,'Ver.1.2通常掲載':act,'差':act-expected})
        assert expected==act,(k,expected,act)
    assert all(r['項目']!='公開区分' for r in change)
    return group,change

def events(data,rows):
    after=readcsv(data/'c/post-baseline.csv')
    special={'マックスバリュ新宮店':'候補-f3bfc63c49f8','マックスバリュエクスプレス向野２丁目店':'候補-ab100d068e2e'}
    out=[]
    for r in after:
        n=r['対象']
        if n in special:match=[]
        else:match=[uid for uid,x in rows.items() if common_name(x['表示用店舗名'])==common_name(n)]
        if len(match)>1:raise ValueError((r,match))
        assert r['日付'][:10]>BASIS,r
        if match and ('開店予定' in r['区分'] or 'グランドオープン' in r['区分']):
            assert rows[match[0]]['公開区分']!='通常掲載',r
        out.append(r|{'全国統合ID':match[0] if match else '','候補キー':special.get(n,''),
                     '集計扱い':'2026-11-23の営業・通常掲載集計から独立管理'})
    assert len(out)==7
    return out

def pending(rows,actions):
    out=[]
    for r in rows.values():
        if r['公開区分']=='参考・保留':
            out.append({'全国統合ID':r['全国統合ID'],'店舗名':r['表示用店舗名'],'種類':'参考・保留の公開区分','現在の判定':r['掲載適格性'],
               '基準日営業状況':r['基準日営業状況'],'保留理由':r['保留理由'],'根拠URL':r['掲載適格性根拠URL'] or r['営業判定根拠URL'],
               '公開上の扱い':'参考・保留。通常掲載数から除外。'})
        if (r.get('住所に関する保留事項') and not r.get('基準日時点の住所')
                and r['公開区分']!='履歴・休業・予定'):
            out.append({'全国統合ID':r['全国統合ID'],'店舗名':r['表示用店舗名'],'種類':'基準日住所・枝番の確認',
                        '現在の判定':r['旧住所との関係'],'保留理由':r['住所に関する保留事項'],'根拠URL':r['住所根拠URL'],
                        '公開上の扱い':'公式住所原文と表示用住所を維持。基準日住所は保留。'})
        if not r['実運営法人']:
            out.append({'全国統合ID':r['全国統合ID'],'店舗名':r['表示用店舗名'],'種類':'実運営法人','現在の判定':'未確定',
              '保留理由':r['運営法人確認状態'],'根拠URL':r['住所根拠URL'],'公開上の扱い':'系列分類は既存値。法人未確定として集計。'})
    for c in actions:
        if c['Ver1.2処理']=='保留':
            out.append({'全国統合ID':c['全国統合ID'],'店舗名':c['店舗名'],'種類':'修正管理キーの保留','項目':c['修正項目'],
                '現在の判定':'判断保留','保留理由':c['Ver1.2統合理由'],'根拠URL':c['重点監査根拠URL'] or c['根拠URL'],
                '公開上の扱い':'既存値・公式原文・履歴を保持。'})
    return out

def coordinate_queue(rows):
    ans=[]
    for u,r in rows.items():
        public=r['公開区分'];p=r['座標精度区分']
        move='対象外・履歴を別管理' if public not in ('参考・保留','通常掲載') else '食品・掲載可否確認後に位置を調査' if public=='参考・保留' else '既存P4を維持' if p=='P4' else '個店位置を再確認' if p!='未確認' else '公式個店で位置を取得'
        ans.append({k:r.get(k,'') for k in ('全国統合ID','都道府県','市区町村','系列分類','表示用店舗名','公開区分','表示用住所','公式店舗URL','公式URL種別',
                    '住所根拠URL',*COORD_FIELDS)}|{'次工程の扱い':move})
    return ans

def defs():
    return [
      {'項目':'台帳基準日','定義':BASIS,'扱い':'取得日・確認日・発効日と区別。'},
      {'項目':'全国統合ID','定義':'既存4,701件を保持。新規27件は候補キーを種に固定発番。','扱い':'AE-＋SHA-256先頭16桁（大文字）。入力 KUSSOON|PHASE2D|候補キー。'},
      {'項目':'全国統合マスター','定義':'Ver.1.2の正本。ここから公開区分・集計・証跡表を再計算。','扱い':'派生表は同一ID・列を直接抽出。'},
      {'項目':'掲載区分／公開区分','定義':'通常掲載、参考・保留、対象外、履歴・休業・予定','扱い':'通常掲載は営業根拠と食品適格性根拠が必要。'},
      {'項目':'公式住所原文','定義':'第7回または重点監査の原文。','扱い':'原文の連続県名・空白も保持。'},
      {'項目':'住所／旧台帳住所','定義':'既存行ではVer.1.1の旧住所を継承。','扱い':'基準日住所・表示用住所と独立した旧値。'},
      {'項目':'基準日時点の住所','定義':'基準日時点との同一性を判定できる住所。','扱い':'旧地番、住号、発効日が確認できない場合は空欄。'},
      {'項目':'表示用住所','定義':'府県名の重複や余分な空白を整えた表示用所在地。','扱い':'公式原文を改変せず、枝番・住号を推定しない。'},
      {'項目':'店舗名・公式店舗名・旧店舗名','定義':'表示名、証跡の店名、旧台帳名を区別。','扱い':'改称・旧屋号は履歴資料と統合先IDで追跡。'},
      {'項目':'運営会社／実運営法人／系列分類／有効屋号','定義':'前者は既存・承認候補値。実運営法人は公式根拠に基づく法人欄。有効屋号は集計用。','扱い':'運営法人が未確定の場合は未確定区分で集計。'},
      {'項目':'座標精度区分','定義':'既往のP1〜P4（P1/P2は住所等の概略、P3は公式案内等、P4は照合済みの店舗名付き地点）。','扱い':'今回の主表は既往確定資料を継承。P1/P2比較点は履歴に保存。'},
      {'項目':'位置区分・座標再確認の要否','定義':'店舗名付き地点、施設代表点、公式案内点、利用者指定中心等を区別。','扱い':'P3・未確認は次工程で個店と施設・入口の区別を確認。'}
    ]

def provenance(rows):
    fields=('全国統合ID','都道府県','表示用店舗名','全国調査基準日','住所証跡採録段階','公式住所原文','住所確認資料種別','住所根拠URL',
      '公式資料取得日時UTC','住所応答SHA-256','住所同定補足URL','住所同定補足取得日時UTC','住所同定補足SHA256',
      '基準日営業状況','営業判定根拠URL','営業確認日時UTC','営業応答SHA-256','営業判定根拠説明','掲載適格性','掲載適格性根拠URL',
      '掲載適格性補足資料URL','掲載適格性資料取得日時UTC','掲載適格性根拠説明','実運営法人','運営法人根拠URL')
    return [slice_row(r,fields) for r in rows.values()]

def slice_row(r,fields):
    return {key:r.get(key,'') for key in fields}

def normal_proof(r):
    assert r['基準日営業状況']==ACTIVE_OP and r['掲載適格性'] in GOOD_FOOD
    assert r['営業判定根拠URL'] and r['掲載適格性根拠URL'] and r['住所根拠URL']

def protect_files(data):
    expected={'aeon-national-master-phase2c-20261123.zip':'d559b38962e8a428732c4873f7a5524904e39c08c9fc991930bb09211ed9af03',
     'aeon-round7-1-results.zip':'9de39aa280d953e7ee0aaf3e7ace74f305f27525065fc6c0ab57f686013346bc',
     'aeon-round7-2-evidence-part1.zip':'0f69b796ea77b3f9a5a25a4c342dbd418c61ccb2b70ee16a589372f8ba4c0aa7',
     'aeon-round7-2-evidence-part2.zip':'723617300aa9d9960dca0a72d274e5b42b0f0ad88f9de458216b14ea98a64c4a',
     'aeon-round7-2-evidence-part3.zip':'a60ff7ebf1dd14fe8ac17f5038ad6c4db241bfc490f2ab56f5c2d7b173c434b0',
     'aeon-stage2c-final-audit-evidence-part1.zip':'1b4a52bc71d6e79e1388c8c0745175849cc9b203f47bfdc7bf4a772228c6c5c6',
     'aeon-stage2c-final-audit-evidence-part2.zip':'ce04cb3683caa3fa15768bdacab7da830e19adce62a7ec2a6d3575e72c741623',
     'aeon-stage2c-final-audit-results.zip':'e6cba3bcef01af4f18032b439ab89bd691f5d99c04e911d5796a6a1bf65fa82c'}
    out=[]
    for line in (data/'original-archives.sha256').read_text().splitlines():
        h,file=line.split('  ',1);p=Path(file)
        name=p.name.removeprefix('1-')
        assert expected[name]==h,(name,h)
        checked=sha256(p) if p.exists() else h
        assert h==checked,p
        out.append({'ファイル':name,'SHA256':checked,'確認':'原ZIP実測一致' if p.exists() else '原取得時の記録'})
    assert len(out)==8
    return out


def build(data,out,evidence,tabular_only):
    out.mkdir(parents=True,exist_ok=True);evidence.mkdir(parents=True,exist_ok=True)
    oldfile=data/'v11'/BASEFILE
    start=sha256(oldfile);before=protect_files(data)
    orig,previous,r7,axes,approval,options=load_state(data)
    cf=data/'c-results'; hf=data/'r7'
    candidates=tab(cf/CANDIDATES,'指定18店舗の採否')+tab(cf/CANDIDATES,'旧保留からの追加採用案')
    assert len(one(candidates,'候補キー'))==27
    table=tab(cf/CANDIDATES,'重複整理・施設核対応')
    dup=one(table,'通常掲載から外すID')
    assert len(dup)==3
    historical=defaultdict(list)
    for row in tab(oldfile,'営業例外・改称履歴'):
        u=row['全国統合ID']
        if u in orig:
            historical[u].append(row['店舗名'])
            if row['関連全国統合ID'] in orig:historical[row['関連全国統合ID']].append(row['店舗名'])
    previous_cases=case_by_id(data)
    stores,address_clean=make_existing(orig,previous,r7,axes,options,previous_cases,dup)
    rows,issued,new_audit=flag_duplicates(stores,candidates,historical)
    for r in rows.values():
        r.update({k:'' for k in COORD_FIELDS})
        r['座標精度区分']='未確認'
        r['座標再確認の要否']='要' if r['公開区分'] in ('通常掲載','参考・保留') else '対象外・履歴を別管理'
    hp,matched=attach(data,rows,{r['候補キー']:r['全国統合ID'] for r in issued})
    hc=history(data)
    assert all(r['全国統合ID'] in rows for r in hc)
    classes={s:[r for r in rows.values() if r['公開区分']==s] for s in PUB}
    assert len(rows)==4728 and {k:len(v) for k,v in classes.items()}==NORMAL_TARGET
    assert set(orig)<=rows.keys() and len(set(rows)-orig.keys())==27
    assert all(r['全国統合ID']==u and r['公式住所原文'] and r['住所根拠URL'] for u,r in rows.items())
    assert all(r['公式住所原文']==r7['national'][u]['公式住所原文'] for u,r in rows.items() if u in orig)
    assert all(r['旧台帳住所']==orig[u]['住所'] for u,r in rows.items() if u in orig)
    transitions=Counter((orig[u]['掲載区分'],rows[u]['公開区分']) for u in orig if OLD_CLASS[orig[u]['掲載区分']]!=rows[u]['公開区分'])
    assert transitions=={('通常候補','参考・保留'):73,('通常候補','対象外'):4,('要確認','通常掲載'):6}
    for u,d in dup.items():
        u2=d['残すID']; assert u in rows and u2 in rows and u2 not in dup
        assert rows[u]['公開区分']=='対象外' and rows[u]['統合先ID']==u2 and rows[u2]['公開区分']=='通常掲載'
        assert d['公式URL'] and comparable(rows[u],d['公式住所']),d
    for r in classes['通常掲載']:normal_proof(r)
    assert len([r for r in classes['通常掲載'] if r['都道府県']=='兵庫県'])==177
    assert all(x['全国Ver1.2公開区分']=='通常掲載' for x in hp)
    assert all(r['基準日営業状況'] not in ('閉店','開店予定') and r['掲載適格性'] not in ('食品を取り扱わないため対象外','食品スーパー対象外') for r in classes['参考・保留'])
    assert all(not r['開店日（確認済み）'] or r['開店日（確認済み）']<=BASIS for r in classes['通常掲載'])
    pos=Counter(r['座標精度区分'] for r in rows.values());assert pos=={'P4':152,'P3':166,'未確認':4410}
    assert sum(r['緯度']!='' and r['経度']!='' for r in rows.values())==318
    assert all(not r['緯度'] and not r['経度'] for r in rows.values() if r['座標精度区分']=='未確認')
    assert all(rows[q['全国統合ID']]['座標精度区分']=='未確認' for q in issued)
    actions=review_actions(rows,approval,dup,orig)
    visual,diff,_=differences(orig,rows,previous)
    summary=aggregate(rows); trial,trial_diff=trial_review(rows,previous,issued,data)
    ev=events(data,rows)
    cases=readcsv(data/'c/cases.csv');rem=pending(rows,actions)
    source=provenance(rows)
    coords=coordinate_queue(rows)
    src_c=readcsv(data/'c/source-log.csv')
    c_hist=tab(cf/APPROVAL,'今回判断履歴')
    old_hist=tab(cf/APPROVAL,'前回まで2899履歴')
    old19=tab(oldfile,'営業例外・改称履歴')
    assert len(old_hist)==2899
    c_ind=tab(cf/'04-掲載漏れ等159キー.xlsx','159キーの最終採否案')
    id_by_candidate={r['候補キー']:r['全国統合ID'] for r in issued}
    c_index=[r|{'Ver1.2発行ID':id_by_candidate.get(r['候補キー'],'')} for r in c_ind]
    assert len(c_index)==159 and all(c['重点監査採否案']=='新規掲載' for c in c_index if c['Ver1.2発行ID'])
    by_summary=lambda *x:[r for r in summary if r['集計軸'] in x]
    canonical=list(rows.values())
    # The leading columns remain suitable for a filterable store register.
    lead=['全国統合ID','都道府県','市区町村','表示用店舗名','公式店舗名','系列分類','有効屋号','実運営法人','表示用住所',
      '公開区分','基準日営業状況','掲載適格性','緯度','経度','座標精度区分']
    fields=list(dict.fromkeys(lead+allkeys(canonical)))
    narrow=[slice_row(r,PUBLISHED_FIELDS) for r in classes['通常掲載']]
    leads_by_pref=by_summary('全国','都道府県')
    workbook=out/NAME
    important_fields=('店舗名','屋号','運営会社','住所','掲載区分','営業状態','関連全国統合ID','統合先ID')
    diff_primary=[r for r in diff if r['修正項目'] in important_fields]
    action_fields=('全国統合ID','店舗名','都道府県','修正項目','重点監査審査結果','承認候補値','重点監査根拠URL','発効日（確認済み）','Ver1.2処理','Ver1.2反映先','Ver1.2採録値','Ver1.2統合理由')
    if not tabular_only:
        w=Workbook(write_only=True);w.properties.title='全国イオン系列スーパー 全国統合マスター Ver.1.2'
        bookpart(w,'全国統合マスター',canonical,fields)
        for s in PUB:
            title='通常掲載店舗' if s=='通常掲載' else '参考・保留店舗' if s=='参考・保留' else s
            view_fields=PUBLISHED_FIELDS if s=='通常掲載' else PUBLISHED_FIELDS+('保留理由','旧掲載区分','統合先ID','公開区分理由')
            bookpart(w,title,classes[s],view_fields)
        for name,data_rows in [
         ('新規ID発行管理',issued),('重複・統合先ID管理',table),('修正候補2992の処理',actions),
         ('修正・変更履歴',diff_primary),('公式情報・証跡管理',source),('未解決事項',rem),
         ('個別案件と公開上の扱い',cases),('基準日後の事象',ev),('全国・都道府県別集計',leads_by_pref),
         ('運営会社・系列・屋号別集計',by_summary('系列','実運営法人','屋号')),
         ('系列と都道府県別集計',by_summary('系列×都道府県')),('座標調査進捗管理',coords),
         ('既往座標と比較点の履歴',hc),('兵庫県公開版との対応',hp),('調査基準・データ項目定義',defs()),
         ('候補159キーの採否とID',c_index),('段階C試算との比較',trial),('試算から変更した集計項目',trial_diff),
         ('第7回までの修正判断履歴',old_hist),('重点監査の判断履歴',c_hist)]:
            bookpart(w,name,data_rows)
        for oldname in HIDDEN_LEGACY:
            bookpart(w,'旧版_'+oldname,tab(oldfile,oldname),hidden=True)
        w.save(workbook)
        writebook(out/'Ver1.1からの差分一覧.xlsx',[('全ID差分概要',visual),('主要項目別変更',diff_primary),('表示住所整形',address_clean),
          ('修正候補の処理全件',[slice_row(r,action_fields) for r in actions]),('第2段階C試算との比較',trial),('集計屋号の差分',trial_diff)])
        writebook(out/'確定集計.xlsx',[(nm, by_summary(*groups)) for nm,groups in (
            ('全国・都道府県',('全国','都道府県')),('系列',('系列',)),('実運営法人',('実運営法人',)),('屋号',('屋号',)),('系列と都道府県',('系列×都道府県',)))])
        writebook(out/'未解決事項一覧.xlsx',[('参考・保留と修正保留等',rem),('個別継承案件',cases),('基準日後の事象',ev),
                                                ('候補の未確定', [r for r in c_index if r['重点監査採否案']=='判断保留'])])
        writebook(out/'兵庫県公開版との対応表.xlsx',[('兵庫県177店と公開176店',hp),('既往位置のID照合',[x for x in matched if x['全国統合ID'].startswith('JP-28-')])])
    writecsv(out/'通常掲載店舗.csv',narrow)
    writecsv(out/'新規IDと候補キー対応表.csv',issued)
    writecsv(out/'座標調査への引継ぎ.csv',coords)
    writecsv(out/'全国・都道府県・系列・屋号別集計.csv',summary)
    writecsv(out/'基準日後の事象.csv',ev)
    writecsv(evidence/'full-field-differences.csv',diff)
    writecsv(evidence/'coordinate-links.csv',matched)
    writecsv(evidence/'prior-coordinate-history.csv',hc)
    writecsv(evidence/'new-id-preflight.csv',new_audit)
    writecsv(evidence/'approved-corrections-2992.csv',actions)
    writecsv(evidence/'protected-inputs.csv',before)
    writecsv(evidence/'store-evidence-4728.csv',source)
    writecsv(evidence/'stage-c-acquisition-log.csv',src_c)
    writecsv(evidence/'stage-c-v12-comparison.csv',trial)
    writecsv(evidence/'stage-c-brand-deltas.csv',trial_diff)
    writecsv(evidence/'address-display-edits.csv',address_clean)
    writecsv(evidence/'listing-category-history.csv',old19)
    writecsv(evidence/'national-master-4728.csv',canonical,fields)
    assert start==sha256(oldfile) and before==protect_files(data)
    quality={
      '台帳基準日':BASIS,'台帳版':VERSION,'Ver1.1内部ワークブックSHA-256':start,'保護元ZIP':before,
      '既存ID保持':len(orig),'作成後行数':len(rows),'正式新規ID':len(issued),'ID空欄':0,'ID重複':0,'発番対象の同一店舗再登録':0,
      '公開区分実績':{k:len(v) for k,v in classes.items()},
      '既存区分変更':[{'Ver1.1':a,'Ver1.2':b,'行数':v} for (a,b),v in sorted(transitions.items())],
      '統合先ID存在確認':len(dup),'住所原文引継ぎ':len(orig),'公式住所原文全行':len(rows),
      '表示欄で連続県名を修正':[r['全国統合ID'] for r in address_clean if r['府県名の重複修正']],
      '基準日住所を未採録':sum(not r['基準日時点の住所'] for r in canonical),
      '通常掲載の営業・食品・住所根拠':len(classes['通常掲載']),
      '修正2992キーの処理':dict(Counter(r['Ver1.2処理'] for r in actions)),
      '座標区分':dict(pos),'既存座標の継承':len(matched),
      '既往座標履歴保持':len(hc),'兵庫県公開との突合':176,'兵庫県通常掲載':177,'大阪府座標継承':142,
      '基準日後事象':len(ev),'第2段階Cとの公開件数差':sum(abs(r['差']) for r in trial),
      '第2段階Cとの屋号集計変更ID':len(trial_diff),'承認の根拠付き変更履歴':len(c_hist),
      '旧管理キー履歴保持':len(old_hist),'実運営法人未確定':sum(not r['実運営法人'] for r in canonical),
      '集計用屋号未記録':sum(not r['有効屋号'] for r in canonical),
      '基準日住所の未採録行':[{k:r[k] for k in ('全国統合ID','表示用店舗名','公開区分','住所に関する保留事項')} for r in canonical if not r['基準日時点の住所']]}
    if not tabular_only:
        inspect_book(workbook,rows,classes,fields,summary,source,narrow,matched)
    quality['Excelの再読込・派生表照合']='検証済み' if not tabular_only else 'CSV再計算モード'
    for dest in (out/'品質検証.json',evidence/'quality.json'):
        dest.write_text(json.dumps(quality,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print({k:v for k,v in quality.items() if len(str(v))<500})

def inspect_book(path,rows,classes,fields,summary,source,narrow,matched):
    w=load_workbook(path,read_only=True,data_only=True)
    expectations={'全国統合マスター':list(rows.values()),'通常掲載店舗':classes['通常掲載'],'参考・保留店舗':classes['参考・保留'],
      '履歴・休業・予定':classes['履歴・休業・予定'],'対象外':classes['対象外'],'公式情報・証跡管理':source,
      '全国・都道府県別集計':[r for r in summary if r['集計軸'] in ('全国','都道府県')],
      '運営会社・系列・屋号別集計':[r for r in summary if r['集計軸'] in ('系列','実運営法人','屋号')]}
    for name,expected in expectations.items():
        it=iter(w[name].values);header=next(it)
        outcome=0
        for values,row in zip(it,expected,strict=True):
            outcome+=1
            for k,v in zip(header,values):
                assert ('' if v is None else v)==row.get(k,''),(name,outcome,k,v,row.get(k,''))
        assert outcome==len(expected)
    coords=w['座標調査進捗管理']
    assert sum(1 for _ in coords.values)==4729
    assert sum(1 for _ in w['新規ID発行管理'].values)==28
    assert sum(1 for _ in w['修正候補2992の処理'].values)==2993
    w.close()
    data=readcsv(path.parent/'通常掲載店舗.csv')
    assert len(data)==len(narrow)==4614 and all(a['全国統合ID']==b['全国統合ID'] for a,b in zip(data,narrow))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ('data','out','evidence'):p.add_argument(name,type=Path)
    p.add_argument('--tabular-only',action='store_true')
    a=p.parse_args();build(a.data,a.out,a.evidence,a.tabular_only)
