"""Create the Ver.1.2 register from the approved Phase C state and archived sources."""
import re,hashlib
from collections import Counter,defaultdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.parse import urlsplit
from util import *

BASEFILE='aeon-national-master-phase2c-v1.1-20261123.xlsx'
CANDIDATES='03-新規掲載と重複整理.xlsx'
APPROVAL='05-修正候補の承認審査.xlsx'
AUTH='07-Ver1.2最終試算.xlsx'
GOOD_FOOD={'食品スーパー業態として確認','総合スーパーの食品売場確認'}
ACTIVE_OP='営業中（公式一覧基準）'
HELD={'根拠不足による未確認','専門業態・一般利用条件等による判断保留'}
APPROVED={'公式根拠により反映推奨','運営会社・系列・屋号の変更','営業状況・掲載区分の変更','公式住所原文の採録','重複整理'}
NORMAL_TARGET={'通常掲載':4614,'参考・保留':75,'対象外':25,'履歴・休業・予定':14}
OLD_CLASS={'通常候補':'通常掲載','条件付き':'参考・保留','要確認':'参考・保留','除外':'対象外','履歴・休業・予定':'履歴・休業・予定'}
LEGAL_DOMAINS={
 'mybasket.co.jp':('まいばすけっと','まいばすけっと株式会社'),
 'biga.co.jp':('ビッグ・エー','株式会社ビッグ・エー'),
 'maruetsu.co.jp':('マルエツ','株式会社マルエツ'),
 'kasumi.co.jp':('カスミ','株式会社カスミ'),
 'inageya.co.jp':('いなげや','株式会社いなげや'),
 'aeonfoodstyle.com':('ダイエー・イオンフードスタイル','株式会社イオンフードスタイル'),
 'daiei.co.jp':('ダイエー・イオンフードスタイル','株式会社ダイエー'),
 'mv-tokai.co.jp':('マックスバリュ東海','マックスバリュ東海株式会社'),
 'mv-hokuriku.co.jp':('マックスバリュ北陸','マックスバリュ北陸株式会社'),
 'aeonretail.jp':('イオンリテール','イオンリテール株式会社'),
 'aeonretail.com':('イオンリテール','イオンリテール株式会社'),
 'aeonbig.co.jp':('イオンビッグ','イオンビッグ株式会社'),
 'aeon-hokkaido.jp':('イオン北海道','イオン北海道株式会社'),
 'aeontohoku.co.jp':('イオン東北','イオン東北株式会社'),
 'aeon-kyushu.info':('イオン九州','イオン九州株式会社'),
 'aeon-ryukyu.jp':('イオン琉球','イオン琉球株式会社'),
 'the-fuji.com':('フジ','株式会社フジ'),
 'tokiwa-industry.co.jp':('トキハインダストリー','株式会社トキハインダストリー'),
}
ALT_BRANDS={'AE-4A5DB471A19B88BE':'ザ・ビッグ','AE-7FDAE0B87CE2603A':'COCOSA B1'}
FIXED_ADDRESS={'AE-08B8757C739CA987':'公式フロアガイド・公式営業時間案内・公式ネットスーパーで同一店の相楽台1丁目1番1を確認。欠けていた丁目の数字を採用。'}
TRANSLATED={'AE-80B96CB0D9095A4C':('Yanagimachi','苫小牧市柳町'), 'AE-4E426E90B109666A':('Tokuda','名寄市徳田'), 'AE-D67CA2CDDE2B0229':('Midorimachi','旭川市緑町')}

def load_state(data):
    oldf=data/'v11'/BASEFILE
    previous=tab(oldf,'統合マスター')+tab(oldf,'除外・履歴・保留')
    old=one(previous)
    assert len(old)==4701 and sha256(oldf)==json.loads((data/'v11/validation.json').read_text())['改訂Workbook_SHA256']
    c=data/'c-results'
    current=one(tab(c/AUTH,'既存4701行の公開区分案'))
    r7={name:one(readcsv(data/'r7'/f'{name}-4701.csv')) for name in ('national','operation','eligibility')}
    c_axes={name:one(readcsv(data/'c'/f'{name}-audit.csv')) for name in ('operation','eligibility')}
    assert all(set(x)==set(old) for x in (current,*r7.values()))
    proposals=tab(c/APPROVAL,'全管理キーの承認候補')
    original_c=readcsv(data/'c/correction-approval.csv')
    assert [(r['全国統合ID'],r['修正項目'],r['重点監査審査結果'],r['承認候補値']) for r in proposals]==[(r['全国統合ID'],r['修正項目'],r['重点監査審査結果'],r['承認候補値']) for r in original_c]
    options=defaultdict(dict)
    for r in proposals:
        uid,e=r['全国統合ID'],r['修正項目'];assert e not in options[uid]
        options[uid][e]=r
    assert len(proposals)==2992 and sum(r['重点監査審査結果']=='判断保留' for r in proposals)==46
    return old,current,r7,c_axes,proposals,options

def canon_company(s):
    return re.sub(r'株式会社|合同会社|有限会社|[\s・()]','',nf(s or ''))
def compare_company(u,series):
    host=(urlsplit(u).hostname or '').removeprefix('www.')
    for domain,(op,name) in LEGAL_DOMAINS.items():
        if (host==domain or host.endswith('.'+domain)) and series==op:
            return name
    return ''

def actual_company(row,r7,pending):
    current=row['運営会社']
    official=r7['公式運営会社']
    addr_url=row['住所根拠URL']
    conditional='要個別確認' in current or '要確認' in current
    if current and ('株式会社' in current or '合同会社' in current) and not conditional:
        if official and compare_company(addr_url,row['系列分類']) and canon_company(current)!=canon_company(official) and pending:
            return '',addr_url,'旧法人と公式資料の法人差。承認保留のため実運営法人は未確定。'
        return current,addr_url if canon_company(official)==canon_company(current) else '', '承認済み法人または既存台帳の法人表示'
    if pending and current:
        return '',addr_url,'法人帰属の判断保留'
    if official and any(s in official for s in ('株式会社','合同会社')) and (not current or canon_company(current)==canon_company(official) or conditional):
        return official,addr_url,'第7回の運営会社確認欄'
    keys=[u for u in (addr_url,row['公式店舗URL'],row['営業判定根拠URL']) if u]
    companies=list(dict.fromkeys((c,u) for u in keys if (c:=compare_company(u,row['系列分類']))))
    unique={c for c,u in companies}
    if len(unique)==1 and (not current or canon_company(current) in {canon_company(c) for c in unique}):
        return companies[0][0],companies[0][1],'同一店の運営会社公式ドメイン'
    return '','','実運営法人の同定資料が不足。既存の系列分類を保持。'

def address_fields(r,a,approved,cases):
    pref=r['都道府県'];city=r['市区町村'];uid=r['全国統合ID'];old=r['旧台帳住所'];raw=a['公式住所原文']
    display=clean_address(old,pref,city)
    status=a['住所照合結果']
    equivalent=status.startswith(('一致','原文一致','表記')) or compare_input(r,raw) in EQ
    note=''
    if equivalent:
        # An equivalent old address remains the display address unless it contains obvious syntax damage.
        at_basis=clean_address(raw,pref,city); relation='同一の所在地（公式原文と旧表記を保持）'
        if r['公開区分']=='履歴・休業・予定' and '開店予定' in r['営業状態']:
            at_basis='';note='基準日時点は開店予定。予定所在地は公式住所原文欄で管理。'
    elif uid in FIXED_ADDRESS:
        at_basis=clean_address(raw,pref,city);display=at_basis
        relation='旧表記の欠落を公式資料で補正';note=FIXED_ADDRESS[uid]
    elif uid in TRANSLATED and TRANSLATED[uid][0] in old and TRANSLATED[uid][1] in raw:
        at_basis=clean_address(raw,pref,city);display=at_basis;relation='施設の英日表記対応（既往の施設照合）'
    else:
        at_basis='';display=clean_address(raw,pref,city) or display
        relation='旧番地・住号・発効日等の対応を保留'
        note='公式原文を採録。表示欄は公式の掲載住所。基準日の住所・旧住所との直接対応は未確定。'
    if approved and approved.get('重点監査審査結果')=='公式住所原文の採録' and approved.get('承認候補値')!=raw:
        raise ValueError((uid,'Address approval differs from source raw'))
    lookup=cases.get(uid,{})
    cn=lookup.get('今回の確認と残る理由','')
    if not equivalent and cn:note=' ／ '.join(filter(None,(note,cn)))
    return {'公式住所原文':raw,'公式住所（掲載表記）':raw,'基準日時点の住所':at_basis,'表示用住所':display,
            '旧住所との関係':relation,'住所照合結果（継承）':status,'住所に関する保留事項':note,
            '住所根拠URL':a['住所証跡URL'],'住所確認根拠URL':a['住所証跡URL'],'住所確認資料種別':a['住所確認資料種別'],
            '公式資料取得日時UTC':a['取得日時UTC'],'住所確認日時UTC':a['取得日時UTC'],'住所応答SHA-256':a['住所応答SHA256'],
            '住所証跡採録段階':a['確認段階']}

def food_equiv(v):
    return {'食品売場・食品の根拠あり':'総合スーパーの食品売場確認','公式の食品スーパー屋号':'食品スーパー業態として確認'}.get(v,v)

def case_by_id(data):
    rs=readcsv(data/'c/cases.csv')
    return {r['全国統合ID']:r for r in rs if r['全国統合ID']}
def jst(s):
    if not s:return ''
    try:return datetime.fromisoformat(s).astimezone(timezone(timedelta(hours=9))).date().isoformat()
    except ValueError:return ''
def normalize_brand(r,c):
    # Stage C explicitly recognized the independent COCOSA and Big brands for final grouping.
    if r['全国統合ID'] in ALT_BRANDS:return ALT_BRANDS[r['全国統合ID']]
    if r['屋号'] or c['屋号']:return r['屋号'] or c['屋号']
    names=(r['公式店舗名'],r['表示用店舗名'])
    for label in ('ファミリーマートプラス','FOOD OFFストッカー','マックスバリュエクスプレス','マックスバリュ',
                  'イオンスタイル','イオン','まいばすけっと','マルエツ','ザ・ビッグエクストラ','ザ・ビッグ','ビッグ・エー','アコレ'):
        if r['住所根拠URL'] and any(nf(n).startswith(label) for n in names):return label
    return ''
def approved_value(d,field,default):
    q=d.get(field,{})
    return q['承認候補値'] if q.get('重点監査審査結果') in APPROVED and q['承認候補値'] else default

def make_existing(old,current,r7,axes,options,cases,dupes):
    built={};address_clean=[]
    for uid,o in old.items():
        v=current[uid];a=r7['national'][uid];op=r7['operation'][uid];food=r7['eligibility'][uid]; ap=options[uid]
        ax=axes['operation'].get(uid,{})
        fx=axes['eligibility'].get(uid,{})
        sharp=ap.get('運営会社',{}).get('重点監査審査結果')=='判断保留'
        assert (o['都道府県'],o['店舗名'],o['住所'])==(v['都道府県'],v['店舗名'],a['台帳住所'])
        assert a['公式住所原文']==v['公式住所原文'] and v['基準日']==BASIS
        assert o['掲載区分']==v['現行掲載区分']
        live=v['Ver1.2承認候補区分']
        public='履歴・休業・予定' if live=='履歴' else live
        official=a['公式店舗名'] or o['現行公式名'] or ''
        display=approved_value(ap,'店舗名',o['店舗名'])
        if ap.get('店舗名',{}).get('重点監査審査結果') in APPROVED:official=display
        effective_operator=approved_value(ap,'運営会社',o['運営会社'])
        brand=approved_value(ap,'屋号',o['屋号'])
        # For withheld fields the legacy store values stay in the legacy columns.
        rr=o|{'店舗名':display,'屋号':brand,'運営会社':effective_operator,'全国統合ID':uid,'台帳版':VERSION,
             '旧掲載区分':o['掲載区分'],'掲載区分':public,'公開区分':public,'掲載区分根拠':v['公開区分根拠URL'],
             '公開区分理由':v['公開区分の理由'],'系列分類':v['系列'],'現行公式名':official,'公式店舗名':official,
             '表示用店舗名':display,'旧店舗名':o['店舗名'],'旧屋号':o['屋号'],'旧運営会社':o['運営会社'],
             '旧台帳住所':o['住所'],'営業状態':v['重点監査営業判定'],'基準日営業状況':v['重点監査営業判定'],
             '旧営業判定':o['営業状態'],'第7回営業判定':v['第7回営業判定'],'営業判定根拠URL':v['営業根拠URL'],
             '営業確認日時UTC':ax.get('取得日時UTC') or (op['営業根拠取得日時UTC'] if op['営業根拠URL']==v['営業根拠URL'] else ''),
             '営業応答SHA-256':ax.get('根拠SHA256') or (o['営業応答SHA-256'] if o['営業判定根拠URL']==v['営業根拠URL'] else ''),
             '営業判定根拠説明':ax.get('監査理由') or op['判定根拠・未確認理由'],
             '掲載適格性':v['重点監査掲載適格性'],'第7回掲載適格性':v['第7回掲載適格性'],
             '掲載適格性根拠URL':v['掲載適格性根拠URL'],'掲載適格性資料取得日時UTC':fx.get('取得日時UTC') or (food['取得日時UTC'] if food['根拠URL']==v['掲載適格性根拠URL'] else ''),
             '掲載適格性根拠説明':fx.get('監査理由') or food['根拠または未確認理由'],
             '掲載適格性補足資料URL':food['補足資料URL'],'統合先ID':v['統合先ID'],
             '関連全国統合ID':v['統合先ID'] or o['関連全国統合ID'],
             '確認済み運営会社':a['公式運営会社'] or o['確認済み運営会社'],'全国調査基準日':BASIS,
             '候補キー':'','ID来歴':'Ver.1.1継承','開店日（確認済み）':'','公式住所確認':'確認済み'}
        if rr['営業確認日時UTC']:
            rr['営業確認日']=jst(rr['営業確認日時UTC']) or rr['営業確認日']
        rr.update(address_fields(rr,a,ap.get('住所'),cases))
        rr['正規化住所']=normalize(rr['表示用住所'])
        rr['現行公式名確認日JST']=jst(a['取得日時UTC']) or o['現行公式名確認日JST']
        # Preserve the listing URL column and expose a usable official link from the evidence for all rows.
        rr['旧公式店舗URL']=o['公式店舗URL']
        if not rr['公式店舗URL']:
            urls=[u for u in (a['住所証跡URL'],v['営業根拠URL']) if u and ' ／ ' not in u
                  and (compare_company(u,rr['系列分類']) or (urlsplit(u).hostname or '').removeprefix('www.')=='aeon.com')]
            if urls:rr['公式店舗URL']=next((u for u in urls if is_branch_url(u)),urls[0])
        rr['公式URL種別']='運営会社等の個店' if is_branch_url(rr['公式店舗URL']) else '公式一覧・補足資料' if rr['公式店舗URL'] else '個店URL未採録（根拠URL欄を参照）'
        legal,lu,ln=actual_company(rr,a,sharp)
        rr.update({'実運営法人':legal,'運営法人根拠URL':ap.get('運営会社',{}).get('重点監査根拠URL','') if effective_operator!=o['運営会社'] else lu,
                   '運営法人確認状態':ln,'有効屋号':normalize_brand(rr,v),
                   '屋号の根拠・由来':('承認候補' if brand!=o['屋号'] else '重点監査の公開区分試算に用いた屋号') if v['屋号'] else '現行の屋号表示',
                   '要追加確認':'対象外・履歴の証跡を維持' if public not in ('通常掲載','参考・保留') else ('通常掲載判定の根拠あり' if public=='通常掲載' else v['公開区分の理由'])})
        if not brand and not v['屋号'] and rr['有効屋号']:
            rr['屋号の根拠・由来']='同一店舗の表記に明示された屋号。旧台帳の屋号欄は保持。'
        if public=='参考・保留':
            rr['保留理由']=cases.get(uid,{}).get('今回の確認と残る理由') or ' ／ '.join(dict.fromkeys(q for q in (v['公開区分の理由'],fx.get('監査理由'),ax.get('監査理由')) if q and q!='台帳掲載区分を継承。')) or '条件付き掲載・業態の確認事項を継承。'
            if rr['掲載適格性'] in HELD:rr['次工程']='食品売場・業態・一般利用条件を資料で確認'
        if uid in dupes:rr['施設・核店舗区分']=dupes[uid]['整理種別']+'・統合元'
        elif uid in {p['残すID'] for p in dupes.values()}:rr['施設・核店舗区分']='重複・施設対応の掲載側'
        elif public=='対象外' and re.search(r'ショッピングセンター|モール|専門店街',o['店舗名']):rr['施設・核店舗区分']='施設行'
        else:rr['施設・核店舗区分']='店舗／台帳で採録した単位'
        pref=rr['都道府県'];after=rr['表示用住所'];bef=old[uid]['住所']
        repetition=pref*2 in re.sub(r'\s','',str(bef or ''))
        if repetition:assert pref*2 not in re.sub(r'\s','',after)
        raw=a['公式住所原文']
        cp=clean_address(raw,rr['都道府県'],rr['市区町村'])
        if cp!=raw or after!=bef:
            address_clean.append({'全国統合ID':uid,'店舗名':display,'旧台帳住所':bef,'公式住所原文':raw,'表示用住所':after,
                 '基準日時点の住所':rr['基準日時点の住所'],'府県名の重複修正':repetition,
                 '理由':rr['住所に関する保留事項'] or '府県名重複、郵便表記または余分な空白の整形。'})
        built[uid]=rr
    return built,address_clean

def namealias(n,series):
    t=common_name(n)
    if series=='カスミ':t=re.sub(r'^フードスクエア(?:カスミ)?|^カスミ|^フードマーケット','',t)
    if series=='ダイエー・イオンフードスタイル':t=re.sub(r'^(?:ダイエー|イオンフードスタイル|グルメシティ)','',t)
    return t

def flag_duplicates(existing,candidates,prior_names):
    idx_a=defaultdict(set);idx_n=defaultdict(set);idx_u=defaultdict(set)
    rows=dict(existing); audits=[]; allocated=[]
    def add(uid,row,nms=()):
        pref=row['都道府県'];seq=row['系列分類'];city=row['市区町村']
        for a in (row['旧台帳住所'],row['基準日時点の住所'],row['公式住所原文'],row['表示用住所']):
            k=address_key(a,pref,city)
            if k:idx_a[pref,k].add(uid)
        for n in (row['旧店舗名'],row['表示用店舗名'],row['公式店舗名'],*nms):
            if n:
                idx_n[pref,common_name(n)].add(uid)
                idx_n[pref,seq,namealias(n,seq)].add(uid)
        for u in (row['公式店舗URL'],row.get('旧公式店舗URL',''),row['住所根拠URL']):
            if is_branch_url(u):idx_u[url_key(u)].add(uid)
    for uid,r in rows.items():add(uid,r,prior_names.get(uid,()))
    for c in sorted(candidates,key=lambda x:x['候補キー']):
        uid='AE-'+hashlib.sha256(f"KUSSOON|PHASE2D|{c['候補キー']}".encode()).hexdigest()[:16].upper()
        assert uid not in rows,c
        n,seq,p=c['公式店舗名'],c['系列'],c['都道府県']
        city=municipality(c['公式住所'],p)
        assert city,(c,p)
        branch=is_branch_url(c['公式URL']); ka=address_key(c['公式住所'],p,city)
        names=idx_n[p,common_name(n)]|idx_n[p,seq,namealias(n,seq)]
        addr=idx_a[p,ka]
        urls=idx_u[url_key(c['公式URL'])] if branch else set()
        # A common address alone is a risk to review. It never automatically assigns an ID.
        match=names|addr|urls
        decision='既存・先行採用候補の同一店舗なし。'
        if match:
            raise ValueError((c['候補キー'],n,[(i,rows[i]['店舗名'],i in names,i in addr,i in urls) for i in sorted(match)]))
        date=c['開店日既知']
        assert not date or date<=BASIS
        assert c['採否案']=='採用推奨' and c['基準日時点営業']==ACTIVE_OP and c['食品適格性'] in GOOD_FOOD
        source=c['公式URL'];opref=c['営業・食品補足URL'] or source
        value=c['公式住所'];ad=clean_address(value,p,city)
        indexed=seq=='イオンリテール'
        stamp,sha=(c['取得日時UTC'],c['根拠SHA256']) if not indexed else ('','')
        row={'全国統合ID':uid,'台帳版':VERSION,'都道府県':p,'市区町村':city,'候補キー':c['候補キー'],
             '店舗名':n,'表示用店舗名':n,'公式店舗名':n,'現行公式名':n,'現行公式名確認日JST':c['確認日JST'],
             '旧店舗名':'','屋号':c['屋号'],'有効屋号':c['屋号'],'屋号の根拠・由来':c['出典区分'],
             '旧屋号':'','運営会社':c['運営会社'],'実運営法人':c['運営会社'],'確認済み運営会社':c['運営会社'],'運営法人根拠URL':source,
             '運営法人確認状態':'第2段階Cで承認候補となった運営会社','旧運営会社':'','グループ系列':seq,'系列分類':seq,
             '住所':ad,'旧台帳住所':'','公式住所原文':value,'公式住所（掲載表記）':value,'基準日時点の住所':ad,'表示用住所':ad,
             '正規化住所':normalize(ad),'旧住所との関係':'新規採用。旧台帳の対応なし。',
             '公式住所確認':'確認済み','住所確認資料種別':'公式個店の公開索引・公式地域一覧を補足' if indexed else ('第2段階C・公式個店等' if branch else '運営会社公式一覧'),
             '住所根拠URL':source,'住所確認根拠URL':source,
             '公式資料取得日時UTC':stamp,'住所確認日時UTC':stamp,'住所応答SHA-256':sha,
             '住所同定補足URL':opref if indexed else '', '住所同定補足取得日時UTC':c['取得日時UTC'] if indexed else '', '住所同定補足SHA256':c['根拠SHA256'] if indexed else '',
             '住所証跡採録段階':'第2段階C','公式店舗URL':source,'公式URL種別':'運営会社等の個店' if branch else '運営会社公式共用一覧',
             '情報出典':'第2段階C・新規掲載承認候補','掲載区分':'通常掲載','公開区分':'通常掲載','掲載区分根拠':opref,
             '公開区分理由':c['根拠・既存照合メモ'],'基準日営業状況':ACTIVE_OP,'営業状態':ACTIVE_OP,
             '営業判定根拠URL':opref,'営業判定根拠説明':c['根拠・既存照合メモ'],'営業確認日':c['確認日JST'],
             '掲載適格性':c['食品適格性'],'掲載適格性根拠URL':opref,'掲載適格性補足資料URL':source,
             '掲載適格性根拠説明':'第2段階Cで店舗固有の食品売場または運営会社の食品スーパー業態を確認。',
             '開店日（確認済み）':date,'全国調査基準日':BASIS,'原資料基準日':BASIS,'確認日':c['確認日JST'],
             'ID来歴':'Ver.1.2正式発行','統合先ID':'','施設・核店舗区分':'食品スーパー（個店または施設の食品核店舗）'}
        rows[uid]=row;add(uid,row)
        allocated.append({'候補キー':c['候補キー'],'全国統合ID':uid,'店舗名':n,'都道府県':p,'系列':seq,'運営会社':c['運営会社'],
            '公式住所原文':value,'公式店舗URL':source,'掲載根拠URL':opref,'発番日JST':'2026-11-24','出典区分':c['出典区分']})
        audits.append({'候補キー':c['候補キー'],'全国統合ID':uid,'都道府県':p,'店舗名':n,'照合対象':'既存4701行と先行発番済み候補。旧名と公式名、住所、個店URL。',
            '住所候補数':len(addr),'名称・別名候補数':len(names),'個店URL候補数':len(urls),
            '一覧URLは共用':not branch,'照合結果':decision})
    return rows,allocated,audits

def municipality(a,pref):
    local=a.removeprefix(pref)
    if pref=='東京都':
        m=re.match(r'^\S{1,8}?区',local)
        if m:return m[0]
    m=re.match(r'^.{1,8}?郡(.{1,8}?[町村])',local)
    if m:return m[1]
    m=re.match(r'^.{1,8}?市(?:.{1,7}?区)?',local)
    if m:return m[0]
    return ''
