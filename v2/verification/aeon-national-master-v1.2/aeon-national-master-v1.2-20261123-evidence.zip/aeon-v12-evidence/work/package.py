"""Pack the results separately, with independently extractable evidence archives."""
import hashlib,argparse
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from zlib import compress
from assembly import BASEFILE,APPROVAL,CANDIDATES,AUTH
from util import sha256

def collect(root):
    d=root/'data';w=root/'work';e=root/'evidence'
    selections={
      'v11':(BASEFILE,'validation.json'),
      'r7':('national-4701.csv','operation-4701.csv','eligibility-4701.csv'),
      'c':('operation-audit.csv','eligibility-audit.csv','correction-approval.csv','cases.csv','post-baseline.csv','source-log.csv','store-counts.csv'),
      'c-results':(APPROVAL,CANDIDATES,AUTH,'04-掲載漏れ等159キー.xlsx','Ver1.2制作手順書.md'),
    }
    src=[]
    for folder,files in selections.items():
        src.extend(d/folder/n for n in files)
    src.extend(d/n for n in ('coord-sources.tsv','original-archives.sha256','hyogo-public-live.html',
       'OFFICIAL-POSITION-REVIEW-20261123.md','FOLLOWUP-20261122.md','FLOORPLAN-REVIEW-3-20261122.md','UNRESOLVED.md'))
    src.extend(d/line.split('\t')[0] for line in (d/'coord-sources.tsv').read_text().splitlines())
    code=[w/n for n in ('publish.py','reports.py','assembly.py','coord.py','util.py','package.py')]+list((w/'vendor').glob('*.py'))
    evidence=[p for p in sorted(e.iterdir()) if p.is_file()]
    collection=[(str(p.relative_to(root)),p.read_bytes()) for p in sorted(set(src+code+evidence))]
    hashes=''.join(f'{sha256(p)}  {p.relative_to(root)}\n' for p in sorted(set(src+code)))
    collection.append(('sources-sha256.txt',hashes.encode()))
    notes=(root/'out/再生成・更新手順書.md').read_bytes()
    collection.append(('再生成・更新手順書.md',notes))
    return collection

def pack(root):
    out,rel=root/'out',root/'release'
    rel.mkdir(exist_ok=True)
    stem='aeon-national-master-v1.2-20261123'
    results=rel/(stem+'-results.zip')
    with ZipFile(results,'w',ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(out.iterdir()):
            if p.is_file():z.write(p,p.name)
    groups=[]
    for n,content in sorted(collect(root),key=lambda x:(-len(compress(x[1],6)),x[0])):
        zname='aeon-v12-evidence/'+n
        count=len(compress(content,6))+2*len(zname.encode())+180
        assigned=next((i for i,(size,_) in enumerate(groups) if size+count<9_850_000),None)
        if assigned is None:assigned=len(groups);groups.append((0,[]))
        size,entries=groups[assigned];entries.append((zname,content));groups[assigned]=(size+count,entries)
    archives=[results]
    for i,(size,part) in enumerate(groups,1):
        suffix=f'-part{i}' if len(groups)>1 else ''
        dest=rel/(stem+'-evidence'+suffix+'.zip')
        with ZipFile(dest,'w',ZIP_DEFLATED,compresslevel=6) as z:
            for n,b in sorted(part):z.writestr(n,b)
            z.writestr(f'aeon-v12-evidence/証跡ZIP{i}-内容.txt',f'{i}/{len(groups)}\nすべての証跡ZIPを同一フォルダへ展開します。\n'+'\n'.join(n for n,b in sorted(part)))
        assert dest.stat().st_size<10_000_000
        archives.append(dest)
    for p in archives:
        with ZipFile(p) as z:assert z.testzip() is None
        print(p.name,p.stat().st_size,sha256(p))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);pack(p.parse_args().root)
