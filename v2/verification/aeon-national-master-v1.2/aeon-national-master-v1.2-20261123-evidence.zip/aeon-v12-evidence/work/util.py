"""Shared data readers, address comparisons and workbook/export formatting."""
import csv,hashlib,re,unicodedata,json
from collections import defaultdict
from pathlib import Path
from urllib.parse import urlsplit,unquote,parse_qs
from openpyxl import load_workbook,Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter
from address_cases import address_check
from compare import normalize,nf

BASIS='2026-11-23'
VERSION='Ver.1.2'
PUB=('通常掲載','参考・保留','対象外','履歴・休業・予定')
EQ={'一致','表記のみ相違'}
PREFS='北海道 青森県 岩手県 宮城県 秋田県 山形県 福島県 茨城県 栃木県 群馬県 埼玉県 千葉県 東京都 神奈川県 新潟県 富山県 石川県 福井県 山梨県 長野県 岐阜県 静岡県 愛知県 三重県 滋賀県 京都府 大阪府 兵庫県 奈良県 和歌山県 鳥取県 島根県 岡山県 広島県 山口県 徳島県 香川県 愛媛県 高知県 福岡県 佐賀県 長崎県 熊本県 大分県 宮崎県 鹿児島県 沖縄県'.split()
def sha256(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def readcsv(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def one(rows,k='全国統合ID'):
    data={r[k]:r for r in rows};assert len(data)==len(rows) and all(data)
    return data
def tab(path,title):
    w=load_workbook(path,read_only=True,data_only=False)
    it=iter(w[title].values);h=next(it)
    rows=[{k:(v if v is not None else '') for k,v in zip(h,row)} for row in it]
    w.close();return rows
def common_name(s):
    s=nf(str(s or '')).casefold()
    s=re.sub(r'\s+|[・･,。]','',s)
    return re.sub(r'\([^)]*(?:内|階|旧|閉店)[^)]*\)$','',s).removesuffix('店').replace('ヶ','ケ').replace('λ','a')
def url_key(u):
    if not u:return ''
    b=urlsplit(u)
    p=unquote(b.path).rstrip('/')
    p=re.sub(r'/(?:flyer|shop_info(?:/(?:hours|map|service|floor_guide))?)$','',p)
    h=(b.hostname or '').removeprefix('www.')
    if h=='tenpo.aeon-kyushu.info':
        p=re.sub(r'^/(?:aeon|big|maxvalu)(?=/detail/)','',p)
    if h=='stores.inageya.co.jp':p+='?s='+parse_qs(b.query).get('s',[''])[0]
    return h+p
def is_branch_url(u):
    k=url_key(u)
    return bool(k and ('/detail/' in k or '/stores/' in k or '/tenpotop/' in k or '/shop/' in k or '/store/イオン/' in k or '?s=' in k)
                and not k.endswith(('/stores','/shop','/store')) and '/tenpotop/area/' not in k and '/store/list/' not in k)
def clean_address(s,pref,city=''):
    t=re.sub(r'[\s\u3000]+',' ',str(s or '')).strip()
    t=re.sub(r'^〒?\s*[0-9０-９]{3}[-－−][0-9０-９]{4}\s*(?='+re.escape(pref)+')','',t)
    if t.startswith(pref):
        t=re.sub('^(?:'+re.escape(pref)+r'\s*){2,}',pref,t)
        if city and nf(city)!=pref:
            t=re.sub('^'+re.escape(pref)+r'\s*(?:'+re.escape(city)+r'\s*){2,}',pref+city,t)
    return t
def compare_input(row,addr):
    pref=row['都道府県']; city=row.get('市区町村','')
    return address_check({'住所':clean_address(row['住所'],pref,city),'都道府県':pref,'全国統合ID':row['全国統合ID'],
       '系列分類':row['系列分類']},clean_address(addr,pref,city))
def comparable(row,adr):
    if not adr:return False
    return any(compare_input(row|{'住所':row.get(k,'')},adr) in EQ for k in ('住所','旧台帳住所','公式住所原文','表示用住所') if row.get(k))
def address_key(s,pref,city=''):
    if not s:return ''
    k=normalize(clean_address(s,pref,city))
    k=re.sub(r'(?<=[市区町村])大字','',k)
    k=re.split(r'\(|[A-Za-z]{3,}|(?<=\d)(?:イオン|ビル|ショッピング|モール)',k,1)[0]
    return k.removesuffix('番')
def safe(x):
    if isinstance(x,str) and len(x)>32767:raise ValueError('Excel field exceeds maximum length')
    return x
def allkeys(items):
    return list(dict.fromkeys(k for r in items for k in r))
def writecsv(path,rows,fields=None):
    fields=fields or allkeys(rows)
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for row in rows:
            clean={k:("'"+v if isinstance(v,str) and v.startswith(('=','+','-','@','\t','\r')) else v) for k,v in row.items()}
            w.writerow(clean)
def bookpart(book,title,rows,fields=None,hidden=False):
    s=book.create_sheet(title);fields=fields or allkeys(rows) or ['状態']
    s.freeze_panes='D2'
    s.auto_filter.ref=f'A1:{get_column_letter(len(fields))}{len(rows)+1}'
    if hidden:s.sheet_state='hidden'
    for j,k in enumerate(fields,1):
        s.column_dimensions[get_column_letter(j)].width= min(64,max(14,len(k)*1.6+4,40 if any(p in k for p in ('URL','住所','備考','根拠','理由')) else 22 if '店舗名' in k else 0))
    header=[]
    for k in fields:
        c=WriteOnlyCell(s,value=k);c.font=Font(name='Yu Gothic',bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='28544B');header.append(c)
    s.append(header)
    for row in rows:
        values=[]
        for k in fields:
            v=safe(row.get(k,''))
            if isinstance(v,str) and v.startswith('='):
                c=WriteOnlyCell(s,value=v);c.data_type='s';values.append(c)
            elif k in ('緯度','経度','公開版緯度','公開版経度') and isinstance(v,(int,float)):
                c=WriteOnlyCell(s,value=v);c.number_format='0.00000000';values.append(c)
            else:values.append(v)
        s.append(values)
    return s
def writebook(path,parts):
    w=Workbook(write_only=True)
    for title,rows in parts:bookpart(w,title,rows)
    w.save(path)
