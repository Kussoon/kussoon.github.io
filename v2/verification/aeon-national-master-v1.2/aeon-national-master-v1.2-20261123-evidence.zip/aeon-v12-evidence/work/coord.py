"""Bring forward published and archived coordinates without acquiring new points."""
import json,re
from collections import Counter
from lxml import html
from util import readcsv, common_name, comparable, url_key, sha256

HYOGO='https://kussoon.com/reading/aeon-supermarkets/'
COMMIT='d05e3872cd7484ce16df3681bb43a3b4591fa00d'
RAW=f'https://raw.githubusercontent.com/Kussoon/kussoon.github.io/{COMMIT}/'
OSAKA=RAW+'v2/verification/aeon-hyogo-osaka-map/'
PLUS={'JP-27-000033':'8Q6QPFMP+CF','JP-27-000047':'8Q6QMFQW+QF'}
def stores(path):
    tree=html.fromstring(path.read_bytes())
    body=next(el.text.strip() for el in tree.xpath('//script') if (el.text or '').strip().startswith('const STORES='))
    return json.JSONDecoder().raw_decode(body.split('=',1)[1])[0]

def data_file_check(data):
    for line in (data/'coord-sources.tsv').read_text().splitlines():
        name,u,blob=line.split('\t')
        import hashlib
        b=(data/name).read_bytes()
        assert hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()==blob,name
    assert sha256(data/'hyogo-public-live.html')==sha256(data/'hyogo-public-repo.html')

def coordinate_origin(note,method,precision,plus=False):
    s=note+' '+method
    if plus:return '利用者指定のプラスコード中心'
    if '施設代表点' in s or '施設全体' in s or '施設の地図' in s:return '施設代表点'
    if '店舗名付き' in s or 'マーカーデータ' in s or precision=='P4':return '店舗名付き地点'
    if '数値' in s:return '数値で指定された案内地点'
    return '店舗・施設の公式案内地点（入口・売場未特定）'

def co(lat,lng,p,method,url,date,ref,notes,kind):
    return {'緯度':float(lat),'経度':float(lng),'座標精度区分':p,'座標取得方法':method,
      '座標根拠URL':url,'座標確認日':date,'位置区分':kind,'座標再確認の要否':'要' if p in ('P1','P2','P3') else '定期確認',
      '座標備考':notes,'座標継承資料':ref}

def attach(data,master,new_map):
    data_file_check(data)
    geo=readcsv(data/'osaka-geocode.csv')
    hyoc=readcsv(data/'hyogo-audit.csv')
    h=stores(data/'hyogo-public-live.html')
    op=stores(data/'osaka-preview.html')
    hy_lookup={r['no']:r for r in op if r['pref']=='兵庫県'}
    assert len(h)==len(hyoc)==len(hy_lookup)==176
    assert [r['id'] for r in h]==list(range(1,177))
    a={int(r['No.']):r for r in hyoc}
    pos=readcsv(data/'osaka-position.csv')
    osaka={x['店舗ID']:x for x in readcsv(data/'osaka-audit.csv')}
    assert len(pos)==len(osaka)==142
    linked=[];hp=[]
    for item in h:
        n=item['id'];v=a[n]; hist=hy_lookup[n];uid=hist['id'];row=master[uid]
        assert uid.startswith('JP-28-') and row['都道府県']=='兵庫県'
        assert item['name']==v['正式店舗名']==hist['name'] and item['address']==v['住所']==hist['address']
        assert common_name(item['name']) in {common_name(row[k]) for k in ('店舗名','旧店舗名','公式店舗名')}
        assert comparable(row,item['address']) or url_key(item['url']) in {url_key(row[k]) for k in ('公式店舗URL','住所根拠URL')},uid
        assert float(v['緯度'])==item['lat'] and float(v['経度'])==item['lng'] and v['座標精度']==item['precision']
        assert v['確認根拠URL']==item['coordinateSource'] and v['確認日']==item['coordinateChecked']
        method='公開版で採用した店舗ピン・公式案内地点の継承'
        basis=RAW+'reading/aeon-supermarkets/coordinates-audit.csv'
        row.update(co(v['緯度'],v['経度'],v['座標精度'],method,v['確認根拠URL'],v['確認日'],basis,v['位置備考'],coordinate_origin(v['位置備考'],method,v['座標精度'])))
        linked.append({'全国統合ID':uid,'資料IDまたはNo.':n,'照合方法':'公開No.・旧JP ID・店名・住所または公式個店の三者突合','採用座標':'兵庫県公開176店版','資料URL':basis})
        hp.append({'公開版ID':n,'全国統合ID':uid,'公開版店舗名':item['name'],'Ver1.2表示店舗名':row['表示用店舗名'],
           '公開版住所':item['address'],'Ver1.2表示住所':row['表示用住所'],'公開版公式URL':item['url'],
           '公開版緯度':item['lat'],'公開版経度':item['lng'],'公開版座標精度':item['precision'],'公開版掲載':'掲載あり',
           '全国Ver1.2公開区分':row['公開区分'],'座標確認日':item['coordinateChecked'],'照合結果':'公開版・全国台帳の同一店',
           '追加備考':'南塚口町2-1-3／d0890。塚口SC店（2-1-1／d0318）と別店舗。' if uid=='JP-28-000047' else '',
           '公開ページURL':HYOGO})
    for v in pos:
        uid=v['店舗ID'];row=master[uid];old=osaka[uid]
        assert row['都道府県']=='大阪府'
        assert common_name(v['正式店舗名'])==common_name(old['正式店舗名'])
        titles={common_name(row[k]) for k in ('店舗名','旧店舗名','公式店舗名')}
        assert common_name(v['正式店舗名']) in titles,(uid,v['正式店舗名'],titles)
        assert comparable(row,v['既存住所']) or (v['公式店舗ページURL'] and url_key(v['公式店舗ページURL']) in {url_key(row[k]) for k in ('公式店舗URL','住所根拠URL')}),uid
        p=v['反映候補精度'];lat=v['反映候補緯度'];lng=v['反映候補経度']
        assert p in ('P3','P4') and v['確認日']=='2026-11-23' and lat and lng
        plus=PLUS.get(uid)
        basis=OSAKA+'osaka-official-position-audit.csv'
        url=(OSAKA+'OFFICIAL-POSITION-REVIEW-20261123.md') if plus else (v['公式地図URL'] or v['取得した公式ページURL'] or v['公式店舗ページURL'])
        note=' ／ '.join(filter(None,(v['精度の根拠'],v['未解決事項'],('指定プラスコード '+plus+' の掲載済み中心点') if plus else '')))
        row.update(co(lat,lng,p,v['取得方法'],url,v['確認日'],basis,note,coordinate_origin(note,v['取得方法'],p,bool(plus))))
        linked.append({'全国統合ID':uid,'資料IDまたはNo.':uid,'照合方法':'全国ID一致、旧店舗名と旧住所または公式個店URL一致',
              '採用座標':'大阪府2026年11月23日最終監査の継承','資料URL':basis})
    u=new_map['候補-819cf861e1d8'];v=master[u];soc=master['JP-28-000047']
    assert comparable(soc,a[47]['住所']) and not comparable(soc,v['公式住所原文'])
    assert url_key(v['公式店舗URL'])!=url_key(soc['公式店舗URL'])
    assert all(url_key(v['公式店舗URL'])!=url_key(x['url']) and common_name(v['公式店舗名'])!=common_name(x['name']) for x in h)
    hp.append({'公開版ID':'','全国統合ID':u,'公開版店舗名':'','Ver1.2表示店舗名':v['表示用店舗名'],'公開版住所':'',
       'Ver1.2表示住所':v['表示用住所'],'公開版公式URL':'','公開版緯度':'','公開版経度':'','公開版座標精度':'',
       '公開版掲載':'掲載なし','全国Ver1.2公開区分':v['公開区分'],'座標確認日':'',
       '照合結果':'塚口SC店は全国Ver.1.2で新規採用','追加備考':'ダイエー公式個店d0318・南塚口町2-1-1。公開No.47のソコラ塚口店はd0890・2-1-3。座標流用なし。',
       '公開ページURL':HYOGO})
    assert len(linked)==len({r['全国統合ID'] for r in linked})==318
    assert len(geo)==318 and set(r['id'] for r in geo)=={r['全国統合ID'] for r in linked}
    assert len(hp)==177
    return hp,linked

def history(data):
    """Retain previous candidate and comparison geometry with its unmodified supporting record."""
    names=('hyogo-audit.csv','osaka-audit.csv','osaka-position.csv','osaka-followup.csv','osaka-changes.csv','osaka-geocode.csv')
    hist=[]
    for f in names:
        rs=readcsv(data/f)
        for r in rs:
            uid=r.get('店舗ID') or r.get('id') or f"JP-28-{int(r['No.']):06d}"
            lat=r.get('緯度') or r.get('反映候補緯度') or r.get('lat','')
            lng=r.get('経度') or r.get('反映候補経度') or r.get('lng','')
            p=r.get('座標精度') or r.get('反映候補精度') or r.get('precision','')
            hist.append({'全国統合ID':uid,'継承元ファイル':f,'公式・過去緯度':lat,'公式・過去経度':lng,'精度':p,
               '確認日':r.get('座標確認日') or r.get('確認日',''),'根拠URL':r.get('確認根拠URL') or r.get('座標根拠URL') or r.get('公式地図URL') or r.get('source',''),
               '元資料原文JSON':json.dumps(r,ensure_ascii=False)})
    return hist
